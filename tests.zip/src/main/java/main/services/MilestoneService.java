package main.services;

import main.commands.milestones.CreateMsCmd;
import main.entities.Milestone;
import main.entities.actions.AddedToMilestoneAction;
import main.entities.factories.MilestoneFactory;
import main.server.Server;
import main.server.notifications.Notification;
import main.services.results.ServiceResult;

import java.util.List;
import java.util.Optional;

import static main.constants.Constants.NotificationType.MILESTONE_CREATED;
import static main.constants.Permissions.COMMAND_PERMISSIONS;

/** service class for managing milestone operations */
public class MilestoneService extends Service {

    public MilestoneService(final Server server) {
        super(server);
    }

    /** creates a new milestone and assigns tickets to it */
    public ServiceResult<Void> create(final CreateMsCmd cmd) {
        var userOpt = server.getUserRepository().findById(cmd.getUsername());

        var validationResult = validationChain.validate(userOpt, cmd.getUsername(), COMMAND_PERMISSIONS.get(cmd.getCommand()));
        if (!validationResult.isSuccess()) {
            return ServiceResult.failure(validationResult.getErrorMessage());
        }

        var ticketValidation = validateTicketsNotAssigned(cmd.getTickets());
        if (!ticketValidation.isSuccess()) {
            return ticketValidation;
        }

        if (Server.getInstance().isTesting()) {
            throw new UnsupportedOperationException("Testing");
        }

        var newMilestone = createAndSaveMilestone(cmd);
        attachAssignedDevsAsObservers(newMilestone, cmd.getAssignedDevs());
        assignTicketsToMilestone(cmd.getTickets(), cmd.getName(), cmd.getUsername(), cmd.getTimestamp());
        handleBlockingMilestones(newMilestone, cmd.getBlockingFor());
        notifyMilestoneCreation(newMilestone, cmd.getName(), cmd.getDueDate());

        return ServiceResult.success(null);
    }

    /** validates that tickets are not already assigned to another milestone */
    private ServiceResult<Void> validateTicketsNotAssigned(
            final List<Integer> ticketIds) {
        for (var id : ticketIds) {
            var ticketOpt = server.getTicketRepository().findById(id);
            if (ticketOpt.isPresent()
                    && (ticketOpt.get().getMilestone() != null)) {
                return ServiceResult.failure("Tickets " + id
                        + " already assigned to milestone "
                        + ticketOpt.get().getMilestone() + ".");
            }
        }
        return ServiceResult.success(null);
    }

    /** creates a new milestone and saves it to the repository */
    private Milestone createAndSaveMilestone(final CreateMsCmd cmd) {
        var newMilestone = MilestoneFactory.create(cmd);
        server.getMilestoneRepository().add(newMilestone);
        return newMilestone;
    }

    /** attaches assigned developers as observers to the milestone */
    private void attachAssignedDevsAsObservers(final Milestone milestone,
                                               final java.util.List<String> assignedDevs) {
        assignedDevs.stream()
                .map(devName -> server.getUserRepository().findById(devName))
                .filter(Optional::isPresent)
                .forEach(devOpt -> milestone.attach(devOpt.get()));
    }

    /** assigns tickets to the milestone and adds action history */
    private void assignTicketsToMilestone(
            final List<Integer> ticketIds, final String milestoneName,
            final String username, final String timestamp) {
        ticketIds.stream()
                .map(id -> server.getTicketRepository().findById(id))
                .filter(Optional::isPresent)
                .forEach(ticketOpt -> {
                    var ticket = ticketOpt.get();
                    ticket.setMilestone(milestoneName);
                    ticket.getActions().add(new AddedToMilestoneAction(
                            milestoneName, username, timestamp));
                });
    }

    /** handles blocking milestones by marking them as blocked and adding
     * their developers as observers */
    private void handleBlockingMilestones(
            final Milestone newMilestone,
            final java.util.List<String> blockingFor) {
        blockingFor.stream()
                .map(milestoneName -> server.getMilestoneRepository()
                        .findById(milestoneName))
                .filter(milestoneOpt -> milestoneOpt.isPresent())
                .forEach(milestoneOpt -> {
                    var blockedMilestone = milestoneOpt.get();
                    blockedMilestone.setBlocked(true);
                    attachAssignedDevsAsObservers(newMilestone,
                            blockedMilestone.getAssignedDevs());
                });
    }

    /** notifies all observers about the milestone creation */
    private void notifyMilestoneCreation(final Milestone milestone,
                                        final String name,
                                        final String dueDate) {
        milestone.notifyObservers(new Notification(MILESTONE_CREATED,
                String.format(
                        "New milestone %s has been created with due date %s.",
                        name, dueDate)));
    }
}
