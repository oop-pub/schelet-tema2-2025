package main.services;

import main.server.Server;
import main.services.validation.ValidationChain;

// base service for validation and server access
public abstract class Service {
    protected final Server server;
    protected final ValidationChain validationChain;

    // builds with server
    protected Service(final Server server) {
        this.server = server;
        this.validationChain = ValidationChain.createBasicChain();
    }
}
