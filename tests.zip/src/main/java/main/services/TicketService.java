package main.services;

import main.commands.tickets.AddCommentCmd;
import main.commands.tickets.AssignCmd;
import main.commands.tickets.ChangeStCmd;
import main.commands.tickets.ReportTicketCmd;
import main.commands.tickets.UndoAddCommentCmd;
import main.commands.tickets.UndoAssignCmd;
import main.commands.tickets.UndoChangeStCmd;
import main.constants.TicketConstants;
import main.entities.actions.AssignedAction;
import main.entities.actions.DeAssignedAction;
import main.entities.actions.StatusChangeAction;
import main.entities.factories.tickets.AbsFactory;
import main.entities.tickets.Comment;
import main.entities.tickets.Ticket;
import main.entities.users.AbstractUser;
import main.entities.users.Developer;
import main.server.Server;
import main.server.notifications.Notification;
import main.services.results.ServiceResult;
import main.services.validation.TicketValidationContext;
import main.services.validation.ticket.AnonymousTicketValidator;
import main.services.validation.ticket.CommentLengthValidator;
import main.services.validation.ticket.DeveloperAssignedToTicketValidator;
import main.services.validation.ticket.ExpertiseAreaValidator;
import main.services.validation.ticket.MilestoneAssignmentValidator;
import main.services.validation.ticket.ReporterClosedTicketValidator;
import main.services.validation.ticket.ReporterOfficialReporterValidator;
import main.services.validation.ticket.SeniorityForPriorityValidator;
import main.services.validation.ticket.SeniorityForTicketTypeValidator;
import main.services.validation.ticket.TicketAssignedToCurrentDeveloperValidator;
import main.services.validation.ticket.TicketStatusValidator;

import java.time.LocalDate;

import static main.constants.Constants.NotificationType.UNBLOCKED;
import static main.constants.Constants.NotificationType.UNBLOCKED_AFTER_DEADLINE;
import static main.constants.Permissions.COMMAND_PERMISSIONS;
import static main.constants.TicketConstants.BusinessPriority.LOW;
import static main.constants.TicketConstants.TicketStatus.CLOSED;
import static main.constants.TicketConstants.TicketStatus.IN_PROGRESS;
import static main.constants.TicketConstants.TicketStatus.OPEN;
import static main.constants.TicketConstants.TicketStatus.RESOLVED;
import static main.constants.TicketConstants.TicketType.BUG;

/** manages ticket operations with validation and permission checks */
public class TicketService extends Service {

    /** constructs ticket service with server instance */
    public TicketService(final Server server) {
        super(server);
    }

    /** reports new ticket with user role and testing phase validation */
    public ServiceResult<Void> report(final ReportTicketCmd cmd) {
        var userOpt = server.getUserRepository().findById(cmd.getUsername());

        var validationResult = validationChain.validate(userOpt, cmd.getUsername(),
                COMMAND_PERMISSIONS.get(cmd.getCommand()));
        if (!validationResult.isSuccess()) {
            return ServiceResult.failure(validationResult.getErrorMessage());
        }

        if (!server.isTesting()) {
            return ServiceResult.failure(
                    "Tickets can only be reported during testing phases.");
        }

        var ticket = AbsFactory.create(cmd);

        if (ticket.getReportedBy().isEmpty() && !ticket.getType().equals(BUG)) {
            return ServiceResult.failure(
                    "Anonymous reports are only allowed for tickets of type BUG.");
        } else if (ticket.getReportedBy().isEmpty()) {
            ticket.setBusinessPriority(LOW);
        }

        server.getTicketRepository().add(ticket);
        return ServiceResult.success(null);
    }

    /** assigns ticket to developer with expertise seniority and milestone validation */
    public ServiceResult<Void> assign(final AssignCmd cmd) {
        var userOpt = server.getUserRepository().findById(cmd.getUsername());

        var validationResult = validationChain.validate(userOpt, cmd.getUsername(),
                COMMAND_PERMISSIONS.get(cmd.getCommand()));
        if (!validationResult.isSuccess()) {
            return ServiceResult.failure(validationResult.getErrorMessage());
        }

        var developer = (Developer) userOpt.get();
        var ticketOpt = server.getTicketRepository().findById(cmd.getTicketID());
        if (ticketOpt.isEmpty()) {
            return ServiceResult.success();
        }

        var ticket = ticketOpt.get();

        // Build validator chain for assignment
        var assignmentValidator = new TicketStatusValidator(OPEN,
                "Only OPEN tickets can be assigned.");
        assignmentValidator
                .setNext(new ExpertiseAreaValidator())
                .setNext(new SeniorityForPriorityValidator())
                .setNext(new SeniorityForTicketTypeValidator())
                .setNext(new MilestoneAssignmentValidator());

        var context = new TicketValidationContext.Builder()
                .ticket(ticket)
                .user(developer)
                .server(server)
                .timestamp(cmd.getTimestamp())
                .build();

        var validation = assignmentValidator.validate(context);
        if (!validation.isSuccess()) {
            return validation;
        }

        performAssignment(ticket, developer, cmd.getTimestamp());
        return ServiceResult.success();
    }

    /** performs the actual ticket assignment and status change */
    private void performAssignment(final Ticket ticket, final Developer developer,
                                   final String timestamp) {
        ticket.setAssignee(developer.getUsername());
        ticket.setStatus(IN_PROGRESS);
        ticket.setAssignedAt(timestamp);
        ticket.getActions().add(new AssignedAction(developer.getUsername(), timestamp));
        ticket.getActions().add(new StatusChangeAction(OPEN.name(), IN_PROGRESS.name(),
                developer.getUsername(), timestamp));
    }

    /** undoes ticket assignment with status validation */
    public ServiceResult<Void> undoAssign(final UndoAssignCmd cmd) {
        var userOpt = server.getUserRepository().findById(cmd.getUsername());

        var validationResult = validationChain.validate(userOpt, cmd.getUsername(),
                COMMAND_PERMISSIONS.get(cmd.getCommand()));
        if (!validationResult.isSuccess()) {
            return ServiceResult.failure(validationResult.getErrorMessage());
        }

        var ticketOpt = server.getTicketRepository().findById(cmd.getTicketID());
        if (ticketOpt.isEmpty()) {
            return ServiceResult.success();
        }

        var ticket = ticketOpt.get();

        var undoAssignValidator = new TicketStatusValidator(IN_PROGRESS,
                "Only IN_PROGRESS tickets can be unassigned.");
        var context = new TicketValidationContext.Builder()
                .ticket(ticket)
                .user(userOpt.get())
                .server(server)
                .timestamp(cmd.getTimestamp())
                .build();

        var validation = undoAssignValidator.validate(context);
        if (!validation.isSuccess()) {
            return validation;
        }

        ticket.setStatus(TicketConstants.TicketStatus.OPEN);
        ticket.setAssignee(null);
        ticket.setAssignedAt(null);
        ticket.getActions().add(new DeAssignedAction(cmd.getUsername(), cmd.getTimestamp()));
        return ServiceResult.success();
    }

    /** adds comment to ticket with role and ticket state validation */
    public ServiceResult<Void> addComment(final AddCommentCmd cmd) {
        var userOpt = server.getUserRepository().findById(cmd.getUsername());

        var validationResult = validationChain.validate(userOpt, cmd.getUsername(),
                COMMAND_PERMISSIONS.get(cmd.getCommand()));
        if (!validationResult.isSuccess()) {
            return ServiceResult.failure(validationResult.getErrorMessage());
        }

        var currentUser = userOpt.get();
        var ticketOpt = server.getTicketRepository().findById(cmd.getTicketID());
        if (ticketOpt.isEmpty()) {
            return ServiceResult.success();
        }

        var ticket = ticketOpt.get();

        // Build validator chain for adding comments
        var commentValidator = new AnonymousTicketValidator();
        commentValidator
                .setNext(new ReporterClosedTicketValidator())
                .setNext(new CommentLengthValidator())
                .setNext(new DeveloperAssignedToTicketValidator())
                .setNext(new ReporterOfficialReporterValidator());

        var context = new TicketValidationContext.Builder()
                .ticket(ticket)
                .user(currentUser)
                .server(server)
                .timestamp(cmd.getTimestamp())
                .comment(cmd.getComment())
                .build();

        var validation = commentValidator.validate(context);
        if (!validation.isSuccess()) {
            return validation;
        }

        addCommentToTicket(ticket, currentUser, cmd.getComment(), cmd.getTimestamp());
        return ServiceResult.success();
    }

    /** adds comment to ticket */
    private void addCommentToTicket(final Ticket ticket,
                                    final AbstractUser currentUser,
                                    final String commentContent,
                                    final String timestamp) {
        var comment = new Comment(currentUser.getUsername(), commentContent,
                timestamp);
        ticket.getComments().add(comment);
    }

    /** undoes comment addition with validation */
    public ServiceResult<Void> undoAddComment(final UndoAddCommentCmd cmd) {
        var userOpt = server.getUserRepository().findById(
                cmd.getUsername());

        var validationResult = validationChain.validate(userOpt,
                cmd.getUsername(),
                COMMAND_PERMISSIONS.get(cmd.getCommand()));
        if (!validationResult.isSuccess()) {
            return ServiceResult.failure(validationResult.getErrorMessage());
        }

        var currentUser = userOpt.get();
        var ticketOpt = server.getTicketRepository().findById(cmd.getTicketID());
        if (ticketOpt.isEmpty()) {
            return ServiceResult.success();
        }

        var ticket = ticketOpt.get();

        var undoCommentValidator = new AnonymousTicketValidator();
        var context = new TicketValidationContext.Builder()
                .ticket(ticket)
                .user(currentUser)
                .server(server)
                .timestamp(cmd.getTimestamp())
                .build();

        var validation = undoCommentValidator.validate(context);
        if (!validation.isSuccess()) {
            return validation;
        }

        removeLastCommentByUser(ticket, currentUser);
        return ServiceResult.success();
    }

    /** removes last comment by current user */
    private void removeLastCommentByUser(final Ticket ticket,
                                        final AbstractUser currentUser) {
        var comments = ticket.getComments();
        for (int i = comments.size() - 1; i >= 0; i--) {
            if (comments.get(i).author().equals(currentUser.getUsername())) {
                comments.remove(i);
                break;
            }
        }
    }

    /** changes ticket status from in progress to resolved or resolved to closed */
    public ServiceResult<Void> changeStatus(ChangeStCmd cmd) {
        var userOpt = server.getUserRepository().findById(cmd.getUsername());

        var validationResult = validationChain.validate(userOpt, cmd.getUsername(), COMMAND_PERMISSIONS.get(cmd.getCommand()));
        if (!validationResult.isSuccess()) {
            return ServiceResult.failure(validationResult.getErrorMessage());
        }

        var currentUser = userOpt.get();
        var ticketOpt = server.getTicketRepository().findById(cmd.getTicketID());
        if (ticketOpt.isEmpty()) {
            return ServiceResult.success();
        }

        var ticket = ticketOpt.get();

        var statusChangeValidator = new TicketAssignedToCurrentDeveloperValidator();
        var context = new TicketValidationContext.Builder()
                .ticket(ticket)
                .user(currentUser)
                .server(server)
                .timestamp(cmd.getTimestamp())
                .build();

        var validation = statusChangeValidator.validate(context);
        if (!validation.isSuccess()) {
            return validation;
        }

        if (ticket.getStatus() == CLOSED) {
            return ServiceResult.success();
        }

        boolean wasResolved = ticket.getStatus() == RESOLVED;

        if (ticket.getStatus() == IN_PROGRESS) {
            changeStatusFromInProgressToResolved(ticket, currentUser, cmd.getTimestamp());
        } else if (ticket.getStatus() == RESOLVED) {
            changeStatusFromResolvedToClosed(ticket, currentUser, cmd.getTimestamp());
        }

        // final After status change, check if ticket is now CLOSED and handle milestone unblocking
        if (wasResolved && ticket.getStatus() == CLOSED) {
            checkAndNotifyUnblockedMilestones(ticket, cmd.getTimestamp());
        }

        return ServiceResult.success();
    }

    /** changes status from in progress to resolved */
    private void changeStatusFromInProgressToResolved(final Ticket ticket,
                                                      final AbstractUser currentUser,
                                                      final String timestamp) {
        ticket.setStatus(RESOLVED);
        ticket.setSolvedAt(timestamp);
        ticket.getActions().add(new StatusChangeAction(IN_PROGRESS.name(),
                RESOLVED.name(), currentUser.getUsername(), timestamp));
    }

    /** changes status from resolved to closed */
    private void changeStatusFromResolvedToClosed(final Ticket ticket,
                                                  final AbstractUser currentUser,
                                                  final String timestamp) {
        ticket.setStatus(CLOSED);
        ticket.getActions().add(new StatusChangeAction(RESOLVED.name(),
                CLOSED.name(), currentUser.getUsername(), timestamp));
    }

    /** checks if closing this ticket unblocks milestones and sends notifications */
    private void checkAndNotifyUnblockedMilestones(
            final Ticket closedTicket, final String timestamp) {
        if (closedTicket.getMilestone() == null
                || closedTicket.getMilestone().isEmpty()) {
            return;
        }

        var milestoneOpt = server.getMilestoneRepository().findById(
                closedTicket.getMilestone());
        if (milestoneOpt.isEmpty()) {
            return;
        }

        var milestone = milestoneOpt.get();

        // check if all tickets in this milestone are now CLOSED
        boolean allTicketsClosed = milestone.getTickets().stream()
                .map(ticketId -> server.getTicketRepository().findById(
                        ticketId))
                .filter(java.util.Optional::isPresent)
                .map(java.util.Optional::get)
                .allMatch(t -> t.getStatus() == CLOSED);

        if (!allTicketsClosed) {
            return;
        }

        // this milestone is now complete, check if it was blocking other
        // milestones
        if (milestone.getBlockingFor() != null
                && !milestone.getBlockingFor().isEmpty()) {

            for (String blockedMilestoneName : milestone.getBlockingFor()) {
                var blockedMilestoneOpt = server.getMilestoneRepository()
                        .findById(blockedMilestoneName);
                if (blockedMilestoneOpt.isPresent()) {
                    var blockedMilestone = blockedMilestoneOpt.get();

                    // unblock the milestone
                    blockedMilestone.setBlocked(false);

                    // compare against the milestone's due date
                    boolean afterDueDate = isAfterDueDate(
                            blockedMilestone.getDueDate(), timestamp);

                    if (afterDueDate) {
                        milestone.notifyObservers(new Notification(
                                UNBLOCKED_AFTER_DEADLINE,
                                String.format("Milestone %s was unblocked "
                                        + "after due date. All active tickets "
                                        + "are now CRITICAL.",
                                        blockedMilestoneName)
                        ));
                    } else {
                        milestone.notifyObservers(new Notification(
                                UNBLOCKED,
                                String.format("Milestone %s is now unblocked "
                                        + "as ticket %d has been CLOSED.",
                                        blockedMilestoneName,
                                        closedTicket.getId())
                        ));
                    }
                }
            }
        }

    }

    /** checks if current timestamp is after milestone due date */
    private boolean isAfterDueDate(final String dueDate,
                                   final String timestamp) {
        LocalDate due = LocalDate.parse(dueDate);
        LocalDate current = LocalDate.parse(timestamp);
        return current.isAfter(due);
    }

    /** undoes status change with validation and adds javadoc */
    public ServiceResult<Void> undoChangeStatus(final UndoChangeStCmd cmd) {
        var userOpt = server.getUserRepository().findById(
                cmd.getUsername());

        var validationResult = validationChain.validate(userOpt,
                cmd.getUsername(),
                COMMAND_PERMISSIONS.get(cmd.getCommand()));
        if (!validationResult.isSuccess()) {
            return ServiceResult.failure(validationResult.getErrorMessage());
        }

        var currentUser = userOpt.get();
        var ticketOpt = server.getTicketRepository().findById(cmd.getTicketID());
        if (ticketOpt.isEmpty()) {
            return ServiceResult.success();
        }

        var ticket = ticketOpt.get();

        var undoStatusValidator = new TicketAssignedToCurrentDeveloperValidator();
        var context = new TicketValidationContext.Builder()
                .ticket(ticket)
                .user(currentUser)
                .server(server)
                .timestamp(cmd.getTimestamp())
                .build();

        var validation = undoStatusValidator.validate(context);
        if (!validation.isSuccess()) {
            return validation;
        }

        if (ticket.getStatus() == IN_PROGRESS) {
            return ServiceResult.success();
        }

        if (ticket.getStatus() == RESOLVED) {
            revertStatusFromResolvedToInProgress(ticket, currentUser, cmd.getTimestamp());
        } else if (ticket.getStatus() == CLOSED) {
            revertStatusFromClosedToResolved(ticket, currentUser, cmd.getTimestamp());
        }

        return ServiceResult.success();
    }

    /** reverts status from resolved to in progress */
    private void revertStatusFromResolvedToInProgress(final Ticket ticket,
                                                      final AbstractUser currentUser,
                                                      final String timestamp) {
        ticket.setStatus(IN_PROGRESS);
        ticket.setSolvedAt(null);
        ticket.getActions().add(new StatusChangeAction(RESOLVED.name(),
                IN_PROGRESS.name(), currentUser.getUsername(), timestamp));
    }

    /** reverts status from closed to resolved */
    private void revertStatusFromClosedToResolved(final Ticket ticket,
                                                  final AbstractUser currentUser,
                                                  final String timestamp) {
        ticket.setStatus(RESOLVED);
        ticket.setSolvedAt(null);
        ticket.getActions().add(new StatusChangeAction(CLOSED.name(),
                RESOLVED.name(), currentUser.getUsername(), timestamp));
    }
}

