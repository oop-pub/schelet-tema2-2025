package main.services.results;

import main.dto.search.ItemSearchDTO;

import java.util.List;

/**
 * wrapper for search results with their appropriate handler
 */
public record SearchResult(List<ItemSearchDTO> results) {
}
