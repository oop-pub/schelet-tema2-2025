package main.services.results;

import lombok.Getter;

/** wraps service operation results with success or failure state and optional payload */
@Getter
public final class ServiceResult<T> {
    private final boolean success;
    private final String errorMessage;
    private final T payload;

    /** private constructor enforces factory method usage */
    private ServiceResult(final boolean success, final String errorMessage,
                         final T payload) {
        this.success = success;
        this.errorMessage = errorMessage;
        this.payload = payload;
    }

    /** creates successful result with payload */
    public static <T> ServiceResult<T> success(final T payload) {
        return new ServiceResult<>(true, null, payload);
    }

    /** creates failed result with error message */
    public static <T> ServiceResult<T> failure(final String errorMessage) {
        return new ServiceResult<>(false, errorMessage, null);
    }

    /** creates successful result without payload */
    public static ServiceResult<Void> success() {
        return new ServiceResult<>(true, null, null);
    }
}
