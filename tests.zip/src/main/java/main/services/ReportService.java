package main.services;

import main.commands.AbstractCmd;
import main.commands.reports.GenImpactReportCmd;
import main.commands.reports.GenPerfReportCmd;
import main.commands.reports.GenResEffReportCmd;
import main.commands.reports.GenRiskReportCmd;
import main.commands.reports.GenStabilityReportCmd;
import main.entities.tickets.Ticket;
import main.entities.users.AbstractUser;
import main.entities.users.enums.Seniority;
import main.server.Server;
import main.server.metrics.CompositeVisitor;
import main.server.metrics.ImpactVisitor;
import main.server.metrics.MetricVisitor;
import main.server.metrics.ResolutionEffVisitor;
import main.server.metrics.RiskVisitor;
import main.server.performance.PerformanceData;
import main.server.performance.PerformanceReviewer;
import main.server.performance.strategies.JuniorStrategy;
import main.server.performance.strategies.MidStrategy;
import main.server.performance.strategies.PerformanceStrategy;
import main.server.performance.strategies.SeniorStrategy;
import main.services.results.ServiceResult;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

import static main.constants.Permissions.COMMAND_PERMISSIONS;
import static main.constants.TicketConstants.TicketStatus.CLOSED;
import static main.constants.TicketConstants.TicketStatus.IN_PROGRESS;
import static main.constants.TicketConstants.TicketStatus.OPEN;
import static main.constants.TicketConstants.TicketStatus.RESOLVED;

/** service for generating various reports */
public class ReportService extends Service {
    public ReportService(final Server server) {
        super(server);
    }

    /** generates impact report for tickets */
    public ServiceResult<List<Ticket>> generateImpactReport(
            final GenImpactReportCmd cmd) {
        return genMetricReport(cmd, new ImpactVisitor(),
                t -> t.getStatus() == OPEN || t.getStatus() == IN_PROGRESS);
    }

    /** generates risk report for tickets */
    public ServiceResult<List<Ticket>> generateRiskReport(
            final GenRiskReportCmd cmd) {
        return genMetricReport(cmd, new RiskVisitor(),
                t -> t.getStatus() == OPEN || t.getStatus() == IN_PROGRESS);
    }

    /** generates efficiency report for tickets */
    public ServiceResult<List<Ticket>> generateEffReport(
            final GenResEffReportCmd cmd) {
        return genMetricReport(cmd, new ResolutionEffVisitor(),
                t -> t.getStatus() == RESOLVED || t.getStatus() == CLOSED);
    }

    private ServiceResult<List<Ticket>> genMetricReport(
            final AbstractCmd cmd, final MetricVisitor visitor,
            final Predicate<Ticket> filter) {
        var userOpt = server.getUserRepository().findById(
                cmd.getUsername());

        var validationResult = validationChain.validate(userOpt,
                cmd.getUsername(),
                COMMAND_PERMISSIONS.get(cmd.getCommand()));
        if (!validationResult.isSuccess()) {
            return ServiceResult.failure(validationResult.getErrorMessage());
        }

        List<Ticket> tickets = server.getTicketRepository().findAll()
                .filter(filter)
                .toList();

        tickets.forEach(ticket -> ticket.accept(visitor));

        return ServiceResult.success(tickets);
    }

    /** generates stability report for tickets */
    public ServiceResult<List<Ticket>> genStabilityReport(
            final GenStabilityReportCmd cmd) {
        CompositeVisitor compositeVisitor = new CompositeVisitor(
                new RiskVisitor(), new ImpactVisitor());
        return genMetricReport(cmd, compositeVisitor,
                t -> t.getStatus() == OPEN || t.getStatus() == IN_PROGRESS);
    }

    /** generates performance report for developers */
    public ServiceResult<List<PerformanceData>> genPerformanceReport(
            final GenPerfReportCmd cmd) {
        var userOpt = server.getUserRepository().findById(
                cmd.getUsername());

        var validationResult = validationChain.validate(userOpt,
                cmd.getUsername(),
                COMMAND_PERMISSIONS.get(cmd.getCommand()));
        if (!validationResult.isSuccess()) {
            return ServiceResult.failure(validationResult.getErrorMessage());
        }

        List<AbstractUser> subordinates = getSubordinates(userOpt.get());
        LocalDate currentDate = LocalDate.parse(cmd.getTimestamp());

        List<PerformanceData> performanceDataList =
                calculatePerformanceData(subordinates, currentDate);

        return ServiceResult.success(performanceDataList);
    }

    private List<AbstractUser> getSubordinates(final AbstractUser manager) {
        return server.getUserRepository()
                .findAll()
                .filter(t -> manager.getSubordinates().contains(t.getUsername()))
                .toList();
    }

    private List<PerformanceData> calculatePerformanceData(
            final List<AbstractUser> subordinates,
            final LocalDate currentDate) {
        LocalDate previousMonthStart = currentDate.minusMonths(1)
                .withDayOfMonth(1);
        LocalDate previousMonthEnd = currentDate.withDayOfMonth(1)
                .minusDays(1);

        List<PerformanceData> performanceDataList = new ArrayList<>();

        for (AbstractUser dev : subordinates) {
            List<Ticket> closedTickets = getClosedTicketsForDeveloper(dev,
                    previousMonthStart, previousMonthEnd);

            int closedTicketCount = closedTickets.size();
            double performance = closedTicketCount > 0
                    ? calculatePerformance(dev, closedTickets) : 0.0;
            double avgResolutionTime = closedTicketCount > 0
                    ? calculateAverageResolutionTime(closedTickets) : 0.0;

            dev.setPerformanceScore(performance);

            PerformanceData data = new PerformanceData(
                dev.getUsername(),
                closedTicketCount,
                performance,
                avgResolutionTime,
                dev.getSeniority().name()
            );

            performanceDataList.add(data);
        }

        return performanceDataList;
    }

    private List<Ticket> getClosedTicketsForDeveloper(final AbstractUser dev,
                                                      final LocalDate start,
                                                      final LocalDate end) {
        return server.getTicketRepository()
                .findAll()
                .filter(ticket -> ticket.getStatus() == CLOSED
                        && ticket.getAssignee() != null
                        && ticket.getAssignee().equals(dev.getUsername())
                        && ticket.getSolvedAt() != null
                        && isInPreviousMonth(ticket.getSolvedAt(), start, end))
                .toList();
    }

    private double calculatePerformance(final AbstractUser dev,
                                       final List<Ticket> tickets) {
        PerformanceStrategy strategy = selectStrategy(dev.getSeniority());
        PerformanceReviewer reviewer = new PerformanceReviewer(strategy);
        return reviewer.review(tickets);
    }

    private double calculateAverageResolutionTime(
            final List<Ticket> tickets) {
        if (tickets.isEmpty()) {
            return 0.0;
        }
        double totalDays = 0.0;
        for (Ticket ticket : tickets) {
            totalDays += ticket.getDaysToResolve();
        }

        return totalDays / tickets.size();
    }

    private PerformanceStrategy selectStrategy(final Seniority seniority) {
        return switch (seniority) {
            case MID -> new MidStrategy();
            case SENIOR -> new SeniorStrategy();
            default -> new JuniorStrategy();
        };
    }

    private boolean isInPreviousMonth(final String solvedAt,
                                     final LocalDate start,
                                     final LocalDate end) {
        LocalDate solvedDate = LocalDate.parse(solvedAt);
        return !solvedDate.isBefore(start) && !solvedDate.isAfter(end);
    }
}
