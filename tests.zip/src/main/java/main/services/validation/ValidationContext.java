package main.services.validation;

import main.entities.users.AbstractUser;

import java.util.List;
import java.util.Optional;

public record ValidationContext(Optional<AbstractUser> userOpt, String username,
                                List<String> requiredRoles) {

}

