package main.services.validation;

import lombok.Getter;
import main.entities.tickets.Ticket;
import main.entities.users.AbstractUser;
import main.server.Server;

/** context for ticket validation containing all necessary data */
@Getter
public final class TicketValidationContext {
    private final Ticket ticket;
    private final AbstractUser user;
    private final Server server;
    private final String timestamp;
    private final String comment;

    private TicketValidationContext(final Builder builder) {
        this.ticket = builder.ticket;
        this.user = builder.user;
        this.server = builder.server;
        this.timestamp = builder.timestamp;
        this.comment = builder.comment;
    }

    /** builder for ticket validation context */
    @Getter
    public static class Builder {
        private Ticket ticket;
        private AbstractUser user;
        private Server server;
        private String timestamp;
        private String comment;

        /**
         * Sets ticket.
         * @param ticketValue the ticket
         * @return this builder
         */
        public final Builder ticket(final Ticket ticketValue) {
            this.ticket = ticketValue;
            return this;
        }

        /**
         * Sets user.
         * @param userValue the user
         * @return this builder
         */
        public final Builder user(final AbstractUser userValue) {
            this.user = userValue;
            return this;
        }

        /**
         * Sets server.
         * @param serverValue the server
         * @return this builder
         */
        public final Builder server(final Server serverValue) {
            this.server = serverValue;
            return this;
        }

        /**
         * Sets timestamp.
         * @param timestampValue the timestamp
         * @return this builder
         */
        public final Builder timestamp(final String timestampValue) {
            this.timestamp = timestampValue;
            return this;
        }

        /**
         * Sets comment.
         * @param commentValue the comment
         * @return this builder
         */
        public final Builder comment(final String commentValue) {
            this.comment = commentValue;
            return this;
        }

        /**
         * Builds the context.
         * @return ticket validation context
         */
        public TicketValidationContext build() {
            return new TicketValidationContext(this);
        }
    }
}


