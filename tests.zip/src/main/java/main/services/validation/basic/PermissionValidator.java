package main.services.validation.basic;

import main.services.results.ServiceResult;
import main.services.validation.ValidationContext;
import main.services.validation.ValidationHandler;

/** validates user permissions against required roles */
public final class PermissionValidator extends ValidationHandler {
    /**
     * Validates user has required role permissions.
     * @param context validation context
     * @return success or failure result
     */
    @Override
    public ServiceResult<Void> validate(final ValidationContext context) {
        if (context.userOpt().isEmpty()) {
            return validateNext(context);
        }

        var user = context.userOpt().get();
        String userRole = user.getRole().name();

        if (!context.requiredRoles().contains(userRole)) {
            String roles = String.join(", ", context.requiredRoles());
            return ServiceResult.failure("The user does not have permission "
                    + "to execute this command: required role " + roles
                    + "; user role " + userRole + ".");
        }

        return validateNext(context);
    }
}

