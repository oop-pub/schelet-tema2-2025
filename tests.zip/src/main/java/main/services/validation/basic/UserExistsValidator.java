package main.services.validation.basic;

import main.services.results.ServiceResult;
import main.services.validation.ValidationContext;
import main.services.validation.ValidationHandler;

/** validates that a user exists in the system */
public final class UserExistsValidator extends ValidationHandler {
    /**
     * Validates user exists.
     * @param context validation context
     * @return success or failure result
     */
    @Override
    public ServiceResult<Void> validate(final ValidationContext context) {
        if (context.userOpt().isEmpty()) {
            return ServiceResult.failure("The user " + context.username()
                    + " does not exist.");
        }
        return validateNext(context);
    }
}

