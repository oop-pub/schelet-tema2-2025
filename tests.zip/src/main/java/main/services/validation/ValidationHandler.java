package main.services.validation;

import main.services.results.ServiceResult;

/** base class for validation handler chain of responsibility */
public abstract class ValidationHandler {
    protected ValidationHandler next;

    /**
     * Sets next handler in chain.
     * @param nextHandler the next handler
     * @return the next handler
     */
    public ValidationHandler setNext(final ValidationHandler nextHandler) {
        this.next = nextHandler;
        return nextHandler;
    }

    /**
     * Validates context.
     * @param context the validation context
     * @return validation result
     */
    public abstract ServiceResult<Void> validate(
            final ValidationContext context);

    /**
     * Passes validation to next handler in chain.
     * @param context the validation context
     * @return validation result
     */
    protected ServiceResult<Void> validateNext(
            final ValidationContext context) {
        if (next != null) {
            return next.validate(context);
        }
        return ServiceResult.success(null);
    }
}

