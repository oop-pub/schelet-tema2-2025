package main.services.validation;

import main.entities.users.AbstractUser;
import main.services.results.ServiceResult;
import main.services.validation.basic.PermissionValidator;
import main.services.validation.basic.UserExistsValidator;

import java.util.List;
import java.util.Optional;

/** chain of responsibility for validation handlers */
public final class ValidationChain {
    private final ValidationHandler firstHandler;

    private ValidationChain(final ValidationHandler firstHandler) {
        this.firstHandler = firstHandler;
    }

    /** creates basic validation chain with user exists and permission checks */
    public static ValidationChain createBasicChain() {
        UserExistsValidator userValidator = new UserExistsValidator();
        PermissionValidator permissionValidator = new PermissionValidator();

        userValidator.setNext(permissionValidator);

        return new ValidationChain(userValidator);
    }

    /**
     * Validates using the chain.
     * @param userOpt optional user
     * @param username username
     * @param requiredRoles required roles
     * @return validation result
     */
    public ServiceResult<Void> validate(
            final Optional<AbstractUser> userOpt, final String username,
            final List<String> requiredRoles) {
        ValidationContext context = new ValidationContext(userOpt, username,
                requiredRoles);
        return firstHandler.validate(context);
    }
}

