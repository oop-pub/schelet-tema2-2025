package main.services.validation.ticket;

import main.entities.users.Developer;
import main.services.results.ServiceResult;
import main.services.validation.TicketValidationContext;

import static main.constants.Permissions.SENIORITY_TICKET_TYPES_ACCESS;
import static main.constants.Permissions.TICKET_TYPES_SENIORITY_ACCESS;

/** validates developer seniority meets ticket type requirements */
public final class SeniorityForTicketTypeValidator extends TicketValidator {
    /**
     * Validates seniority for ticket type.
     * @param context ticket validation context
     * @return success or failure result
     */
    @Override
    public ServiceResult<Void> validate(final TicketValidationContext context) {
        if (!(context.getUser() instanceof Developer developer)) {
            return validateNext(context);
        }

        var ticket = context.getTicket();

        var allowedTicketTypes = SENIORITY_TICKET_TYPES_ACCESS.get(
                developer.getSeniority().name());
        if (!allowedTicketTypes.contains(ticket.getType().name())) {
            var requiredSeniorities = TICKET_TYPES_SENIORITY_ACCESS.get(
                    ticket.getType().name());
            return ServiceResult.failure("Developer "
                    + developer.getUsername() + " cannot assign ticket "
                    + ticket.getId() + " due to seniority level. Required: "
                    + String.join(", ", requiredSeniorities)
                    + "; Current: " + developer.getSeniority().name() + ".");
        }

        return validateNext(context);
    }
}

