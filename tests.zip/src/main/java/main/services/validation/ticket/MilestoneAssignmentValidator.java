package main.services.validation.ticket;

import main.entities.users.Developer;
import main.services.results.ServiceResult;
import main.services.validation.TicketValidationContext;

/** validates developer is assigned to ticket milestone */
public final class MilestoneAssignmentValidator extends TicketValidator {
    /**
     * Validates milestone assignment.
     * @param context ticket validation context
     * @return success or failure result
     */
    @Override
    public ServiceResult<Void> validate(final TicketValidationContext context) {
        if (!(context.getUser() instanceof Developer developer)) {
            return validateNext(context);
        }

        var ticket = context.getTicket();

        if (ticket.getMilestone() == null
                || ticket.getMilestone().isEmpty()) {
            return ServiceResult.failure("Developer "
                    + developer.getUsername()
                    + " is not assigned to milestone .");
        }

        var milestoneOpt = context.getServer().getMilestoneRepository()
                .findById(ticket.getMilestone());
        if (milestoneOpt.isPresent()) {
            var milestone = milestoneOpt.get();
            if (!milestone.getAssignedDevs().contains(
                    developer.getUsername())) {
                return ServiceResult.failure("Developer "
                        + developer.getUsername()
                        + " is not assigned to milestone "
                        + milestone.getName() + ".");
            }
            if (milestone.isBlocked()) {
                return ServiceResult.failure("Cannot assign ticket "
                        + ticket.getId() + " from blocked milestone "
                        + milestone.getName() + ".");
            }
        }

        return validateNext(context);
    }
}

