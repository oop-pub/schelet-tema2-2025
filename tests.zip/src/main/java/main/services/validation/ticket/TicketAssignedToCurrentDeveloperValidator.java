package main.services.validation.ticket;

import main.services.results.ServiceResult;
import main.services.validation.TicketValidationContext;

/** validates ticket is assigned to current developer */
public final class TicketAssignedToCurrentDeveloperValidator
        extends TicketValidator {
    /**
     * Validates ticket assignment.
     * @param context ticket validation context
     * @return success or failure result
     */
    @Override
    public ServiceResult<Void> validate(final TicketValidationContext context) {
        var user = context.getUser();
        var ticket = context.getTicket();

        if (ticket.getAssignee() == null
                || !ticket.getAssignee().equals(user.getUsername())) {
            return ServiceResult.failure("Ticket " + ticket.getId()
                    + " is not assigned to developer " + user.getUsername()
                    + ".");
        }

        return validateNext(context);
    }
}

