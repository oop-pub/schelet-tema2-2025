package main.services.validation.ticket;

import main.entities.users.enums.UserRole;
import main.services.results.ServiceResult;
import main.services.validation.TicketValidationContext;

/** validates reporter is official reporter of ticket */
public final class ReporterOfficialReporterValidator extends TicketValidator {
    /**
     * Validates reporter is official.
     * @param context ticket validation context
     * @return success or failure result
     */
    @Override
    public ServiceResult<Void> validate(final TicketValidationContext context) {
        var user = context.getUser();
        var ticket = context.getTicket();

        if (user.getRole() == UserRole.REPORTER) {
            if (!ticket.getOfficialReporter().equals(user.getUsername())) {
                return ServiceResult.failure("Reporter "
                        + user.getUsername()
                        + " cannot comment on ticket " + ticket.getId()
                        + ".");
            }
        }

        return validateNext(context);
    }
}

