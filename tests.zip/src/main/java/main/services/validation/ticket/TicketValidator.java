package main.services.validation.ticket;

import main.services.results.ServiceResult;
import main.services.validation.TicketValidationContext;

/** base class for ticket validation chain of responsibility */
public abstract class TicketValidator {
    protected TicketValidator next;

    /**
     * Sets next validator in chain.
     * @param nextValidator the next validator
     * @return the next validator
     */
    public TicketValidator setNext(final TicketValidator nextValidator) {
        this.next = nextValidator;
        return nextValidator;
    }

    /**
     * Validates ticket context.
     * @param context the validation context
     * @return validation result
     */
    public abstract ServiceResult<Void> validate(
            final TicketValidationContext context);

    /**
     * Passes validation to next validator in chain.
     * @param context the validation context
     * @return validation result
     */
    protected ServiceResult<Void> validateNext(
            final TicketValidationContext context) {
        if (next != null) {
            return next.validate(context);
        }
        return ServiceResult.success(null);
    }
}

