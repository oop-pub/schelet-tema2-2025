package main.services.validation.ticket;

import main.services.results.ServiceResult;
import main.services.validation.TicketValidationContext;

/** validates ticket is not anonymous */
public final class AnonymousTicketValidator extends TicketValidator {
    /**
     * Validates ticket has reporter.
     * @param context ticket validation context
     * @return success or failure result
     */
    @Override
    public ServiceResult<Void> validate(final TicketValidationContext context) {
        var ticket = context.getTicket();

        if (ticket.getReportedBy() == null
                || ticket.getReportedBy().isEmpty()) {
            return ServiceResult.failure(
                    "Comments are not allowed on anonymous tickets.");
        }

        return validateNext(context);
    }
}

