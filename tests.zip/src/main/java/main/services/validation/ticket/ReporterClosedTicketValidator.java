package main.services.validation.ticket;

import main.constants.TicketConstants;
import main.entities.users.enums.UserRole;
import main.services.results.ServiceResult;
import main.services.validation.TicketValidationContext;

/** validates reporters cannot comment on closed tickets */
public final class ReporterClosedTicketValidator extends TicketValidator {
    /**
     * Validates ticket not closed for reporter.
     * @param context ticket validation context
     * @return success or failure result
     */
    @Override
    public ServiceResult<Void> validate(final TicketValidationContext context) {
        var user = context.getUser();
        var ticket = context.getTicket();

        if (user.getRole() == UserRole.REPORTER) {
            if (ticket.getStatus() == TicketConstants.TicketStatus.CLOSED) {
                return ServiceResult.failure(
                        "Reporters cannot comment on CLOSED tickets.");
            }
        }

        return validateNext(context);
    }
}

