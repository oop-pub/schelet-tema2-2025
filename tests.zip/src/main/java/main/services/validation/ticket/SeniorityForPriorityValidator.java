package main.services.validation.ticket;

import main.entities.users.Developer;
import main.services.results.ServiceResult;
import main.services.validation.TicketValidationContext;

import static main.constants.Permissions.PRIORITY_SENIORITY_ACCESS;
import static main.constants.Permissions.SENIORITY_PRIORITY_ACCESS;

/** validates developer seniority meets priority requirements */
public final class SeniorityForPriorityValidator extends TicketValidator {
    /**
     * Validates seniority for priority.
     * @param context ticket validation context
     * @return success or failure result
     */
    @Override
    public ServiceResult<Void> validate(final TicketValidationContext context) {
        if (!(context.getUser() instanceof Developer developer)) {
            return validateNext(context);
        }

        var ticket = context.getTicket();

        var allowedPriorities = SENIORITY_PRIORITY_ACCESS.get(
                developer.getSeniority().name());
        if (!allowedPriorities.contains(
                ticket.getBusinessPriority().name())) {
            var requiredSeniorities = PRIORITY_SENIORITY_ACCESS.get(
                    ticket.getBusinessPriority().name());
            return ServiceResult.failure("Developer "
                    + developer.getUsername() + " cannot assign ticket "
                    + ticket.getId() + " due to seniority level. Required: "
                    + String.join(", ", requiredSeniorities)
                    + "; Current: " + developer.getSeniority().name() + ".");
        }

        return validateNext(context);
    }
}

