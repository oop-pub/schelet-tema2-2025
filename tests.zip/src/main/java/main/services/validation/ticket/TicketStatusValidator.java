package main.services.validation.ticket;

import main.constants.TicketConstants;
import main.services.results.ServiceResult;
import main.services.validation.TicketValidationContext;

/** validates ticket status matches expected status */
public final class TicketStatusValidator extends TicketValidator {
    private final TicketConstants.TicketStatus expectedStatus;
    private final String errorMessage;

    public TicketStatusValidator(
            final TicketConstants.TicketStatus expectedStatus,
            final String errorMessage) {
        this.expectedStatus = expectedStatus;
        this.errorMessage = errorMessage;
    }

    /**
     * Validates ticket status.
     * @param context ticket validation context
     * @return success or failure result
     */
    @Override
    public ServiceResult<Void> validate(final TicketValidationContext context) {
        if (context.getTicket().getStatus() != expectedStatus) {
            return ServiceResult.failure(errorMessage);
        }
        return validateNext(context);
    }
}

