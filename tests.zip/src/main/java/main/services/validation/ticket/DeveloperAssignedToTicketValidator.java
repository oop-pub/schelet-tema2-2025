package main.services.validation.ticket;

import main.entities.users.enums.UserRole;
import main.services.results.ServiceResult;
import main.services.validation.TicketValidationContext;

/** validates developer is assigned to the ticket */
public final class DeveloperAssignedToTicketValidator extends TicketValidator {
    /**
     * Validates developer is assigned to ticket.
     * @param context ticket validation context
     * @return success or failure result
     */
    @Override
    public ServiceResult<Void> validate(final TicketValidationContext context) {
        var user = context.getUser();
        var ticket = context.getTicket();

        if (user.getRole() == UserRole.DEVELOPER) {
            if (ticket.getAssignee() == null
                    || !ticket.getAssignee().equals(user.getUsername())) {
                return ServiceResult.failure("Ticket " + ticket.getId()
                        + " is not assigned to the developer "
                        + user.getUsername() + ".");
            }
        }

        return validateNext(context);
    }
}

