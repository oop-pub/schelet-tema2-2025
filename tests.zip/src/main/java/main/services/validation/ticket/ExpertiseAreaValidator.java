package main.services.validation.ticket;

import main.entities.users.Developer;
import main.services.results.ServiceResult;
import main.services.validation.TicketValidationContext;

import static main.constants.Permissions.DEVELOPER_EXPERTISE_AREAS;
import static main.constants.Permissions.TICKET_EXPERTISE_TO_DEVELOPER_TYPES;

/** validates developer expertise area matches ticket requirements */
public final class ExpertiseAreaValidator extends TicketValidator {
    /**
     * Validates developer expertise area.
     * @param context ticket validation context
     * @return success or failure result
     */
    @Override
    public ServiceResult<Void> validate(final TicketValidationContext context) {
        if (!(context.getUser() instanceof Developer developer)) {
            return validateNext(context);
        }

        var ticket = context.getTicket();

        var devExpertiseAreas = DEVELOPER_EXPERTISE_AREAS.get(
                developer.getExpertiseArea().name());
        if (!devExpertiseAreas.contains(ticket.getExpertiseArea().name())) {
            var requiredDeveloperTypes =
                    TICKET_EXPERTISE_TO_DEVELOPER_TYPES.get(
                            ticket.getExpertiseArea().name());
            return ServiceResult.failure("Developer "
                    + developer.getUsername() + " cannot assign ticket "
                    + ticket.getId() + " due to expertise area. Required: "
                    + String.join(", ", requiredDeveloperTypes)
                    + "; Current: " + developer.getExpertiseArea().name()
                    + ".");
        }

        return validateNext(context);
    }
}

