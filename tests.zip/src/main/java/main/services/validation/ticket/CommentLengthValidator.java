package main.services.validation.ticket;

import main.services.results.ServiceResult;
import main.services.validation.TicketValidationContext;

/** validates comment length meets minimum requirements */
public final class CommentLengthValidator extends TicketValidator {
    private static final int MIN_COMMENT_LENGTH = 10;

    /**
     * Validates comment is at least minimum length.
     * @param context ticket validation context
     * @return success or failure result
     */
    @Override
    public ServiceResult<Void> validate(final TicketValidationContext context) {
        var comment = context.getComment();

        if (comment != null && comment.length() < MIN_COMMENT_LENGTH) {
            return ServiceResult.failure("Comment must be at least "
                    + MIN_COMMENT_LENGTH + " characters long.");
        }

        return validateNext(context);
    }
}

