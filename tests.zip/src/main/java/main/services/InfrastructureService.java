package main.services;

import main.commands.general.SearchCmd;
import main.commands.general.StartTestingPhaseCmd;
import main.commands.view.ViewTicketsCmd;
import main.constants.Constants;
import main.entities.Milestone;
import main.entities.tickets.Ticket;
import main.entities.users.AbstractUser;
import main.entities.users.Developer;
import main.entities.users.Manager;
import main.entities.users.enums.UserRole;
import main.output.mappers.search.DeveloperSearchMapper;
import main.output.mappers.search.SearchResultMapper;
import main.output.mappers.search.SearchResultMapperFactory;
import main.output.mappers.search.TicketSearchMapper;
import main.output.mappers.search.TicketSearchWithKeywordsMapper;
import main.server.Server;
import main.server.search.SearchBar;
import main.server.search.strategies.DevTicketSearchStrategy;
import main.server.search.strategies.ManagerDevSearchStrategy;
import main.server.search.strategies.ManagerTicketSearchStrategy;
import main.services.results.SearchResult;
import main.services.results.ServiceResult;

import java.util.List;
import java.util.Set;

import static main.constants.Permissions.COMMAND_PERMISSIONS;

/** service for managing infrastructure operations like testing and search */
public class InfrastructureService extends Service {

    private final SearchResultMapperFactory searchMapperFactory;

    /** constructs infrastructure service with server instance */
    public InfrastructureService(final Server server) {
        super(server);
        this.searchMapperFactory = new SearchResultMapperFactory(
                new TicketSearchMapper(),
                new TicketSearchWithKeywordsMapper(),
                new DeveloperSearchMapper()
        );
    }

    /** starts testing phase after validation */
    public ServiceResult<Void> startTesting(
            final StartTestingPhaseCmd cmd) {
        var userOpt = server.getUserRepository().findById(
                cmd.getUsername());

        var validationResult = validationChain.validate(userOpt,
                cmd.getUsername(),
                COMMAND_PERMISSIONS.get(cmd.getCommand()));
        if (!validationResult.isSuccess()) {
            return ServiceResult.failure(validationResult.getErrorMessage());
        }

        if (Server.getInstance().getMilestoneRepository()
                .existsActiveMilestone()) {
            return ServiceResult.failure("Cannot start a new testing phase.");
        }

        Server.getInstance().startTestingPhase();
        return ServiceResult.success();
    }

    /** performs search based on filters and user role */
    public ServiceResult<SearchResult> search(final SearchCmd cmd) {
        var userOpt = server.getUserRepository().findById(
                cmd.getUsername());

        var validationResult = validationChain.validate(userOpt,
                cmd.getUsername(),
                COMMAND_PERMISSIONS.get(cmd.getCommand()));
        if (!validationResult.isSuccess()) {
            return ServiceResult.failure(validationResult.getErrorMessage());
        }

        if (cmd.getFilters().getSearchType().equals(
                Constants.SearchType.DEVELOPER.name())) {
            return searchDevs(cmd, (Manager) userOpt.get());
        }

        if (cmd.getFilters().getSearchType().equals(
                Constants.SearchType.TICKET.name())) {
            return searchTickets(cmd, userOpt.get());
        }

        // never here
        return ServiceResult.failure("Invalid search type: "
                + cmd.getFilters().getSearchType());
    }

    private ServiceResult<SearchResult> searchTickets(
            final SearchCmd cmd, final AbstractUser user) {
        if (cmd.getFilters().noFilters()) {
            ServiceResult<List<Ticket>> ticketsResult =
                    server.getViewService().viewTickets(
                            new ViewTicketsCmd(cmd));
            if (!ticketsResult.isSuccess()) {
                return ServiceResult.failure(
                        ticketsResult.getErrorMessage());
            }

            SearchResultMapper<Ticket> mapper =
                    searchMapperFactory.create(cmd);
            return ServiceResult.success(new SearchResult(
                    mapper.map(ticketsResult.getPayload())));
        }

        if (user.getRole() == UserRole.DEVELOPER) {
           List<Milestone> userMilestones =
                   server.getMilestoneRepository().getUserMilestones(
                           user.getUsername());
           List<Ticket> openTicketsInUserMilestones =
                   server.getTicketRepository()
                           .findOpenTicketsInUserMilestones(
                                   user.getUsername(),
                                   userMilestones.stream().map(
                                           Milestone::getName).toList());

           var searchBar = new SearchBar<Ticket>(
                   new DevTicketSearchStrategy((Developer) user));
           var filteredTickets = searchBar.execute(cmd.getFilters(),
                   openTicketsInUserMilestones);

           SearchResultMapper<Ticket> mapper =
                   searchMapperFactory.create(cmd);
           return ServiceResult.success(new SearchResult(
                   mapper.map(filteredTickets)));
        }

        if (user.getRole() == UserRole.MANAGER) {
            List<Ticket> allTickets = server.getTicketRepository()
                    .findAll().toList();
            var searchBar = new SearchBar<Ticket>(
                    new ManagerTicketSearchStrategy());
            var filteredTickets = searchBar.execute(cmd.getFilters(),
                    allTickets);

            SearchResultMapper<Ticket> mapper =
                    searchMapperFactory.create(cmd);
            return ServiceResult.success(new SearchResult(
                    mapper.map(filteredTickets)));
        }

        // never here
        return ServiceResult.failure(
                "User role not recognized for searching tickets.");
    }

    private ServiceResult<SearchResult> searchDevs(
            final SearchCmd cmd, final Manager manager) {
        Set<String> devNames = manager.getSubordinates();
        List<Developer> devs = server.getUserRepository().findAll()
                .filter(user -> user.getRole() == UserRole.DEVELOPER
                        && devNames.contains(user.getUsername()))
                .map(user -> (Developer) user)
                .toList();

        var searchBar = new SearchBar<Developer>(
                new ManagerDevSearchStrategy()).execute(cmd.getFilters(),
                devs);

        SearchResultMapper<Developer> mapper =
                searchMapperFactory.createDeveloperMapper();
        return ServiceResult.success(new SearchResult(mapper.map(searchBar)));
    }
}
