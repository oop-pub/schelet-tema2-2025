package main.services;

import main.commands.view.ViewAssignedCmd;
import main.commands.view.ViewMsCmd;
import main.commands.view.ViewNotificationsCmd;
import main.commands.view.ViewTicketHistoryCmd;
import main.commands.view.ViewTicketsCmd;
import main.entities.Milestone;
import main.entities.tickets.Ticket;
import main.entities.users.AbstractUser;
import main.entities.users.enums.UserRole;
import main.repositories.proxies.MilestoneRepoProxy;
import main.repositories.proxies.TicketRepoProxy;
import main.server.Server;
import main.services.results.ServiceResult;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import static main.constants.Permissions.COMMAND_PERMISSIONS;
import static main.entities.users.enums.UserRole.DEVELOPER;

/** manages view operations with permission checks */
public class VisualisationService extends Service {

    /** constructs view service with server instance */
    public VisualisationService(final Server server) {
        super(server);
    }

    /** retrieves all tickets visible to user based on role and permissions */
    public ServiceResult<List<Ticket>> viewTickets(final ViewTicketsCmd cmd) {
        var userOpt = server.getUserRepository().findById(cmd.getUsername());

        var validationResult = validationChain.validate(userOpt, cmd.getUsername(), COMMAND_PERMISSIONS.get(cmd.getCommand()));
        if (!validationResult.isSuccess()) {
            return ServiceResult.failure(validationResult.getErrorMessage());
        }

        var tickets = new TicketRepoProxy(server.getTicketRepository(), userOpt.get(), server.getMilestoneRepository())
                .findAll()
                .toList();

        return ServiceResult.success(tickets);
    }

    /** retrieves all milestones visible to user based on role and permissions */
    public ServiceResult<List<Milestone>> viewMilestones(final ViewMsCmd cmd) {
        var userOpt = server.getUserRepository().findById(cmd.getUsername());

        var validationResult = validationChain.validate(userOpt, cmd.getUsername(), COMMAND_PERMISSIONS.get(cmd.getCommand()));
        if (!validationResult.isSuccess()) {
            return ServiceResult.failure(validationResult.getErrorMessage());
        }

        var milestones = new MilestoneRepoProxy(server.getMilestoneRepository(), userOpt.get(), server.getTicketRepository())
                .findAll()
                .toList();

        return ServiceResult.success(milestones);
    }

    /**
     * retrieves all tickets assigned to the developer sorted by priority date and id
     *
     * sorting order:
     * 1. business priority (CRITICAL > HIGH > MEDIUM > LOW)
     * 2. created date (ascending)
     * 3. ticket id (ascending)
     */
    public ServiceResult<List<Ticket>> viewAssigned(final ViewAssignedCmd cmd) {
        var userOpt = server.getUserRepository().findById(cmd.getUsername());

        var validationResult = validationChain.validate(userOpt, cmd.getUsername(), COMMAND_PERMISSIONS.get(cmd.getCommand()));
        if (!validationResult.isSuccess()) {
            return ServiceResult.failure(validationResult.getErrorMessage());
        }

        var currentUser = userOpt.get();

        if (currentUser.getRole() != DEVELOPER) {
            return ServiceResult.success(List.of());
        }

        var tickets = server.getTicketRepository().findAll()
                .filter(t -> t.getAssignee() != null && t.getAssignee().equals(currentUser.getUsername()))
                .sorted(Comparator.comparing(Ticket::getBusinessPriority, Comparator.reverseOrder())
                        .thenComparing(Ticket::getCreatedAt)
                        .thenComparing(Ticket::getId))
                .toList();

        return ServiceResult.success(tickets);
    }

    /** retrieves ticket history for the user */
    public ServiceResult<List<Ticket>> viewHistory(final ViewTicketHistoryCmd cmd) {
        var userOpt = server.getUserRepository().findById(cmd.getUsername());

        var validationResult = validationChain.validate(userOpt, cmd.getUsername(), COMMAND_PERMISSIONS.get(cmd.getCommand()));
        if (!validationResult.isSuccess()) {
            return ServiceResult.failure(validationResult.getErrorMessage());
        }

        var currentUser = userOpt.get();
        List<Ticket> tickets;

        if (currentUser.getRole() == DEVELOPER) {
            tickets = findDeveloperTicketHistory(currentUser);
        } else if (currentUser.getRole() == UserRole.MANAGER) {
            tickets = findManagerTicketHistory(currentUser);
        } else {
            tickets = List.of();
        }

        return ServiceResult.success(tickets);
    }

    /** finds tickets assigned to developer sorted by date and id */
    private List<Ticket> findDeveloperTicketHistory(final AbstractUser currentUser) {
        return server.getTicketRepository().findAll()
                .filter(ticket -> wasDeveloperAssignedToTicket(ticket, currentUser))
                .sorted(Comparator.comparing(Ticket::getCreatedAt).thenComparing(Ticket::getId))
                .toList();
    }

    /** checks if developer was ever assigned to ticket */
    private boolean wasDeveloperAssignedToTicket(final Ticket ticket, final AbstractUser currentUser) {
        return ticket.getActions().stream()
                .anyMatch(action -> "ASSIGNED".equals(action.action()) && currentUser.getUsername().equals(action.by()));
    }

    /** finds tickets from manager milestones sorted by date and id */
    private List<Ticket> findManagerTicketHistory(final AbstractUser currentUser) {
        var managerMilestones = server.getMilestoneRepository().findAll()
                .filter(m -> m.getManager().equals(currentUser.getUsername()))
                .map(Milestone::getName)
                .toList();

        return server.getTicketRepository().findAll()
                .filter(t -> t.getMilestone() != null && managerMilestones.contains(t.getMilestone()))
                .sorted(Comparator.comparing(Ticket::getCreatedAt).thenComparing(Ticket::getId))
                .toList();
    }

    /** retrieves notifications for user */
    public ServiceResult<List<String>> viewNotifications(
            final ViewNotificationsCmd cmd) {
        var userOpt = server.getUserRepository().findById(
                cmd.getUsername());

        var validationResult = validationChain.validate(userOpt,
                cmd.getUsername(),
                COMMAND_PERMISSIONS.get(cmd.getCommand()));
        if (!validationResult.isSuccess()) {
            return ServiceResult.failure(validationResult.getErrorMessage());
        }

        List<String> notifications = new ArrayList<>(userOpt.get().getNotifications());
        userOpt.get().clearNotifications();

        return ServiceResult.success(notifications);
    }

}
