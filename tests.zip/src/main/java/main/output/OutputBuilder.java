package main.output;

import main.commands.AbstractCmd;
import main.commands.general.SearchCmd;
import main.commands.general.StartTestingPhaseCmd;
import main.commands.milestones.CreateMsCmd;
import main.commands.reports.GenImpactReportCmd;
import main.commands.reports.GenPerfReportCmd;
import main.commands.reports.GenResEffReportCmd;
import main.commands.reports.GenRiskReportCmd;
import main.commands.reports.GenStabilityReportCmd;
import main.commands.tickets.AddCommentCmd;
import main.commands.tickets.AssignCmd;
import main.commands.tickets.ChangeStCmd;
import main.commands.tickets.ReportTicketCmd;
import main.commands.tickets.UndoAddCommentCmd;
import main.commands.tickets.UndoAssignCmd;
import main.commands.tickets.UndoChangeStCmd;
import main.commands.view.ViewAssignedCmd;
import main.commands.view.ViewMsCmd;
import main.commands.view.ViewNotificationsCmd;
import main.commands.view.ViewTicketHistoryCmd;
import main.commands.view.ViewTicketsCmd;
import main.dto.BaseDTO;
import main.dto.ErrorDTO;
import main.dto.reports.*;
import main.dto.search.ItemSearchDTO;
import main.dto.search.SearchDTO;
import main.dto.tickets.ViewAssignedTicketsDTO;
import main.dto.tickets.ViewMilestonesDTO;
import main.dto.tickets.ViewNotificationsDTO;
import main.dto.tickets.ViewTicketDTO;
import main.dto.tickets.ViewTicketHistoryDTO;
import main.entities.Milestone;
import main.entities.tickets.Ticket;
import main.output.mappers.reports.EfficiencyReportMapper;
import main.output.mappers.reports.ImpactReportMapper;
import main.output.mappers.reports.PerformanceReportMapper;
import main.output.mappers.reports.ReportCalculator;
import main.output.mappers.reports.RiskReportMapper;
import main.output.mappers.reports.StabilityReportMapper;
import main.output.mappers.search.DeveloperSearchMapper;
import main.output.mappers.search.TicketSearchMapper;
import main.output.mappers.search.TicketSearchWithKeywordsMapper;
import main.output.mappers.tickets.AssignedMapper;
import main.output.mappers.tickets.MilestoneMapper;
import main.output.mappers.tickets.TicketHistoryMapper;
import main.output.mappers.tickets.TicketMapper;
import main.server.Server;
import main.server.performance.PerformanceData;
import main.services.results.SearchResult;
import main.services.results.ServiceResult;

import java.util.List;
import java.util.Optional;

/** builder class for creating output DTOs from command results */
public final class OutputBuilder {
    private OutputBuilder() {
        // Utility class
    }

    // create mapper instances
    private static final TicketMapper TICKET_MAPPER = new TicketMapper();
    private static final AssignedMapper ASSIGNED_MAPPER = new AssignedMapper();
    private static final MilestoneMapper MILESTONE_MAPPER = new MilestoneMapper();
    private static final TicketHistoryMapper TICKET_HISTORY_MAPPER =
            new TicketHistoryMapper();

    // report mappers with shared calculator
    private static final ReportCalculator REPORT_CALCULATOR = new ReportCalculator();
    private static final ImpactReportMapper IMPACT_REPORT_MAPPER =
            new ImpactReportMapper(REPORT_CALCULATOR);
    private static final EfficiencyReportMapper EFFICIENCY_REPORT_MAPPER =
            new EfficiencyReportMapper(REPORT_CALCULATOR);
    private static final RiskReportMapper RISK_REPORT_MAPPER =
            new RiskReportMapper(REPORT_CALCULATOR);
    private static final StabilityReportMapper STABILITY_REPORT_MAPPER =
            new StabilityReportMapper(REPORT_CALCULATOR);
    private static final PerformanceReportMapper PERFORMANCE_REPORT_MAPPER =
            new PerformanceReportMapper();

    // search mappers
    private static final TicketSearchMapper TICKET_SEARCH_MAPPER =
            new TicketSearchMapper();
    private static final TicketSearchWithKeywordsMapper
            TICKET_SEARCH_WITH_KEYWORDS_MAPPER =
            new TicketSearchWithKeywordsMapper();
    private static final DeveloperSearchMapper DEVELOPER_SEARCH_MAPPER =
            new DeveloperSearchMapper();

    /** helper method for commands that only output errors on failure */
    private static BaseDTO fromVoidResult(final AbstractCmd cmd,
                                          final ServiceResult<Void> result) {
        return result.isSuccess() ? null : createError(cmd, result.getErrorMessage());
    }

    /** creates generic error dto */
    private static BaseDTO createError(final AbstractCmd cmd, final String errorMessage) {
        return new ErrorDTO(cmd.getCommand(), cmd.getUsername(), cmd.getTimestamp(), errorMessage);
    }

    /** creates dto from report ticket command result */
    public static BaseDTO fromReport(final ReportTicketCmd cmd,
                                     final ServiceResult<Void> result) {
        return fromVoidResult(cmd, result);
    }

    /** creates dto from view tickets command result */
    public static BaseDTO fromViewTickets(final ViewTicketsCmd cmd,
                                          final ServiceResult<List<Ticket>> result) {
        return result.isSuccess()
                ? new ViewTicketDTO(cmd.getCommand(), cmd.getUsername(), cmd.getTimestamp(),
                TICKET_MAPPER.toDTOList(result.getPayload()))
                : createError(cmd, result.getErrorMessage());
    }

    /** creates dto from create milestone command result */
    public static BaseDTO fromCreateMs(final CreateMsCmd cmd,
                                       final ServiceResult<Void> result) {
        return fromVoidResult(cmd, result);
    }

    /** creates dto from view milestones command result */
    public static BaseDTO fromViewMs(final ViewMsCmd cmd,
                                     final ServiceResult<List<Milestone>> result) {
        if (!result.isSuccess()) {
            return createError(cmd, result.getErrorMessage());
        }

        Server server = Server.getInstance();
        List<MilestoneMapper.Context> contexts = result.getPayload().stream()
                .map(milestone -> {
                    // fetch tickets for this milestone
                    List<Ticket> tickets = milestone.getTickets().stream()
                            .map(server.getTicketRepository()::findById)
                            .filter(Optional::isPresent)
                            .map(Optional::get)
                            .toList();
                    return new MilestoneMapper.Context(milestone, tickets, cmd.getTimestamp());
                })
                .toList();

        return new ViewMilestonesDTO(
                cmd.getCommand(),
                cmd.getUsername(),
                cmd.getTimestamp(),
                MILESTONE_MAPPER.toDTOList(contexts)
        );
    }

    /** creates dto from assign command result */
    public static BaseDTO fromAssign(final AssignCmd cmd,
                                     final ServiceResult<Void> result) {
        return fromVoidResult(cmd, result);
    }

    /** creates dto from undo assign command result */
    public static BaseDTO fromUndoAssign(final UndoAssignCmd cmd,
                                         final ServiceResult<Void> result) {
        return fromVoidResult(cmd, result);
    }

    /** creates dto from view assigned tickets command result */
    public static BaseDTO fromViewAssigned(final ViewAssignedCmd cmd,
                                           final ServiceResult<List<Ticket>> result) {
        return result.isSuccess()
                ? new ViewAssignedTicketsDTO(cmd.getCommand(), cmd.getUsername(),
                cmd.getTimestamp(),
                ASSIGNED_MAPPER.toDTOList(result.getPayload()))
                : createError(cmd, result.getErrorMessage());
    }

    /** creates dto from view ticket history command result */
    public static BaseDTO fromViewTicketHistory(final ViewTicketHistoryCmd cmd,
                                                final ServiceResult<List<Ticket>> result) {
        return result.isSuccess()
                ? new ViewTicketHistoryDTO(cmd.getCommand(), cmd.getUsername(),
                cmd.getTimestamp(),
                TICKET_HISTORY_MAPPER.toHistoryDTOList(result.getPayload(),
                        cmd.getUsername()))
                : createError(cmd, result.getErrorMessage());
    }

    /** creates dto from add comment command result */
    public static BaseDTO fromAddComment(final AddCommentCmd cmd,
                                         final ServiceResult<Void> result) {
        return fromVoidResult(cmd, result);
    }

    /** creates dto from change status command result */
    public static BaseDTO fromChangeStatus(final ChangeStCmd cmd,
                                           final ServiceResult<Void> result) {
        return fromVoidResult(cmd, result);
    }

    /** creates dto from undo change status command result */
    public static BaseDTO fromUndoChangeStatus(final UndoChangeStCmd cmd,
                                               final ServiceResult<Void> result) {
        return fromVoidResult(cmd, result);
    }

    /** creates dto from undo add comment command result */
    public static BaseDTO fromUndoAddComment(final UndoAddCommentCmd cmd,
                                             final ServiceResult<Void> result) {
        return fromVoidResult(cmd, result);
    }

    /** creates dto from start testing phase command result */
    public static BaseDTO fromStartTesting(final StartTestingPhaseCmd cmd,
                                           final ServiceResult<Void> result) {
        return fromVoidResult(cmd, result);
    }

    /** creates dto from generate impact report command result */
    public static BaseDTO fromGenImpactReport(final GenImpactReportCmd cmd,
                                              final ServiceResult<List<Ticket>> result) {
        return result.isSuccess()
                ? new ImpactReportCmdDTO(cmd.getCommand(), cmd.getUsername(),
                cmd.getTimestamp(),
                IMPACT_REPORT_MAPPER.toDTO(result.getPayload()))
                : createError(cmd, result.getErrorMessage());
    }

    /** creates dto from efficiency report command result */
    public static BaseDTO fromEffReport(final GenResEffReportCmd cmd,
                                        final ServiceResult<List<Ticket>> result) {
        return result.isSuccess()
                ? new EffReportCmdDTO(cmd.getCommand(), cmd.getUsername(),
                cmd.getTimestamp(),
                EFFICIENCY_REPORT_MAPPER.toDTO(result.getPayload()))
                : createError(cmd, result.getErrorMessage());
    }

    /** creates dto from risk report command result */
    public static BaseDTO fromRiskReport(final GenRiskReportCmd cmd,
                                         final ServiceResult<List<Ticket>> result) {
        return result.isSuccess()
                ? new RiskReportCmdDTO(cmd.getCommand(), cmd.getUsername(),
                cmd.getTimestamp(),
                RISK_REPORT_MAPPER.toDTO(result.getPayload()))
                : createError(cmd, result.getErrorMessage());
    }

    /**
     * Creates DTO from performance report command result.
     * @param cmd the command
     * @param result the service result
     * @return base DTO
     */
    public static BaseDTO fromPerformanceReport(
            final GenPerfReportCmd cmd,
            final ServiceResult<List<PerformanceData>> result) {
        return result.isSuccess()
                ? new PerfReportCmdDTO(cmd.getCommand(), cmd.getUsername(),
                cmd.getTimestamp(),
                PERFORMANCE_REPORT_MAPPER.toDTO(result.getPayload()))
                : createError(cmd, result.getErrorMessage());
    }

    /** creates dto from search command result */
    public static BaseDTO fromSearch(final SearchCmd cmd,
                                     final ServiceResult<SearchResult> result) {
        if (!result.isSuccess()) {
            return createError(cmd, result.getErrorMessage());
        }

        String searchType = cmd.getFilters().getSearchType();
        SearchResult searchResult = result.getPayload();

        List<ItemSearchDTO> searchResults = searchResult.results();

        return new SearchDTO(cmd.getCommand(), cmd.getUsername(),
                cmd.getTimestamp(), searchType, searchResults);
    }

    /**
     * Creates DTO from view notifications command result.
     * @param cmd the command
     * @param result the service result
     * @return base DTO
     */
    public static BaseDTO fromViewNotifications(final ViewNotificationsCmd cmd,
                                                final ServiceResult<List<String>> result) {
        return result.isSuccess()
                ? new ViewNotificationsDTO(cmd.getCommand(), cmd.getUsername(),
                cmd.getTimestamp(), result.getPayload())
                : createError(cmd, result.getErrorMessage());
    }

    /**
     * Creates DTO from stability report command result.
     * @param cmd the command
     * @param result the service result
     * @return base DTO
     */
    public static BaseDTO fromStabilityReport(final GenStabilityReportCmd cmd,
                                              final ServiceResult<List<Ticket>> result) {
        return result.isSuccess()
                ? new StabilityReportCmdDTO(cmd.getCommand(), cmd.getUsername(),
                cmd.getTimestamp(),
                STABILITY_REPORT_MAPPER.toDTO(result.getPayload()))
                : createError(cmd, result.getErrorMessage());
    }
}
