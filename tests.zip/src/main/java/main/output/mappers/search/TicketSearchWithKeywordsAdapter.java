package main.output.mappers.search;

import main.dto.search.ItemSearchDTO;
import main.entities.tickets.Ticket;
import main.entities.tickets.decorators.SearchDecorator;

import java.util.List;

public class TicketSearchWithKeywordsAdapter implements SearchResultMapper<Ticket> {
    private final TicketSearchWithKeywordsMapper mapper;
    private final List<String> keywords;

    public TicketSearchWithKeywordsAdapter(
            final TicketSearchWithKeywordsMapper mapper, final List<String> keywords) {
        this.mapper = mapper;
        this.keywords = keywords;
    }

    /**
     * Converts ticket to search DTO with keywords.
     * @param ticket the ticket
     * @return search DTO
     */
    @Override
    public ItemSearchDTO toDTO(final Ticket ticket) {
        SearchDecorator decorator = new SearchDecorator(ticket, true, keywords);
        return mapper.toDTO(decorator);
    }
}

