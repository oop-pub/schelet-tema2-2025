package main.output.mappers.search;

import main.commands.general.SearchCmd;
import main.entities.tickets.Ticket;
import main.entities.users.Developer;
import main.server.Server;

import java.util.List;

import static main.entities.users.enums.UserRole.MANAGER;

public final class SearchResultMapperFactory {

    private final TicketSearchMapper ticketSearchMapper;
    private final TicketSearchWithKeywordsMapper ticketSearchWithKeywordsMapper;
    private final DeveloperSearchMapper developerSearchMapper;

    public SearchResultMapperFactory(
            final TicketSearchMapper ticketSearchMapper,
            final TicketSearchWithKeywordsMapper ticketSearchWithKeywordsMapper,
            final DeveloperSearchMapper developerSearchMapper) {
        this.ticketSearchMapper = ticketSearchMapper;
        this.ticketSearchWithKeywordsMapper = ticketSearchWithKeywordsMapper;
        this.developerSearchMapper = developerSearchMapper;
    }

    /**
     * Creates appropriate search result mapper based on command.
     * @param cmd the search command
     * @return search result mapper
     */
    public SearchResultMapper<Ticket> create(final SearchCmd cmd) {
        Server server = Server.getInstance();
        var userOpt = server.getUserRepository().findById(cmd.getUsername());

        if (userOpt.isEmpty()) {
            return ticketSearchMapper;
        }

        if (userOpt.get().getRole() == MANAGER) {
            List<String> keywords = (cmd.getFilters() != null
                    && cmd.getFilters().getKeywords() != null)
                    ? cmd.getFilters().getKeywords()
                    : List.of();
            return new TicketSearchWithKeywordsAdapter(
                    ticketSearchWithKeywordsMapper, keywords);
        }

        return ticketSearchMapper;
    }

    /**
     * Creates developer search mapper.
     * @return developer search mapper
     */
    public SearchResultMapper<Developer> createDeveloperMapper() {
        return developerSearchMapper;
    }
}
