package main.output.mappers.search;

import main.dto.search.ItemSearchDTO;
import main.dto.search.TSearchDTO;
import main.entities.tickets.Ticket;

/** mapper for converting tickets to search DTOs without matching words (for developers) */
public class TicketSearchMapper implements SearchResultMapper<Ticket> {

    /**
     * Converts ticket to search DTO.
     * @param ticket the ticket
     * @return search DTO
     */
    @Override
    public ItemSearchDTO toDTO(final Ticket ticket) {
        return new TSearchDTO(
                ticket.getId(),
                ticket.getType().name(),
                ticket.getTitle(),
                ticket.getBusinessPriority().name(),
                ticket.getStatus().name(),
                ticket.getCreatedAt(),
                ticket.getSolvedAt() == null ? "" : ticket.getSolvedAt(),
                ticket.getReportedBy() == null ? "" : ticket.getReportedBy(),
                null
        );
    }
}
