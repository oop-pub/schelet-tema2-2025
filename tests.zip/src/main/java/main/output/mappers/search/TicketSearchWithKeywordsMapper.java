package main.output.mappers.search;

import main.dto.search.ItemSearchDTO;
import main.dto.search.TSearchDTO;
import main.entities.tickets.Ticket;
import main.entities.tickets.decorators.SearchDecorator;
import main.output.mappers.Mapper;

import java.util.List;

/** mapper for converting tickets with keywords to search DTOs (for managers) */
public class TicketSearchWithKeywordsMapper implements Mapper<SearchDecorator, ItemSearchDTO> {

    /**
     * Converts search decorator to search DTO.
     * @param decorator the search decorator
     * @return search DTO
     */
    @Override
    public ItemSearchDTO toDTO(final SearchDecorator decorator) {
        Ticket ticket = decorator.getTicket();
        List<String> matchingWords = decorator.getMatchingWords();

        return new TSearchDTO(
                ticket.getId(),
                ticket.getType().name(),
                ticket.getTitle(),
                ticket.getBusinessPriority().name(),
                ticket.getStatus().name(),
                ticket.getCreatedAt(),
                ticket.getSolvedAt() == null ? "" : ticket.getSolvedAt(),
                ticket.getReportedBy() == null ? "" : ticket.getReportedBy(),
                matchingWords
        );
    }
}
