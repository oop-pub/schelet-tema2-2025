package main.output.mappers.search;

import main.dto.search.DevSearchDTO;
import main.dto.search.ItemSearchDTO;
import main.entities.users.Developer;

/** mapper for converting developers to search DTOs */
public class DeveloperSearchMapper implements SearchResultMapper<Developer> {

    /**
     * Converts developer to search DTO.
     * @param developer the developer
     * @return search DTO
     */
    @Override
    public ItemSearchDTO toDTO(final Developer developer) {
        return new DevSearchDTO(
                developer.getUsername(),
                developer.getExpertiseArea().name(),
                developer.getSeniority().name(),
                developer.getPerformanceScore(),
                developer.getHireDate().toString()
        );
    }
}
