package main.output.mappers.search;

import main.dto.search.ItemSearchDTO;
import main.output.mappers.Mapper;

import java.util.List;

/** strategy interface for mapping search results */
public interface SearchResultMapper<T> extends Mapper<T, ItemSearchDTO> {

    /** maps a list of items to search DTOs using the generic mapper's toDTOList */
    default List<ItemSearchDTO> map(final List<T> items) {
        return toDTOList(items);
    }
}
