package main.output.mappers.reports;

import main.dto.reports.PerfReportDTO;
import main.output.mappers.Mapper;
import main.server.performance.PerformanceData;

import java.util.Comparator;
import java.util.List;

/** mapper for converting performance data to performance report DTOs */
public class PerformanceReportMapper implements Mapper<List<PerformanceData>,
        List<PerfReportDTO>> {

    private static final double ROUNDING_FACTOR = 100.0;

    /**
     * Converts performance data to DTOs.
     * @param data list of performance data
     * @return list of performance report DTOs
     */
    @Override
    public List<PerfReportDTO> toDTO(final List<PerformanceData> data) {
        return data.stream()
                .sorted(Comparator.comparing(PerformanceData::getUsername))
                .map(d -> new PerfReportDTO(
                        d.getUsername(),
                        d.getClosedTickets(),
                        Math.round(d.getAverageResolutionTime()
                                * ROUNDING_FACTOR) / ROUNDING_FACTOR,
                        Math.round(d.getPerformanceScore()
                                * ROUNDING_FACTOR) / ROUNDING_FACTOR,
                        d.getSeniority()
                ))
                .toList();
    }
}

