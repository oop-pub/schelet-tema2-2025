package main.output.mappers.reports;

import main.dto.reports.EffReportDTO;
import main.entities.tickets.Ticket;
import main.output.mappers.Mapper;

import java.util.List;
import java.util.Map;

/** mapper for converting ticket lists to efficiency report DTOs */
public class EfficiencyReportMapper implements Mapper<List<Ticket>, EffReportDTO> {

    private final ReportCalculator calculator;

    public EfficiencyReportMapper(final ReportCalculator calculator) {
        this.calculator = calculator;
    }

    /**
     * Converts tickets to efficiency report DTO.
     * @param tickets list of tickets
     * @return efficiency report DTO
     */
    @Override
    public EffReportDTO toDTO(final List<Ticket> tickets) {
        int totalTickets = tickets.size();
        Map<String, Integer> ticketsByType = calculator.countByType(tickets);
        Map<String, Integer> ticketsByPriority = calculator.countByPriority(tickets);
        Map<String, Double> efficiencyByType = calculator
                .calculateAverageByType(tickets, Ticket::getEfficiencyScore);

        return new EffReportDTO(totalTickets, ticketsByType, ticketsByPriority, efficiencyByType);
    }
}

