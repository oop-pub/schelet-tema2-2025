package main.output.mappers.reports;

import main.constants.Constants;
import main.dto.reports.StabilityReportDTO;
import main.entities.tickets.Ticket;
import main.output.mappers.Mapper;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static main.constants.Constants.PRIORITY_LIST;
import static main.constants.Constants.TYPE_LIST;

/** Mapper for converting ticket lists to stability report DTOs (enum-based). */
public class StabilityReportMapper implements Mapper<List<Ticket>, StabilityReportDTO> {

    private final ReportCalculator calculator;

    public StabilityReportMapper(final ReportCalculator calculator) {
        this.calculator = calculator;
    }

    /**
     * Converts tickets to stability report DTO.
     * @param tickets list of tickets
     * @return stability report DTO
     */
    @Override
    public StabilityReportDTO toDTO(final List<Ticket> tickets) {
        int totalOpenTickets = tickets.size();

        // If no open tickets, app is STABLE
        if (totalOpenTickets == 0) {
            return createEmptyStabilityReport();
        }

        Map<String, Integer> openTicketsByType = calculator.countByType(tickets);
        Map<String, Integer> openTicketsByPriority =
                calculator.countByPriority(tickets);

        // Calculate average risk and impact by type
        Map<String, Double> avgRiskByType = calculator
                .calculateAverageByType(tickets, Ticket::getRiskScore);

        // Use enum directly from calculator
        Map<String, Constants.Risk> riskByType = avgRiskByType.entrySet().stream()
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        entry -> calculator.getRiskGrade(entry.getValue()),
                        (e1, e2) -> e1,
                        LinkedHashMap::new
                ));

        Map<String, Double> impactByType = calculator
                .calculateAverageByType(tickets, Ticket::getImpactScore);

        // Determine stability using enums
        String appStability = determineAppStability(riskByType,
                impactByType);

        return new StabilityReportDTO(
                totalOpenTickets,
                openTicketsByType,
                openTicketsByPriority,
                riskByType,
                impactByType,
                appStability
        );
    }

    /** Creates a stability report when there are no open tickets (system stable). */
    private StabilityReportDTO createEmptyStabilityReport() {
        Map<String, Integer> emptyTypeCount = new LinkedHashMap<>();
        Map<String, Integer> emptyPriorityCount = new LinkedHashMap<>();
        Map<String, Constants.Risk> emptyRiskByType = new LinkedHashMap<>();
        Map<String, Double> emptyImpactByType = new LinkedHashMap<>();

        for (String type : TYPE_LIST) {
            emptyTypeCount.put(type, 0);
            emptyRiskByType.put(type, Constants.Risk.NEGLIGIBLE);
            emptyImpactByType.put(type, 0.00);
        }

        for (String priority : PRIORITY_LIST) {
            emptyPriorityCount.put(priority, 0);
        }

        return new StabilityReportDTO(
                0,
                emptyTypeCount,
                emptyPriorityCount,
                emptyRiskByType,
                emptyImpactByType,
                "STABLE"
        );
    }

    private static final double LOW_IMPACT_THRESHOLD = 50.0;

    /** Determines application stability based on risk and impact metrics. */
    private String determineAppStability(
            final Map<String, Constants.Risk> riskByType,
            final Map<String, Double> impactByType) {
        boolean hasHighRisk = riskByType.values().stream()
                .anyMatch(risk -> risk == Constants.Risk.SIGNIFICANT
                        || risk == Constants.Risk.MAJOR);

        if (hasHighRisk) {
            return "UNSTABLE";
        }

        boolean allRisksNegligible = riskByType.values().stream()
                .allMatch(risk -> risk == Constants.Risk.NEGLIGIBLE);

        boolean allImpactsLow = impactByType.values().stream()
                .allMatch(impact -> impact < LOW_IMPACT_THRESHOLD);

        if (allRisksNegligible && allImpactsLow) {
            return "STABLE";
        }

        return "PARTIALLY STABLE";
    }
}
