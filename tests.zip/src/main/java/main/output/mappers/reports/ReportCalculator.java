package main.output.mappers.reports;

import main.constants.Constants;
import main.entities.tickets.Ticket;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.function.ToDoubleFunction;
import java.util.stream.Collectors;

import static main.constants.Constants.PRIORITY_LIST;
import static main.constants.Constants.Risk.NEGLIGIBLE;
import static main.constants.Constants.Risk.MODERATE;
import static main.constants.Constants.Risk.SIGNIFICANT;
import static main.constants.Constants.Risk.MAJOR;
import static main.constants.Constants.TYPE_LIST;

/** utility class for report calculations shared across report mappers */
public final class ReportCalculator {
    /**
     * Counts tickets by type.
     * @param tickets list of tickets
     * @return map of type to count
     */
    public Map<String, Integer> countByType(final List<Ticket> tickets) {
        return countByCategory(tickets, ticket -> ticket.getType().toString(),
                TYPE_LIST);
    }

    /**
     * Counts tickets by priority.
     * @param tickets list of tickets
     * @return map of priority to count
     */
    public Map<String, Integer> countByPriority(final List<Ticket> tickets) {
        return countByCategory(tickets,
                ticket -> ticket.getBusinessPriority().toString(), PRIORITY_LIST);
    }

    /**
     * Counts items by category.
     * @param items list of items
     * @param classifier function to extract category
     * @param order list of categories in order
     * @param <T> type of items
     * @return map of category to count
     */
    public <T> Map<String, Integer> countByCategory(
            final List<T> items,
            final Function<T, String> classifier,
            final List<String> order) {

        Map<String, Integer> result = new LinkedHashMap<>();

        for (String category : order) {
            result.put(category, 0);
        }

        result.putAll(items.stream()
                .collect(Collectors.groupingBy(
                        classifier,
                        Collectors.collectingAndThen(Collectors.counting(), Long::intValue)
                )));

        return result;
    }

    private static final double ROUNDING_FACTOR = 100.0;

    /**
     * Calculates average score by type.
     * @param tickets list of tickets
     * @param scoreExtractor function to extract score
     * @return map of type to average score
     */
    public Map<String, Double> calculateAverageByType(
            final List<Ticket> tickets,
            final ToDoubleFunction<Ticket> scoreExtractor) {

        // initialize with all types set to 0.00
        Map<String, Double> result = new LinkedHashMap<>();
        for (String type : TYPE_LIST) {
            result.put(type, 0.00);
        }

        // calculate averages for types that have tickets
        Map<String, Double> averages = tickets.stream()
                .collect(Collectors.groupingBy(
                        ticket -> ticket.getType().toString(),
                        Collectors.averagingDouble(scoreExtractor)
                ))
                .entrySet().stream()
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        v -> Math.round(v.getValue() * ROUNDING_FACTOR) / ROUNDING_FACTOR,
                        (e1, e2) -> e1,
                        LinkedHashMap::new
                ));

        // override with actual averages where they exist
        result.putAll(averages);

        return result;
    }

    private static final int NEGLIGIBLE_MAX = 24;
    private static final int MODERATE_MIN = 25;
    private static final int MODERATE_MAX = 49;
    private static final int SIGNIFICANT_MIN = 50;
    private static final int SIGNIFICANT_MAX = 74;
    private static final int MAJOR_MIN = 75;
    private static final int MAJOR_MAX = 100;

    /**
     * Gets risk grade based on risk score.
     * @param riskScore the risk score
     * @return risk grade
     */
    public Constants.Risk getRiskGrade(final double riskScore) {
        if (riskScore >= 0 && riskScore <= NEGLIGIBLE_MAX) {
            return NEGLIGIBLE;
        } else if (riskScore >= MODERATE_MIN && riskScore <= MODERATE_MAX) {
            return MODERATE;
        } else if (riskScore >= SIGNIFICANT_MIN && riskScore <= SIGNIFICANT_MAX) {
            return SIGNIFICANT;
        } else if (riskScore >= MAJOR_MIN && riskScore <= MAJOR_MAX) {
            return MAJOR;
        }
        throw new IllegalArgumentException("Risk score out of range: " + riskScore);
    }

}

