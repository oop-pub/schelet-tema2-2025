package main.output.mappers.reports;

import main.dto.reports.RiskReportDTO;
import main.entities.tickets.Ticket;
import main.output.mappers.Mapper;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static main.constants.Constants.Risk;

/** Mapper for converting ticket lists to risk report DTOs (enum-based). */
public class RiskReportMapper implements Mapper<List<Ticket>, RiskReportDTO> {

    private final ReportCalculator calculator;

    public RiskReportMapper(final ReportCalculator calculator) {
        this.calculator = calculator;
    }

    /**
     * Converts tickets to risk report DTO.
     * @param tickets list of tickets
     * @return risk report DTO
     */
    @Override
    public RiskReportDTO toDTO(final List<Ticket> tickets) {
        int totalTickets = tickets.size();

        Map<String, Integer> ticketsByType = calculator.countByType(tickets);
        Map<String, Integer> ticketsByPriority = calculator.countByPriority(tickets);

        // Calculate average risk by type
        Map<String, Double> avgRiskByType = calculator
                .calculateAverageByType(tickets, Ticket::getRiskScore);

        // Map to Risk enum directly
        Map<String, Risk> riskByType = avgRiskByType.entrySet().stream()
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        entry -> calculator.getRiskGrade(entry.getValue()),
                        (e1, e2) -> e1,
                        LinkedHashMap::new
                ));

        return new RiskReportDTO(
                totalTickets,
                ticketsByType,
                ticketsByPriority,
                riskByType
        );
    }
}
