package main.output.mappers.reports;

import main.dto.reports.ImpactReportDTO;
import main.entities.tickets.Ticket;
import main.output.mappers.Mapper;

import java.util.List;
import java.util.Map;

/** mapper for converting ticket lists to customer impact report DTOs */
public class ImpactReportMapper implements Mapper<List<Ticket>, ImpactReportDTO> {

    private final ReportCalculator calculator;

    public ImpactReportMapper(final ReportCalculator calculator) {
        this.calculator = calculator;
    }

    /**
     * Converts tickets to impact report DTO.
     * @param tickets list of tickets
     * @return impact report DTO
     */
    @Override
    public ImpactReportDTO toDTO(final List<Ticket> tickets) {
        int totalTickets = tickets.size();
        Map<String, Integer> ticketsByType = calculator.countByType(tickets);
        Map<String, Integer> ticketsByPriority = calculator.countByPriority(tickets);
        Map<String, Double> customerImpactByType = calculator
                .calculateAverageByType(tickets, Ticket::getImpactScore);

        return new ImpactReportDTO(
                totalTickets, ticketsByType, ticketsByPriority, customerImpactByType);
    }
}

