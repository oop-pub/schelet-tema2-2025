package main.output.mappers.tickets;

import main.dto.tickets.AssignedTicketDTO;
import main.dto.tickets.CommentDTO;
import main.entities.tickets.Ticket;
import main.output.mappers.Mapper;

import java.util.List;

/** mapper for converting assigned tickets to DTOs for viewAssignedTickets output */
public class AssignedMapper implements Mapper<Ticket, AssignedTicketDTO> {

    /** converts ticket entity to assigned ticket DTO with required fields */
    @Override
    public AssignedTicketDTO toDTO(final Ticket ticket) {
        List<CommentDTO> commentDTOs = ticket.getComments().stream()
                .map(c -> new CommentDTO(
                        c.author(),
                        c.content(),
                        c.createdAt()
                ))
                .toList();

        return new AssignedTicketDTO(
                ticket.getId(),
                ticket.getType().name(),
                ticket.getTitle(),
                ticket.getBusinessPriority().name(),
                ticket.getStatus().name(),
                ticket.getCreatedAt(),
                ticket.getAssignedAt() == null ? "" : ticket.getAssignedAt(),
                ticket.getReportedBy() == null ? "" : ticket.getReportedBy(),
                commentDTOs
        );
    }
}
