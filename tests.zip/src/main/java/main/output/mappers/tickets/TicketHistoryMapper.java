package main.output.mappers.tickets;

import lombok.Getter;
import main.dto.tickets.CommentDTO;
import main.dto.tickets.TicketHistoryItemDTO;
import main.entities.actions.Action;
import main.entities.tickets.Comment;
import main.entities.tickets.Ticket;
import main.output.mappers.Mapper;

import java.util.ArrayList;
import java.util.List;

/**
 * Mapper for converting ticket entities to history DTOs
 * with truncation for unassigned developers.
 */
public class TicketHistoryMapper implements Mapper<TicketHistoryMapper.Context, TicketHistoryItemDTO> {

    /**
     * Context object for ticket history mapping with ticket and username.
     */
    @Getter
    public static class Context {
        private final Ticket ticket;
        private final String currentUsername;

        public Context(final Ticket ticket,
                       final String currentUsername) {
            this.ticket = ticket;
            this.currentUsername = currentUsername;
        }

    }

    /** converts ticket context to history DTO with optional truncation at deassign action */
    @Override
    public TicketHistoryItemDTO toDTO(final Context context) {
        Ticket ticket = context.getTicket();
        String currentUsername = context.getCurrentUsername();

        int deAssignedIndex = findDeAssignedIndex(ticket, currentUsername);

        List<Action> actions = collectActions(ticket, deAssignedIndex);
        List<CommentDTO> comments = collectComments(ticket, deAssignedIndex);

        return new TicketHistoryItemDTO(
            ticket.getId(),
            ticket.getTitle(),
            ticket.getStatus().name(),
            actions,
            comments
        );
    }

    /**
     * Converts ticket to history DTO with optional truncation at deassign action.
     * @param ticket the ticket
     * @param currentUsername the current username
     * @return history DTO
     */
    public TicketHistoryItemDTO toHistoryDTO(final Ticket ticket, final String currentUsername) {
        return toDTO(new Context(ticket, currentUsername));
    }

    /**
     * Converts list of tickets to history DTOs.
     * @param tickets list of tickets
     * @param currentUsername the current username
     * @return list of history DTOs
     */
    public List<TicketHistoryItemDTO> toHistoryDTOList(final List<Ticket> tickets,
                                                       final String currentUsername) {
        return tickets.stream()
                .map(ticket -> toDTO(new Context(ticket, currentUsername)))
                .toList();
    }

    /**
     * Finds index of deassigned action by current user or returns -1.
     * @param ticket the ticket
     * @param currentUsername the current username
     * @return index or -1
     */
    private int findDeAssignedIndex(final Ticket ticket, final String currentUsername) {
        for (int i = 0; i < ticket.getActions().size(); i++) {
            Action action = ticket.getActions().get(i);
            if ("DE-ASSIGNED".equals(action.action()) && currentUsername.equals(action.by())) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Collects actions up to deassigned index or all if no deassign.
     * @param ticket the ticket
     * @param deAssignedIndex the deassigned index
     * @return list of actions
     */
    private List<Action> collectActions(final Ticket ticket, final int deAssignedIndex) {
        List<Action> actions = new ArrayList<>();

        if (deAssignedIndex >= 0) {
            for (int i = 0; i <= deAssignedIndex; i++) {
                actions.add(ticket.getActions().get(i));
            }
        } else {
            actions.addAll(ticket.getActions());
        }

        return actions;
    }

    /**
     * Collects comments up to deassigned timestamp or all if no deassign.
     * @param ticket the ticket
     * @param deAssignedIndex the deassigned index
     * @return list of comment DTOs
     */
    private List<CommentDTO> collectComments(final Ticket ticket, final int deAssignedIndex) {
        List<CommentDTO> comments = new ArrayList<>();

        if (deAssignedIndex >= 0) {
            String deAssignedTimestamp = ticket.getActions().get(deAssignedIndex).timestamp();
            for (Comment comment : ticket.getComments()) {
                if (comment.createdAt().compareTo(deAssignedTimestamp) <= 0) {
                    comments.add(new CommentDTO(
                        comment.author(),
                        comment.content(),
                        comment.createdAt()
                    ));
                }
            }
        } else {
            for (Comment comment : ticket.getComments()) {
                comments.add(new CommentDTO(
                    comment.author(),
                    comment.content(),
                    comment.createdAt()
                ));
            }
        }

        return comments;
    }
}
