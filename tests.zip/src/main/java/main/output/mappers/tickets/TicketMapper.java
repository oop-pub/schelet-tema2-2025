package main.output.mappers.tickets;

import main.dto.tickets.CommentDTO;
import main.dto.tickets.TicketDTO;
import main.entities.tickets.Comment;
import main.entities.tickets.Ticket;
import main.output.mappers.Mapper;

import java.text.SimpleDateFormat;
import java.util.List;

public class TicketMapper implements Mapper<Ticket, TicketDTO> {
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");

    /**
     * Converts ticket to DTO.
     * @param t the ticket
     * @return ticket DTO
     */
    @Override
    public TicketDTO toDTO(final Ticket t) {
        List<CommentDTO> commentDTOs = t.getComments().stream()
                .map(TicketMapper::mapComment)
                .toList();

        return new TicketDTO(
                t.getId(),
                t.getType().name(),
                t.getTitle(),
                t.getBusinessPriority().name(),
                t.getStatus().name(),
                t.getCreatedAt(), // already String
                t.getAssignedAt() == null ? "" : t.getAssignedAt(),
                t.getSolvedAt() == null ? "" : t.getSolvedAt(),
                t.getAssignee() == null ? "" : t.getAssignee(),
                t.getReportedBy() == null ? "" : t.getReportedBy(),
                commentDTOs
        );
    }

    private static CommentDTO mapComment(final Comment c) {
        return new CommentDTO(
                c.author(),
                c.content(),
                c.createdAt()
        );
    }
}
