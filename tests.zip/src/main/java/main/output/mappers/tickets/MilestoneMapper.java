package main.output.mappers.tickets;

import lombok.Getter;
import main.dto.milestones.MilestoneDTO;
import main.dto.milestones.RepartitionDTO;
import main.entities.Milestone;
import main.entities.tickets.Ticket;
import main.output.mappers.Mapper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static main.constants.TicketConstants.TicketStatus.CLOSED;

/** mapper for converting milestone entities to DTOs with calculated statistics */
public class MilestoneMapper implements Mapper<MilestoneMapper.Context, MilestoneDTO> {

    private static final double PERCENTAGE_MULTIPLIER = 100.0;

    /** context object for milestone mapping with all required data */
    @Getter
    public static class Context {
        private final Milestone milestone;
        private final List<Ticket> tickets;
        private final String currentDate;

        public Context(final Milestone milestone, final List<Ticket> tickets,
                       final String currentDate) {
            this.milestone = milestone;
            this.tickets = tickets;
            this.currentDate = currentDate;
        }

    }

    /** converts milestone context to DTO with all calculated fields */
    @Override
    public MilestoneDTO toDTO(final Context context) {
        Milestone milestone = context.getMilestone();
        List<Ticket> tickets = context.getTickets();
        String currentDate = context.getCurrentDate();

        // calculate open and closed tickets
        List<Integer> openTickets = tickets.stream()
                .filter(t -> t.getStatus() != CLOSED)
                .map(Ticket::getId)
                .toList();

        List<Integer> closedTickets = tickets.stream()
                .filter(t -> t.getStatus() == CLOSED)
                .map(Ticket::getId)
                .toList();

        // calculate completion percentage
        double completionPercentage = milestone.getTickets().isEmpty()
                ? 0.0
                : (double) closedTickets.size() / milestone.getTickets().size();

        completionPercentage = Math.round(completionPercentage
                * PERCENTAGE_MULTIPLIER) / PERCENTAGE_MULTIPLIER;


        // calculate status
        String status = openTickets.isEmpty() ? "COMPLETED" : "ACTIVE";

        // use milestone's methods for days until due and overdue
        int daysUntilDue = milestone.getDaysUntilDue(currentDate);
        int overdueBy = milestone.getOverdueBy(currentDate);

        // calculate repartition
        List<RepartitionDTO> repartition = calculateRepartition(milestone, tickets);

        return new MilestoneDTO(
                milestone.getName(),
                new ArrayList<>(milestone.getBlockingFor()),
                milestone.getDueDate(),
                milestone.getCreatedAt(),
                milestone.getTickets(),
                new ArrayList<>(milestone.getAssignedDevs()),
                milestone.getManager(),
                status,
                milestone.isBlocked(),
                daysUntilDue,
                overdueBy,
                openTickets,
                closedTickets,
                completionPercentage,
                repartition
        );
    }

    /** calculates repartition of tickets among developers sorted by count and name */
    private List<RepartitionDTO> calculateRepartition(final Milestone milestone,
                                                      final List<Ticket> tickets) {
        // create a map of developer -> assigned ticket IDs
        Map<String, List<Integer>> devTicketMap = new HashMap<>();

        // initialize all assigned devs with empty lists
        for (String dev : milestone.getAssignedDevs()) {
            devTicketMap.put(dev, new ArrayList<>());
        }

        // populate with assigned tickets
        for (Ticket ticket : tickets) {
            if (ticket.getAssignee() != null
                    && devTicketMap.containsKey(ticket.getAssignee())) {
                devTicketMap.get(ticket.getAssignee()).add(ticket.getId());
            }
        }

        // convert to DTOs and sort
        return devTicketMap.entrySet().stream()
                .map(entry -> new RepartitionDTO(entry.getKey(), entry.getValue()))
                .sorted((r1, r2) -> {
                    int sizeCompare = Integer.compare(r1.assignedTickets().size(),
                            r2.assignedTickets().size());
                    if (sizeCompare != 0) {
                        return sizeCompare;
                    }
                    return r1.developer().compareTo(r2.developer());
                })
                .toList();
    }

}
