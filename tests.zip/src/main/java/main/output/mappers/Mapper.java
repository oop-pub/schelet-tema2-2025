package main.output.mappers;

import java.util.List;

/** generic interface for mappers that convert entities to DTOs */
public interface Mapper<E, D> {
    /** converts single entity to DTO - can be overridden for custom implementation */
    D toDTO(E entity);

    /** converts list of entities to list of DTOs */
    default List<D> toDTOList(final List<E> entities) {
        return entities.stream()
                .map(this::toDTO)
                .toList();
    }
}
