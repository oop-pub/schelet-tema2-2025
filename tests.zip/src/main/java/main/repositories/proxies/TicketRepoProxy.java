package main.repositories.proxies;

import lombok.Getter;
import main.constants.TicketConstants;
import main.entities.tickets.Ticket;
import main.entities.users.AbstractUser;
import main.repositories.MilestoneRepo;
import main.repositories.Repository;
import main.repositories.TicketRepo;

import java.util.Comparator;
import java.util.Optional;
import java.util.stream.Stream;

/** proxy for ticket repository with role based filtering - implements proxy pattern */
public class TicketRepoProxy extends Repository<Ticket, Integer> {
    @Getter
    private final TicketRepo realRepo;
    private final AbstractUser currentUser;
    private final MilestoneRepo milestoneRepo;

    /** constructs proxy with repository user and milestone repo */
    public TicketRepoProxy(
            final TicketRepo realRepo, final AbstractUser currentUser,
            final MilestoneRepo milestoneRepo) {
        this.realRepo = realRepo;
        this.currentUser = currentUser;
        this.milestoneRepo = milestoneRepo;
    }

    /** delegates add to real repository */
    @Override
    public void add(final Ticket item) {
        realRepo.add(item);
    }

    /** delegates remove to real repository */
    @Override
    public void remove(final Ticket item) {
        realRepo.remove(item);
    }

    /** delegates find by id to real repository */
    @Override
    public Optional<Ticket> findById(final Integer id) {
        return realRepo.findById(id);
    }

    /** returns filtered stream based on user role sorted by date and id */
    @Override
    public Stream<Ticket> findAll() {
        Stream<Ticket> stream = realRepo.findAll();

        // role-based filtering
        stream = applyRoleBasedFilter(stream);

        // sort
        return stream.sorted(Comparator.comparing(Ticket::getCreatedAt)
                .thenComparing(Ticket::getId));
    }

    /** applies filtering based on current user role */
    private Stream<Ticket> applyRoleBasedFilter(final Stream<Ticket> stream) {
        return switch (currentUser.getRole()) {
            case MANAGER ->
                    stream;
            case REPORTER -> stream.filter(t ->
                    t.getOfficialReporter().equals(currentUser.getUsername())
                            && t.getReportedBy() != null
                            && !t.getReportedBy().isEmpty());
            case DEVELOPER -> stream.filter(t ->
                    t.getStatus().equals(TicketConstants.TicketStatus.OPEN)
                            && t.inMilestone()
                            && isDevInMilestone(t.getMilestone()));
            default -> Stream.empty();
        };
    }

    /** checks if current developer is assigned to milestone */
    private boolean isDevInMilestone(final String milestoneName) {
        return milestoneRepo.findById(milestoneName)
                .map(milestone -> milestone.getAssignedDevs().contains(currentUser.getUsername()))
                .orElse(false);
    }
}
