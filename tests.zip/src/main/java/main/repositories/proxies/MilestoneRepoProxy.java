package main.repositories.proxies;

import main.entities.Milestone;
import main.entities.users.AbstractUser;
import main.entities.users.enums.UserRole;
import main.repositories.MilestoneRepo;
import main.repositories.Repository;
import main.repositories.TicketRepo;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.Optional;
import java.util.stream.Stream;

/** proxy repository for milestone access control filters by user role */
public class MilestoneRepoProxy extends Repository<Milestone, String> {
    private final MilestoneRepo realRepository;
    private final AbstractUser user;
    private final TicketRepo ticketRepo;

    /** constructs milestone proxy with repository user and ticket repo */
    public MilestoneRepoProxy(
            final MilestoneRepo realRepository, final AbstractUser user,
            final TicketRepo ticketRepo) {
        this.realRepository = realRepository;
        this.user = user;
        this.ticketRepo = ticketRepo;
    }

    /** delegates add to real repository */
    @Override
    public void add(final Milestone item) {
        realRepository.add(item);
    }

    /** delegates remove to real repository */
    @Override
    public void remove(final Milestone item) {
        realRepository.remove(item);
    }

    /** finds milestone by id filtered by user access */
    @Override
    public Optional<Milestone> findById(final String id) {
        return realRepository.findById(id)
                .filter(this::canAccess);
    }

    /** finds all milestones filtered by user access sorted by due date and name */
    @Override
    public Stream<Milestone> findAll() {
        return realRepository.findAll()
                .filter(this::canAccess)
                .sorted(Comparator
                        .comparing((final Milestone m) -> LocalDate.parse(m.getDueDate()))
                        .thenComparing(Milestone::getName));
    }

    /** checks if user can access milestone based on role */
    private boolean canAccess(final Milestone milestone) {
        if (user.getRole() == UserRole.MANAGER) {
            return milestone.getManager().equals(user.getUsername());
        } else if (user.getRole() == UserRole.DEVELOPER) {
            return milestone.getAssignedDevs().contains(user.getUsername());
        }
        return false;
    }
}
