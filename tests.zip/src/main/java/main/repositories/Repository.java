package main.repositories;

import java.util.Optional;
import java.util.stream.Stream;

/** abstract base repository provides crud operations for entities */
public abstract class Repository<T, I> {
    /** adds item to repository */
    public abstract void add(T item);
    /** removes item from repository */
    public abstract void remove(T item);
    /** finds item by id */
    public abstract Optional<T> findById(I id);
    /** returns stream of all items */
    public abstract Stream<T> findAll();
}
