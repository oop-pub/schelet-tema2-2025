package main.repositories;

import main.entities.Milestone;
import main.entities.tickets.Ticket;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Stream;

import static main.constants.TicketConstants.TicketStatus.CLOSED;

public class MilestoneRepo extends Repository<Milestone, String> {
    private final Map<String, Milestone> milestones;
    private final TicketRepo ticketRepo;
    public MilestoneRepo(final TicketRepo ticketRepo) {
        milestones = new HashMap<>();
        this.ticketRepo = ticketRepo;
    }

    /**
     * Adds a milestone.
     * @param item the milestone
     */
    @Override
    public void add(final Milestone item) {
        milestones.put(item.getName(), item);
    }

    /**
     * Removes a milestone.
     * @param item the milestone
     */
    @Override
    public void remove(final Milestone item) {
        milestones.remove(item.getName());
    }

    /**
     * Finds milestone by id.
     * @param id the milestone id
     * @return optional milestone
     */
    @Override
    public Optional<Milestone> findById(final String id) {
        return Optional.ofNullable(milestones.get(id));
    }

    /**
     * Finds all milestones.
     * @return stream of milestones
     */
    @Override
    public Stream<Milestone> findAll() {
        return milestones.values().stream();
    }

    /**
     * Gets milestones for a user.
     * @param username the username
     * @return list of milestones
     */
    public List<Milestone> getUserMilestones(final String username) {
        return milestones.values().stream()
                .filter(milestone -> milestone.getAssignedDevs().contains(username))
                .toList();
    }

    /**
     * Checks if there is an active milestone with open tickets.
     * @return true if active milestone exists
     */
    public boolean existsActiveMilestone() {
        for (Milestone milestone : milestones.values()) {
            Stream<Ticket> tickets = ticketRepo.findAll()
                    .filter(t -> t.getMilestone().equals(milestone.getName()))
                    .filter(t -> t.getStatus() != CLOSED);

            if (tickets.findAny().isPresent()) {
                return true;
            }
        }
        return false;
    }
}
