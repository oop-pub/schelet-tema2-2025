package main.repositories;

import main.entities.users.AbstractUser;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Stream;

/** repository for managing users with username as key */
public class UserRepo extends Repository<AbstractUser, String> {
    private Map<String, AbstractUser> users;

    /** constructs user repository with empty map */
    public UserRepo() {
        users = new HashMap<>();
    }

    /** adds user with username as key */
    @Override
    public void add(final AbstractUser item) {
        users.put(item.getUsername(), item);
    }

    /** removes user from repository */
    @Override
    public void remove(final AbstractUser item) {
        users.remove(item.getUsername());
    }

    /** finds user by username */
    @Override
    public Optional<AbstractUser> findById(final String id) {
        return Optional.ofNullable(users.get(id));
    }

    /** returns stream of all users */
    @Override
    public Stream<AbstractUser> findAll() {
        return users.values().stream();
    }

    /** adds multiple users to repository */
    public void addUsers(final List<AbstractUser> list) {
        for (AbstractUser user : list) {
            add(user);
        }
    }
}
