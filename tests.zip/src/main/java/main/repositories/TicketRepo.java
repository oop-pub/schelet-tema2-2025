package main.repositories;

import main.entities.tickets.Ticket;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Stream;

import static main.constants.TicketConstants.TicketStatus.OPEN;

/** repository for managing tickets with auto incrementing ids */
public class TicketRepo extends Repository<Ticket, Integer> {
    private final Map<Integer, Ticket> tickets;
    private Integer currentTicketId = 0;

    /** constructs ticket repository with empty map */
    public TicketRepo() {
        tickets = new HashMap<>();
    }

    /**
     * Gets current ticket ID.
     * @return current ticket ID
     */
    public Integer getCurrentTicketId() {
        return currentTicketId;
    }

    /** adds ticket and assigns auto incremented id */
    @Override
    public void add(final Ticket item) {
        item.setId(currentTicketId++);
        tickets.put(item.getId(), item);
    }

    /** removes ticket from repository */
    @Override
    public void remove(final Ticket item) {
        tickets.remove(item.getId());
    }

    /** finds ticket by id */
    @Override
    public Optional<Ticket> findById(final Integer id) {
        return Optional.ofNullable(tickets.get(id));
    }

    /** returns stream of all tickets */
    @Override
    public Stream<Ticket> findAll() {
        return tickets.values().stream();
    }

    /** finds all open tickets in milestones assigned to the given username */
    public List<Ticket> findOpenTicketsInUserMilestones(final String username,
                                                        final List<String> userMilestones) {
        return tickets.values().stream()
                .filter(ticket -> ticket.getStatus() == OPEN)
                .filter(ticket -> ticket.getMilestone() != null)
                .filter(ticket -> userMilestones.contains(ticket.getMilestone()))
                .toList();
    }
}
