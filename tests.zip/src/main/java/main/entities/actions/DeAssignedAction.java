package main.entities.actions;

import com.fasterxml.jackson.annotation.JsonProperty;

public record DeAssignedAction(
        String by,
        String timestamp
) implements Action {
    @Override
    @JsonProperty("action")
    public String action() {
        return "DE-ASSIGNED";
    }
}
