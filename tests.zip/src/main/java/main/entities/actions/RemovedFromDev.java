package main.entities.actions;

import com.fasterxml.jackson.annotation.JsonProperty;

public record RemovedFromDev(
        String from,
        String timestamp
) implements Action {
    @Override
    @JsonProperty("action")
    public String action() {
        return "REMOVED_FROM_DEV";
    }
    @JsonProperty("by")
    @Override
    public String by() {
        return "system";
    }

}
