package main.entities.actions;

import com.fasterxml.jackson.annotation.JsonProperty;

/** action record for adding ticket to milestone with milestone name user and timestamp */
public record AddedToMilestoneAction(
        String milestone,
        String by,
        String timestamp
) implements Action {
    @Override
    @JsonProperty("action")
    public String action() {
        return "ADDED_TO_MILESTONE";
    }
}
