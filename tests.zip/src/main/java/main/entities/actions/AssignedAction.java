package main.entities.actions;

import com.fasterxml.jackson.annotation.JsonProperty;

/** action record for ticket assignment with user and timestamp */
public record AssignedAction(
        String by,
        String timestamp
) implements Action {
    @Override
    @JsonProperty("action")
    public String action() {
        return "ASSIGNED";
    }
}
