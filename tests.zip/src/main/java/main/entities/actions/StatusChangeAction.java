package main.entities.actions;

import com.fasterxml.jackson.annotation.JsonProperty;

/** action record for ticket status change with from to states user and timestamp */
public record StatusChangeAction(
        String from,
        String to,
        String by,
        String timestamp
) implements Action {
    @Override
    @JsonProperty("action")
    public String action() {
        return "STATUS_CHANGED";
    }
}
