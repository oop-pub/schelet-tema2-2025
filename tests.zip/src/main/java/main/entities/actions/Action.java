package main.entities.actions;

/** sealed interface for ticket actions with polymorphic implementations */
public interface Action {
    /** @return action type */
    String action();
    /** @return user who performed action */
    String by();
    /** @return timestamp */
    String timestamp();
}
