package main.entities.tickets;

import lombok.Getter;
import lombok.Setter;
import main.constants.TicketConstants;
import main.server.metrics.MetricVisitor;

/** ui feedback ticket with element id business value and usability rating */
@Getter
@Setter
public class UIFeedback extends Ticket {
    // mandatory fields
    protected String uiElementId;
    protected TicketConstants.BusinessValue businessValue;
    protected Integer usabilityRating; // 1 to 10

    // optional fields
    protected String screenshotUrl;
    protected String suggestedFix;

    /** constructs ui feedback from builder with all required and optional fields */
    public UIFeedback(final String title,
                      final String businessPriority,
                      final String status,
                      final String reportedBy,
                      final String createdAt,
                      final String expertiseArea,
                      final String uiElementId,
                      final String businessValue,
                      final Integer usabilityRating,
                      final String officialReporter,
                      final String description,
                      final String screenshotUrl,
                      final String suggestedFix) {
        super(title, businessPriority, status, TicketConstants.TicketType.UI_FEEDBACK,
              reportedBy, createdAt, expertiseArea, officialReporter, description);
        this.uiElementId = uiElementId;
        this.businessValue = TicketConstants.BusinessValue.valueOf(businessValue.toUpperCase());
        this.usabilityRating = usabilityRating;
        this.screenshotUrl = screenshotUrl;
        this.suggestedFix = suggestedFix;
    }

    /**
     * Accept method for visitor pattern.
     * @param visitor the metric visitor
     * @return the result of the visit operation
     */
    @Override
    public double accept(final MetricVisitor visitor) {
        return visitor.visit(this);
    }
}
