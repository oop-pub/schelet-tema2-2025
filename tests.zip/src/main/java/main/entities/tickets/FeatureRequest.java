package main.entities.tickets;

import lombok.Getter;
import lombok.Setter;
import main.constants.TicketConstants;
import main.server.metrics.MetricVisitor;

/** feature request ticket with business value and customer demand */
@Getter
@Setter
public class FeatureRequest extends Ticket {
    // mandatory fields
    protected TicketConstants.BusinessValue businessValue;
    protected TicketConstants.CustomerDemand customerDemand;

    /** constructs feature request from builder with all required fields */
    public FeatureRequest(final String title,
                          final String businessPriority,
                          final String status,
                          final String reportedBy,
                          final String createdAt,
                          final String expertiseArea,
                          final String businessValue,
                          final String customerDemand,
                          final String officialReporter,
                          final String description) {
        super(title, businessPriority, status, TicketConstants.TicketType.FEATURE_REQUEST,
              reportedBy, createdAt, expertiseArea, officialReporter, description);
        this.businessValue = TicketConstants.BusinessValue.valueOf(businessValue.toUpperCase());
        this.customerDemand = TicketConstants.CustomerDemand.valueOf(customerDemand.toUpperCase());
    }

    /**
     * Accept method for visitor pattern.
     * @param visitor the metric visitor
     * @return the result of the visit operation
     */
    @Override
    public double accept(final MetricVisitor visitor) {
        return visitor.visit(this);
    }
}
