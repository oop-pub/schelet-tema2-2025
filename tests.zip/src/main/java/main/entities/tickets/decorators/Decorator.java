package main.entities.tickets.decorators;

import lombok.Getter;
import main.entities.tickets.Ticket;

@Getter
public abstract class Decorator {
    protected final Ticket ticket;
    public Decorator(final Ticket ticket) {
        this.ticket = ticket;
    }
}
