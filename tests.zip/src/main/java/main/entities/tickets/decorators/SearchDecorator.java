package main.entities.tickets.decorators;

import lombok.Getter;
import lombok.Setter;
import main.entities.tickets.Ticket;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.TreeSet;

@Getter
@Setter
public class SearchDecorator extends Decorator {
    private List<String> matchingWords;
    private boolean hasMatchingWords;

    public SearchDecorator(final Ticket ticket,
                           final boolean hasMatchingWords,
                           final List<String> wordsToMatch) {
        super(ticket);
        this.hasMatchingWords = hasMatchingWords;
        matchingWords = hasMatchingWords ? computeMatchingWords(wordsToMatch) : new ArrayList<>();
    }

    private List<String> computeMatchingWords(final List<String> wordsToMatch) {
        if (wordsToMatch == null || wordsToMatch.isEmpty()) {
            return Collections.emptyList();
        }

        String title = ticket.getTitle() == null ? "" : ticket.getTitle();
        String description = ticket.getDescription() == null ? "" : ticket.getDescription();
        String fullText = title + " " + description;

        TreeSet<String> matches = getStrings(wordsToMatch, fullText);

        return new ArrayList<>(matches);
    }

    private static TreeSet<String> getStrings(final List<String> wordsToMatch,
                                               final String fullText) {
        String[] words = fullText.split("\\s+");

        TreeSet<String> matches = new TreeSet<>();

        for (String keyword : wordsToMatch) {
            if (keyword == null || keyword.isEmpty()) {
                continue;
            }
            String lowerKeyword = keyword.toLowerCase();

            for (String word : words) {
                if (word == null || word.isEmpty()) {
                    continue;
                }
                String lowerWord = word.toLowerCase();
                if (lowerWord.contains(lowerKeyword)) {
                    matches.add(lowerWord);
                }
            }
        }
        return matches;
    }
}
