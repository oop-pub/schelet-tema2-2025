package main.entities.tickets;

import lombok.Getter;
import lombok.Setter;
import main.constants.TicketConstants;
import main.entities.actions.Action;
import main.server.metrics.MetricVisitable;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

/** abstract base ticket with common fields for all ticket types */
@Getter
@Setter
public abstract class Ticket implements MetricVisitable {
    // mandatory fields
    protected Integer id;
    protected String title;
    protected TicketConstants.BusinessPriority businessPriority;
    protected TicketConstants.TicketStatus status;
    protected TicketConstants.TicketType type;
    protected String reportedBy;
    protected String createdAt;
    protected TicketConstants.ExpertiseArea expertiseArea;
    protected String officialReporter;

    // empty by default
    protected List<Comment> comments;
    protected List<Action> actions;
    protected String assignee;
    protected String assignedAt;
    protected String solvedAt;
    protected String milestone;

    // optional field
    protected String description;

    // metric values
    protected double impactScore;
    protected double riskScore;
    protected double efficiencyScore;

    // used
    protected TicketConstants.BusinessPriority initialBusinessPriority;

    /** constructs ticket from builder with all common fields */
    protected Ticket(final String title,
                     final String businessPriority,
                     final String status,
                     final TicketConstants.TicketType type,
                     final String reportedBy,
                     final String createdAt,
                     final String expertiseArea,
                     final String officialReporter,
                     final String description) {
        this.title = title;
        this.businessPriority = TicketConstants.BusinessPriority
                .valueOf(businessPriority.toUpperCase());
        this.status = TicketConstants.TicketStatus
                .valueOf(status.toUpperCase());
        this.type = type;
        this.reportedBy = reportedBy;
        this.createdAt = createdAt;
        this.expertiseArea = TicketConstants.ExpertiseArea
                .valueOf(expertiseArea.toUpperCase());
        this.officialReporter = officialReporter;
        this.description = description;

        this.assignedAt = null;
        this.assignee = null;
        this.comments = new ArrayList<Comment>();
        this.solvedAt = null;
        this.milestone = null;
        this.actions = new ArrayList<Action>();

        this.impactScore = -1.0;
        this.riskScore = -1.0;
        this.efficiencyScore = -1.0;
        this.initialBusinessPriority = TicketConstants.BusinessPriority
                .valueOf(businessPriority.toUpperCase());
    }

    /** checks equality based on ticket id */
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Ticket ticket = (Ticket) o;

        return id == ticket.id;
    }

    /** returns hash code based on ticket id */
    @Override
    public int hashCode() {
        return Integer.hashCode(id);
    }

    /** checks if ticket is assigned to a milestone */
    public boolean inMilestone() {
        return this.milestone != null && !this.milestone.isEmpty();
    }

    /**
     * Returns the number of days taken to resolve the ticket.
     * @return days to resolve or -1 if not yet solved
     */
    public int getDaysToResolve() {
        if (this.solvedAt == null) {
            return -1;
        }

        LocalDate assigned = LocalDate.parse(this.assignedAt);
        LocalDate solved = LocalDate.parse(this.solvedAt);

        return (int) Math.max(0, ChronoUnit.DAYS.between(assigned, solved) + 1);
    }
}
