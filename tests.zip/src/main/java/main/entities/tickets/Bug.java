package main.entities.tickets;

import lombok.Getter;
import lombok.Setter;
import main.constants.TicketConstants;
import main.server.metrics.MetricVisitor;

/** bug ticket with expected and actual behavior frequency and severity */
@Getter
@Setter
public class Bug extends Ticket {
    protected String expectedBehavior;
    protected String actualBehavior;
    protected TicketConstants.BugFrequency frequency;
    protected TicketConstants.BugSeverity severity;

    // optional fields
    protected String environment;
    protected Integer errorCode;

    /** constructs bug from builder with all required and optional fields */
    public Bug(final String title,
               final String businessPriority,
               final String status,
               final String reportedBy,
               final String createdAt,
               final String expertiseArea,
               final String expectedBehavior,
               final String actualBehavior,
               final String frequency,
               final String severity,
               final String officialReporter,
               final String description,
               final String environment,
               final Integer errorCode) {
        super(title, businessPriority, status, TicketConstants.TicketType.BUG,
              reportedBy, createdAt, expertiseArea, officialReporter, description);
        this.expectedBehavior = expectedBehavior;
        this.actualBehavior = actualBehavior;
        this.frequency = TicketConstants.BugFrequency.valueOf(frequency.toUpperCase());
        this.severity = TicketConstants.BugSeverity.valueOf(severity.toUpperCase());
        this.environment = environment;
        this.errorCode = errorCode;
    }

    /**
     * Accept method for visitor pattern.
     * @param visitor the metric visitor
     * @return the result of the visit operation
     */
    @Override
    public double accept(final MetricVisitor visitor) {
        return visitor.visit(this);
    }
}
