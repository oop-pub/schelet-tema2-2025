package main.entities.tickets;

public record Comment(
        String author,
        String content,
        String createdAt
) { }
