package main.entities.users;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;
import main.entities.users.enums.ExpertiseArea;
import main.entities.users.enums.Seniority;
import main.entities.users.enums.UserRole;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import static main.entities.users.enums.UserRole.DEVELOPER;

/** developer user with seniority and expertise area for ticket assignment */
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class Developer extends AbstractUser {
    protected Seniority seniority;
    protected ExpertiseArea expertiseArea;
    protected String hireDate;
    protected double performanceScore;
    private List<String> notifications;

    public Developer() {
        super();
        this.notifications = new ArrayList<>();
    }

    /** returns developer role */
    @Override
    public UserRole getRole() {
        return DEVELOPER;
    }

    /**
     * Gets the performance score.
     * @return performance score
     */
    @Override
    public double getPerformanceScore() {
        return performanceScore;
    }

    /**
     * Updates with a new notification.
     * @param notification the notification message
     */
    @Override
    public void update(final String notification) {
        notifications.add(notification);
    }

    /**
     * Clears all notifications.
     */
    @Override
    public void clearNotifications() {
        notifications.clear();
    }

    /**
     * Returns an unmodifiable view of notifications for this developer.
     * @return notifications list
     */
    public List<String> getNotifications() {
        return Collections.unmodifiableList(notifications);
    }

    /**
     * Gets subordinates (not supported for developers).
     * @return throws UnsupportedOperationException
     */
    @Override
    public Set<String> getSubordinates() {
        throw new UnsupportedOperationException("Developer does not have subordinates.");
    }
}
