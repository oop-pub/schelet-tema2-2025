package main.entities.users;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;
import main.entities.Milestone;
import main.entities.users.enums.Seniority;
import main.entities.users.enums.UserRole;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static main.entities.users.enums.Seniority.LEAD;
import static main.entities.users.enums.UserRole.MANAGER;

/** manager user with subordinates who can create milestones */
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class Manager extends AbstractUser {
    protected String hireDate;
    protected Set<String> subordinates;
    protected List<Milestone> milestones;

    /** returns manager role */
    @Override
    public UserRole getRole() {
        return MANAGER;
    }

    /**
     * Gets performance score (not supported for managers).
     * @return throws UnsupportedOperationException
     */
    @Override
    public double getPerformanceScore() {
        throw new UnsupportedOperationException("Manager does not have performance score.");
    }

    /**
     * Sets performance score (not supported for managers).
     * @param n the score value
     */
    @Override
    public void setPerformanceScore(final double n) {
        throw new UnsupportedOperationException("Manager does not have performance score.");
    }

    /**
     * Gets notifications.
     * @return empty list
     */
    @Override
    public List<String> getNotifications() {
        return new ArrayList<>();
    }

    /**
     * Clears notifications.
     */
    @Override
    public void clearNotifications() {
        return;
    }

    /**
     * Gets seniority level.
     * @return LEAD seniority
     */
    @Override
    public Seniority getSeniority() {
        return LEAD;
    }

    /**
     * Updates with notification (no-op for managers).
     * @param notification the notification message
     */
    @Override
    public void update(final String notification) {
        return;
    }

    /**
     * Gets subordinates.
     * @return set of subordinate usernames
     */
    @Override
    public Set<String> getSubordinates() {
        return new HashSet<>(subordinates);
    }

}
