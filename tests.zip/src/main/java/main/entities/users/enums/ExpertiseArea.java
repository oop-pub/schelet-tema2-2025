package main.entities.users.enums;

public enum ExpertiseArea {
    FRONTEND, BACKEND, FULLSTACK, DEVOPS, DESIGN, DB
}
