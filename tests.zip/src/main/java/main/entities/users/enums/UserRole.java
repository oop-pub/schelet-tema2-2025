package main.entities.users.enums;

public enum UserRole {
    DEVELOPER, MANAGER, REPORTER
}
