package main.entities.users.enums;

public enum Seniority {
    JUNIOR, MID, SENIOR, LEAD, NOT_SPECIFIED
}
