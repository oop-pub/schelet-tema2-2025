package main.entities.users;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import lombok.Getter;
import lombok.Setter;
import main.entities.users.enums.Seniority;
import main.entities.users.enums.UserRole;
import main.server.notifications.Observer;

import java.util.List;
import java.util.Set;


/** abstract base class for all user types */
@Getter
@Setter
@JsonTypeInfo(
        use = JsonTypeInfo.Id.NAME,
        include = JsonTypeInfo.As.EXISTING_PROPERTY,
        property = "role",
        visible = true
)
@JsonSubTypes({
        @JsonSubTypes.Type(value = Developer.class, name = "DEVELOPER"),
        @JsonSubTypes.Type(value = Manager.class,   name = "MANAGER"),
        @JsonSubTypes.Type(value = Reporter.class,  name = "REPORTER")
})
public abstract class AbstractUser implements Observer {
    protected String username;
    protected String email;

    /** checks equality based on username */
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof AbstractUser that)) {
            return false;
        }
        return username.equals(that.username);
    }

    /** returns hash code based on username */
    @Override
    public int hashCode() {
        return username.hashCode();
    }

    /** returns the role of the user */
    public abstract UserRole getRole();

    /**
     * Returns the performance score for the user.
     * @return performance score
     */
    public abstract double getPerformanceScore();

    /**
     * Sets the performance score for the user.
     * @param score the new performance score
     */
    public abstract void setPerformanceScore(double score);

    /**
     * Returns notifications for the user.
     * @return list of notifications
     */
    public abstract List<String> getNotifications();

    /** Clears notifications for the user. */
    public abstract void clearNotifications();

    /** Returns the seniority of the user. */
    public abstract Seniority getSeniority();

    /** Returns subordinates of the user. */
    public abstract Set<String> getSubordinates();


}
