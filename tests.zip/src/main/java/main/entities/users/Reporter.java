package main.entities.users;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;
import main.entities.users.enums.Seniority;
import main.entities.users.enums.UserRole;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static main.entities.users.enums.Seniority.NOT_SPECIFIED;
import static main.entities.users.enums.UserRole.REPORTER;

/** reporter user who can report tickets and track reported issues */
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class Reporter extends AbstractUser {
    protected Set<Integer> reportedIssues = new HashSet<>();

    /** returns reporter role */
    @Override
    public UserRole getRole() {
        return REPORTER;
    }

    /**
     * Gets performance score (not supported for reporters).
     * @return throws UnsupportedOperationException
     */
    @Override
    public double getPerformanceScore() {
        throw new UnsupportedOperationException("Reporters do not have a performance score.");
    }

    /**
     * Sets performance score (not supported for reporters).
     * @param n the score value
     */
    @Override
    public void setPerformanceScore(final double n) {
        throw new UnsupportedOperationException("Reporter does not have performance score.");
    }

    /**
     * Gets notifications.
     * @return empty list
     */
    @Override
    public List<String> getNotifications() {
        return new ArrayList<>();
    }

    /**
     * Clears notifications.
     */
    @Override
    public void clearNotifications() {
        return;
    }

    /**
     * Gets seniority level.
     * @return NOT_SPECIFIED
     */
    @Override
    public Seniority getSeniority() {
        return NOT_SPECIFIED;
    }

    /**
     * Updates with notification (no-op for reporters).
     * @param notification the notification message
     */
    @Override
    public void update(final String notification) {
        return;
    }

    /**
     * Gets subordinates (not supported for reporters).
     * @return throws UnsupportedOperationException
     */
    @Override
    public Set<String> getSubordinates() {
        throw new UnsupportedOperationException("Reporters do not have subordinates.");
    }
}
