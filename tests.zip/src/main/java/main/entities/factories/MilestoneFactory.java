package main.entities.factories;

import main.commands.milestones.CreateMsCmd;
import main.entities.Milestone;

import java.util.ArrayList;

/** factory for creating milestone entities from commands */
public final class MilestoneFactory {
    private MilestoneFactory() {
        // Utility class
    }


    /** creates milestone entity from create milestone command */
    public static Milestone create(final CreateMsCmd cmd) {
        return new Milestone(
                cmd.getName(),
                cmd.getTimestamp(),
                cmd.getUsername(),
                new ArrayList<>(cmd.getBlockingFor()),
                cmd.getTickets(),
                new ArrayList<>(cmd.getAssignedDevs()),
                cmd.getDueDate()
        );
    }
}
