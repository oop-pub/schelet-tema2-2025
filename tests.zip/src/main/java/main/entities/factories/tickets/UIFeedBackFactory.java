package main.entities.factories.tickets;

import main.commands.tickets.ReportTicketCmd;
import main.entities.tickets.Ticket;
import main.entities.tickets.UIFeedback;

/** factory for creating ui feedback ticket entities */
public final class UIFeedBackFactory implements TicketFactory {

    /**
     * Creates UI feedback ticket from report command.
     * @param cmd the report ticket command
     * @return the created ticket
     */
    @Override
    public Ticket create(final ReportTicketCmd cmd) {
        var p = cmd.getParams();
        return new UIFeedback(
                p.getTitle(),
                p.getBusinessPriority(),
                "OPEN",
                p.getReportedBy(),
                cmd.getTimestamp(),
                p.getExpertiseArea(),
                p.getUiElementId(),
                p.getBusinessValue(),
                p.getUsabilityScore(),
                cmd.getUsername(),
                p.getDescription(),
                p.getScreenshotUrl(),
                p.getSuggestedFix()
        );
    }
}
