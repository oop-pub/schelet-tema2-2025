package main.entities.factories.tickets;

import main.commands.tickets.ReportTicketCmd;
import main.entities.tickets.Ticket;

/** interface for ticket factory implementations */
public interface TicketFactory {
    /**
     * Creates a ticket from report command.
     * @param data the report ticket command
     * @return the created ticket
     */
    Ticket create(ReportTicketCmd data);
}
