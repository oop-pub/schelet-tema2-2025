package main.entities.factories.tickets;

import main.commands.tickets.ReportTicketCmd;
import main.entities.tickets.Ticket;

/** abstract factory for creating ticket entities based on type */
public final class AbsFactory {
    private AbsFactory() {
        // Utility class
    }

    private static final BugFactory BUG_FACTORY = new BugFactory();
    private static final UIFeedBackFactory UI_FEEDBACK_FACTORY = new UIFeedBackFactory();
    private static final FeatureRequestFactory FEATURE_REQUEST_FACTORY =
            new FeatureRequestFactory();

    /** creates ticket entity from report command based on ticket type */
    public static Ticket create(final ReportTicketCmd data) {
        return switch (data.getParams().getType().toUpperCase()) {
            case "BUG" -> BUG_FACTORY.create(data);
            case "UI_FEEDBACK" -> UI_FEEDBACK_FACTORY.create(data);
            case "FEATURE_REQUEST" -> FEATURE_REQUEST_FACTORY.create(data);
            default -> throw new IllegalArgumentException("Invalid ticket type"
                    + data.getParams().getType());
        };
    }

}
