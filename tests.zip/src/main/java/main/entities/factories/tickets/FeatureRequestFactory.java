package main.entities.factories.tickets;

import main.commands.tickets.ReportTicketCmd;
import main.entities.tickets.FeatureRequest;
import main.entities.tickets.Ticket;

/** factory for creating feature request ticket entities */
public class FeatureRequestFactory implements TicketFactory {

    /** creates feature request ticket from report command using builder pattern */
    @Override
    public Ticket create(final ReportTicketCmd cmd) {
        var p = cmd.getParams();
        return new FeatureRequest(
                p.getTitle(),
                p.getBusinessPriority(),
                "OPEN",
                p.getReportedBy(),
                cmd.getTimestamp(),
                p.getExpertiseArea(),
                p.getBusinessValue(),
                p.getCustomerDemand(),
                cmd.getUsername(),
                p.getDescription()
        );
    }
}
