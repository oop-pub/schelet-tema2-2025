package main.entities.factories.tickets;

import main.commands.tickets.ReportTicketCmd;
import main.entities.tickets.Bug;
import main.entities.tickets.Ticket;

/** factory for creating bug ticket entities */
public class BugFactory implements TicketFactory {

    /** creates bug ticket from report command using builder pattern */
    @Override
    public Ticket create(final ReportTicketCmd cmd) {
        var p = cmd.getParams();
        return new Bug(
                p.getTitle(),
                p.getBusinessPriority(),
                "OPEN",
                p.getReportedBy(),
                cmd.getTimestamp(),
                p.getExpertiseArea(),
                p.getExpectedBehavior(),
                p.getActualBehavior(),
                p.getFrequency(),
                p.getSeverity(),
                cmd.getUsername(),
                p.getDescription(),
                p.getEnvironment(),
                p.getErrorCode()
        );
    }
}
