package main.entities;

import lombok.Getter;
import lombok.Setter;
import main.constants.TicketConstants.BusinessPriority;
import main.constants.TicketConstants.TicketStatus;
import main.server.notifications.Notification;
import main.server.notifications.Observer;
import main.server.notifications.Subject;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static main.constants.Constants.NotificationType.DEADLINE_APPROACHING;

/** milestone entity manages tickets grouped under a deadline with priority escalation */
@Getter
@Setter
public class Milestone implements Subject {
    protected String name;
    protected boolean blocked;
    protected boolean completed;
    protected String createdAt;
    protected String completedAt;
    protected String dueDate;
    protected String manager;

    protected List<String> blockingFor;
    protected List<Integer> tickets;
    protected List<String> assignedDevs;
    protected Map<String, List<Integer>> ticketMap;

    protected boolean inactive = false;
    protected Integer frozenDaysUntilDue = null;
    protected Integer frozenOverdueBy = null;
    protected String inactiveSince = null;
    protected boolean dayBeforeDdlNotification = false;

    protected Map<Integer, String> lastEscalationDate = new HashMap<>();

    // 2 types of observers: assigned developers and blocked milestone watchers
    private List<Observer> observers = new ArrayList<>();

    /** constructs milestone with name dates manager dependencies tickets and assigned developers */
    public Milestone(final String name,
                     final String createdAt,
                     final String manager,
                     final List<String> blockingFor,
                     final List<Integer> tickets,
                     final List<String> assignedDevs,
                     final String dueDate) {
        this.name = name;
        this.blocked = false;
        this.completed = false;
        this.createdAt = createdAt;
        this.manager = manager;
        this.blockingFor = new ArrayList<>(blockingFor);
        this.tickets = new ArrayList<>(tickets);
        this.assignedDevs = new ArrayList<>(assignedDevs);
        this.dueDate = dueDate;
        this.ticketMap = new HashMap<>();
        for (String dev : assignedDevs) {
            this.ticketMap.put(dev, new ArrayList<>());
        }
        this.completedAt = null;

        // initialize escalation tracking for each ticket starting from milestone creation date
        for (Integer ticketId : tickets) {
            this.lastEscalationDate.put(ticketId, createdAt);
        }
    }

    /**
     * Updates inactive status and freezes days until due
     * and overdue values when all tickets are closed.
     */
    private void updateInactiveStatus(final Map<Integer, TicketStatus> ticketStatusMap,
                                      final String currentDate) {
        boolean allClosed = tickets.stream()
                .allMatch(id -> TicketStatus.CLOSED.equals(ticketStatusMap.get(id)));
        if (allClosed && !inactive) {
            inactive = true;
            inactiveSince = currentDate;
            frozenDaysUntilDue = calculateDaysUntilDue(currentDate);
            frozenOverdueBy = calculateOverdueBy(currentDate);
        }
    }

    /** returns days until due frozen if inactive or calculated if active */
    public int getDaysUntilDue(final String currentDate) {
        return inactive ? frozenDaysUntilDue : calculateDaysUntilDue(currentDate);
    }

    /** returns overdue days frozen if inactive or calculated if active */
    public int getOverdueBy(final String currentDate) {
        return inactive ? frozenOverdueBy : calculateOverdueBy(currentDate);
    }

    /** calculates days until due date returns zero if overdue */
    private int calculateDaysUntilDue(final String currentDate) {
        LocalDate now = LocalDate.parse(currentDate);
        LocalDate due = LocalDate.parse(dueDate);
        return Math.max(0, (int) ChronoUnit.DAYS.between(now, due) + 1);
    }

    /** calculates days past due date returns zero if not overdue */
    private int calculateOverdueBy(final String currentDate) {
        LocalDate now = LocalDate.parse(currentDate);
        LocalDate due = LocalDate.parse(dueDate);
        return Math.max(0, (int) ChronoUnit.DAYS.between(due, now) + 1);
    }

    private static final int ESCALATION_DAYS = 3;

    /**
     * Escalates ticket business priority by one step every three days
     * if milestone not blocked and ticket not closed.
     */
    private void escalateBusinessPriority(
            final Map<Integer, BusinessPriority> ticketPriorityMap,
            final Map<Integer, TicketStatus> ticketStatusMap,
            final String currentDate) {
        if (blocked) {
            return;
        }

        for (Integer id : tickets) {
            // skip closed tickets
            TicketStatus status = ticketStatusMap.get(id);
            if (TicketStatus.CLOSED.equals(status)) {
                continue;
            }

            BusinessPriority bp = ticketPriorityMap.get(id);
            if (bp == null || bp == BusinessPriority.CRITICAL) {
                continue;
            }

            // get the reference date for this ticket (either initial date or last escalation date)
            String referenceDate = lastEscalationDate.get(id);
            if (referenceDate == null) {
                // if ticket was added later, initialize it with current date
                lastEscalationDate.put(id, currentDate);
                continue;
            }

            long days = ChronoUnit.DAYS.between(LocalDate.parse(referenceDate),
                    LocalDate.parse(currentDate));
            if (days < ESCALATION_DAYS) {
                continue; // no escalation if less than 3 days have passed since last escalation
            }

            int steps = (int) (days / ESCALATION_DAYS);
            if (steps == 0) {
                continue; // no escalation if less than 3 days have passed
            }

            // escalate by the number of 3-day periods that have passed
            int newOrdinal = bp.ordinal() + steps;

            // clamp to valid range
            if (newOrdinal > BusinessPriority.CRITICAL.ordinal()) {
                newOrdinal = BusinessPriority.CRITICAL.ordinal();
            }

            // update the priority and track this escalation
            ticketPriorityMap.put(id, BusinessPriority.values()[newOrdinal]);
            lastEscalationDate.put(id, currentDate);
        }
    }

    /**
     * Sets all non-closed ticket priorities to critical if milestone
     * is one day before due or overdue.
     */
    private void setAllCriticalIfDue(
            final Map<Integer, BusinessPriority> ticketPriorityMap,
            final Map<Integer, TicketStatus> ticketStatusMap,
            final String currentDate) {
        LocalDate now = LocalDate.parse(currentDate);
        LocalDate due = LocalDate.parse(dueDate);

        // check if milestone is due tomorrow or was due and send notification
        if (now.equals(due.minusDays(1)) && !dayBeforeDdlNotification && !blocked) {
            notifyObservers(new Notification(
                    DEADLINE_APPROACHING,
                    String.format("Milestone %s is due tomorrow. "
                            + "All unresolved tickets are now CRITICAL.", name)
            ));
            dayBeforeDdlNotification = true;
        }

        if (!now.isBefore(due.minusDays(1))) {
            for (Integer id : tickets) {
                // skip closed tickets
                TicketStatus status = ticketStatusMap.get(id);
                if (!TicketStatus.CLOSED.equals(status)) {
                    ticketPriorityMap.put(id, BusinessPriority.CRITICAL);
                }
            }
        }
    }

    /** updates milestone state and ticket priorities based on current date */
    public void update(final Map<Integer, TicketStatus> ticketStatusMap,
                       final Map<Integer, BusinessPriority> ticketPriorityMap,
                       final String currentDate) {
        // update inactive status first
        updateInactiveStatus(ticketStatusMap, currentDate);

        // only update priorities if not inactive
        if (!inactive) {
            escalateBusinessPriority(ticketPriorityMap, ticketStatusMap, currentDate);
            setAllCriticalIfDue(ticketPriorityMap, ticketStatusMap, currentDate);
        }
    }

    /**
     * Checks if milestone is active.
     * @return true if not completed
     */
    public final boolean isActive() {
        return !completed;
    }

    /**
     * Attaches an observer to this milestone.
     * @param observer the observer to attach
     */
    @Override
    public final void attach(final Observer observer) {
        observers.add(observer);
    }

    /**
     * Notifies observers based on notification type.
     * @param notification the notification to send
     */
    @Override
    public final void notifyObservers(final Notification notification) {
        switch (notification.getType()) {
            case MILESTONE_CREATED, DEADLINE_APPROACHING ->
                    getAssignedObservers().forEach(t ->
                            t.update(notification.getMessage()));
            case UNBLOCKED, UNBLOCKED_AFTER_DEADLINE ->
                    getBlockedObservers().forEach(t ->
                            t.update(notification.getMessage()));
            default -> {
                // No action for other notification types
            }
        }

    }

    private List<Observer> getAssignedObservers() {
        return observers.stream().filter(obs -> assignedDevs.contains(obs.getUsername())).toList();
    }

    private List<Observer> getBlockedObservers() {
        return observers.stream()
                .filter(obs -> !(assignedDevs.contains(obs.getUsername())))
                .toList();
    }
}
