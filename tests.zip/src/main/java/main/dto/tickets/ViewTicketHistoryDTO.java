package main.dto.tickets;

import main.dto.BaseDTO;

import java.util.List;

public record ViewTicketHistoryDTO(
        String command,
        String username,
        String timestamp,
        List<TicketHistoryItemDTO> ticketHistory
) implements BaseDTO { }

