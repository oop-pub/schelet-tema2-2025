package main.dto.tickets;

import main.entities.actions.Action;

import java.util.List;

public record TicketHistoryItemDTO(
        Integer id,
        String title,
        String status,
        List<Action> actions,
        List<CommentDTO> comments
) { }
