package main.dto.tickets;

import main.dto.BaseDTO;

import java.util.List;

public record ViewTicketDTO(
        String command,
        String username,
        String timestamp,
        List<TicketDTO> tickets
) implements BaseDTO { }
