package main.dto.tickets.actions;

public record AddedToMilestoneActionDTO(
        String by,
        String timestamp,
        String milestone
) implements ActionDTO { }

