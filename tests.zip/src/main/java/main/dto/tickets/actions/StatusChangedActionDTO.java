package main.dto.tickets.actions;

import com.fasterxml.jackson.annotation.JsonProperty;

public record StatusChangedActionDTO(
        @JsonProperty("from") String from,
        @JsonProperty("to") String to,
        String by,
        String timestamp
) implements ActionDTO { }

