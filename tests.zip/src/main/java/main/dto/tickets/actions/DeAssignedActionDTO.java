package main.dto.tickets.actions;

public record DeAssignedActionDTO(
        String by,
        String timestamp
) implements ActionDTO { }

