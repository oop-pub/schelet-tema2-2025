package main.dto.tickets.actions;

public record AssignedActionDTO(
        String by,
        String timestamp
) implements ActionDTO { }

