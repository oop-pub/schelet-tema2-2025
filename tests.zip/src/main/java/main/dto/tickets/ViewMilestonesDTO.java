package main.dto.tickets;

import main.dto.BaseDTO;
import main.dto.milestones.MilestoneDTO;

import java.util.List;

public record ViewMilestonesDTO(
        String command,
        String username,
        String timestamp,
        List<MilestoneDTO> milestones
) implements BaseDTO { }
