package main.dto.tickets;

public record CommentDTO(
        String author,
        String content,
        String createdAt
) { }
