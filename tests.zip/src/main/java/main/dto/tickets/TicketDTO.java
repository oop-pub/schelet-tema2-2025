package main.dto.tickets;

import java.util.List;

public record TicketDTO(
        int id,
        String type,
        String title,
        String businessPriority,
        String status,
        String createdAt,
        String assignedAt,
        String solvedAt,
        String assignedTo,
        String reportedBy,
        List<CommentDTO> comments
) { }
