package main.dto.tickets;

import main.dto.ActionDTO;

/**
 * dto for de-assigned action in ticket history.
 */
public record DeAssignedActionDTO(
        String by,
        String timestamp
) implements ActionDTO { }

