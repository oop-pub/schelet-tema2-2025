package main.dto.tickets;

import main.dto.BaseDTO;

import java.util.List;

public record ViewNotificationsDTO(
        String command,
        String username,
        String timestamp,
        List<String> notifications
) implements BaseDTO { }



