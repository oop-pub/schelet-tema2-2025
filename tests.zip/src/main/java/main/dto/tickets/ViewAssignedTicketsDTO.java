package main.dto.tickets;

import main.dto.BaseDTO;

import java.util.List;

public record ViewAssignedTicketsDTO(
        String command,
        String username,
        String timestamp,
        List<AssignedTicketDTO> assignedTickets
) implements BaseDTO { }
