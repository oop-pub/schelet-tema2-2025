package main.dto.tickets;

import com.fasterxml.jackson.annotation.JsonProperty;
import main.dto.ActionDTO;

/**
 * dto for status changed action in ticket history.
 * includes the previous status and new status.
 */
public record StatusChangedActionDTO(
        @JsonProperty("from") String from,
        @JsonProperty("to") String to,
        String by,
        String timestamp
) implements ActionDTO { }

