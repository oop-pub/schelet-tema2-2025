package main.dto.tickets;

public record TicketCommentDTO(
        String author,
        String timestamp,
        String message
) { }

