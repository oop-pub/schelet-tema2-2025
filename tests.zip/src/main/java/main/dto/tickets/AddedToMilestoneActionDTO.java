package main.dto.tickets;

import main.dto.ActionDTO;

/**
 * dto for added to milestone action in ticket history.
 */
public record AddedToMilestoneActionDTO(
        String by,
        String timestamp,
        String milestone
) implements ActionDTO { }

