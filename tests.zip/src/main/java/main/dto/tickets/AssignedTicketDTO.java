package main.dto.tickets;

import java.util.List;

public record AssignedTicketDTO(
        int id,
        String type,
        String title,
        String businessPriority,
        String status,
        String createdAt,
        String assignedAt,
        String reportedBy,
        List<CommentDTO> comments
) { }

