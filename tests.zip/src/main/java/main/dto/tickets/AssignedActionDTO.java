package main.dto.tickets;

import main.dto.ActionDTO;

/**
 * dto for assigned action in ticket history.
 */
public record AssignedActionDTO(
        String by,
        String timestamp
) implements ActionDTO { }

