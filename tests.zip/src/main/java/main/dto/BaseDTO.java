package main.dto;

public interface BaseDTO {
    /** @return command name */
    String command();
    /** @return username */
    String username();
    /** @return timestamp */
    String timestamp();
}
