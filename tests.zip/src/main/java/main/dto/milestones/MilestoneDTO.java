package main.dto.milestones;

import java.util.List;

public record MilestoneDTO(
        String name,
        List<String> blockingFor,
        String dueDate,
        String createdAt,
        List<Integer> tickets,
        List<String> assignedDevs,
        String createdBy,
        String status,
        boolean isBlocked,
        int daysUntilDue,
        int overdueBy,
        List<Integer> openTickets,
        List<Integer> closedTickets,
        double completionPercentage,
        List<RepartitionDTO> repartition
) { }
