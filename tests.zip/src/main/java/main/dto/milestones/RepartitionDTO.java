package main.dto.milestones;

import java.util.List;

public record RepartitionDTO(
        String developer,
        List<Integer> assignedTickets
) { }
