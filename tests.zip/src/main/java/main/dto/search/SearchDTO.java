package main.dto.search;

import main.dto.BaseDTO;

import java.util.List;

// dto for search command results with searchType
public record SearchDTO(
        String command,
        String username,
        String timestamp,
        String searchType,
        List<ItemSearchDTO> results
) implements BaseDTO { }
