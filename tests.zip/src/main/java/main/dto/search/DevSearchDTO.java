package main.dto.search;

// dto for developer search results
public record DevSearchDTO(
        String username,
        String expertiseArea,
        String seniority,
        Double performanceScore,
        String hireDate
) implements ItemSearchDTO { }
