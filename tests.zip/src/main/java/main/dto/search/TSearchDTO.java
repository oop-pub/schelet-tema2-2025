package main.dto.search;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;

// dto for ticket search results
public record TSearchDTO(
        Integer id,
        String type,
        String title,
        String businessPriority,
        String status,
        String createdAt,
        String solvedAt,
        String reportedBy,
        @JsonInclude(JsonInclude.Include.NON_NULL)
        List<String> matchingWords
) implements ItemSearchDTO { }
