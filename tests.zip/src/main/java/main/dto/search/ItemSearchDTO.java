package main.dto.search;

public interface ItemSearchDTO {
}
