package main.dto;

public record ErrorDTO(
        String command,
        String username,
        String timestamp,
        String error
) implements BaseDTO { }
