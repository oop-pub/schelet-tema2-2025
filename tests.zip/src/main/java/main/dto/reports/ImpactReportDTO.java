package main.dto.reports;

import java.util.Map;

public record ImpactReportDTO(
        int totalTickets,
        Map<String, Integer> ticketsByType,
        Map<String, Integer> ticketsByPriority,
        Map<String, Double> customerImpactByType
) { }
