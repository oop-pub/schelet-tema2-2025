package main.dto.reports;

import main.constants.Constants;

import java.util.Map;

public record StabilityReportDTO(
        int totalOpenTickets,
        Map<String, Integer> openTicketsByType,
        Map<String, Integer> openTicketsByPriority,
        Map<String, Constants.Risk> riskByType,
        Map<String, Double> impactByType,
        String appStability
) { }
