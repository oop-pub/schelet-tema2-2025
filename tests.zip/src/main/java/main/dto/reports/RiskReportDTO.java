package main.dto.reports;

import main.constants.Constants;

import java.util.Map;

public record RiskReportDTO(
        int totalTickets,
        Map<String, Integer> ticketsByType,
        Map<String, Integer> ticketsByPriority,
        Map<String, Constants.Risk> riskByType
) { }
