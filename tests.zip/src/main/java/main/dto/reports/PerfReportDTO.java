package main.dto.reports;


public record PerfReportDTO(
        String username,
        Integer closedTickets,
        Double averageResolutionTime,
        Double performanceScore,
        String seniority
) { }
