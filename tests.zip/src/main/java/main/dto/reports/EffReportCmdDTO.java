package main.dto.reports;

import main.dto.BaseDTO;

public record EffReportCmdDTO(
        String command,
        String username,
        String timestamp,
        EffReportDTO report
) implements BaseDTO { }
