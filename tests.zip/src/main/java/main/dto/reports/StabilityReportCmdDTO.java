package main.dto.reports;

import main.dto.BaseDTO;

public record StabilityReportCmdDTO(
        String command,
        String username,
        String timestamp,
        StabilityReportDTO report
) implements BaseDTO { }
