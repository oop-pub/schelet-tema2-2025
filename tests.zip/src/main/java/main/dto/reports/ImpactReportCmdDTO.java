package main.dto.reports;

import main.dto.BaseDTO;

public record ImpactReportCmdDTO(
        String command,
        String username,
        String timestamp,
        ImpactReportDTO report
) implements BaseDTO { }
