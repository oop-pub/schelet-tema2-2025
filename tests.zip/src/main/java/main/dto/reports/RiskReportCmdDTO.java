package main.dto.reports;

import main.dto.BaseDTO;

public record RiskReportCmdDTO(
        String command,
        String username,
        String timestamp,
        RiskReportDTO report
) implements BaseDTO { }
