package main.dto.reports;

import main.dto.BaseDTO;

import java.util.List;


public record PerfReportCmdDTO(
        String command,
        String username,
        String timestamp,
        List<PerfReportDTO> report
) implements BaseDTO { }
