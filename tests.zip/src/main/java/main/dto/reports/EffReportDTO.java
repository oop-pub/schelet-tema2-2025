package main.dto.reports;

import java.util.Map;

public record EffReportDTO(
        int totalTickets,
        Map<String, Integer> ticketsByType,
        Map<String, Integer> ticketsByPriority,
        Map<String, Double> efficiencyByType
) { }
