package main.dto;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import main.dto.tickets.AddedToMilestoneActionDTO;
import main.dto.tickets.AssignedActionDTO;
import main.dto.tickets.DeAssignedActionDTO;
import main.dto.tickets.StatusChangedActionDTO;

/**
 * base interface for action DTOs in ticket history.
 * uses polymorphic serialization to handle different action types.
 */
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, property = "action")
@JsonSubTypes({
        @JsonSubTypes.Type(value = AssignedActionDTO.class, name = "ASSIGNED"),
        @JsonSubTypes.Type(value = DeAssignedActionDTO.class, name = "DE-ASSIGNED"),
        @JsonSubTypes.Type(value = StatusChangedActionDTO.class, name = "STATUS_CHANGED"),
        @JsonSubTypes.Type(value = AddedToMilestoneActionDTO.class, name = "ADDED_TO_MILESTONE")
})
public interface ActionDTO {
    /** @return user who performed the action */
    String by();
    /** @return timestamp of the action */
    String timestamp();
}

