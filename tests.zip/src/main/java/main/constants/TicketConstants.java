package main.constants;

import lombok.Getter;

public class TicketConstants {

    // all
    public enum TicketType {
        BUG, FEATURE_REQUEST, UI_FEEDBACK
    }

    @Getter
    public enum BusinessPriority {
        LOW(1), MEDIUM(2), HIGH(3), CRITICAL(4);
        private final int value;
        BusinessPriority(final int value) {
            this.value = value;
        }
    }

    public enum TicketStatus {
        OPEN, IN_PROGRESS, RESOLVED, CLOSED
    }

    public enum ExpertiseArea {
        FRONTEND, BACKEND, DEVOPS, DESIGN, DB
    }

    // BUG
    @Getter
    public enum BugFrequency {
        RARE(1), OCCASIONAL(2), FREQUENT(3), ALWAYS(4);
        private final int value;
        BugFrequency(final int value) {
            this.value = value;
        }
    }

    @Getter
    public enum BugSeverity {
        MINOR(1), MODERATE(2), SEVERE(3);
        private final int value;
        BugSeverity(final int value) {
            this.value = value;
        }
    }

    public enum Environment {
        WINDOWS, LINUX, MACOS, IOS, ANDROID
    }

    // FEATURE_REQUEST and UI_FEEDBACK
    @Getter
    public enum BusinessValue {
        S(1), M(3), L(6), XL(10);
        private final int value;
        BusinessValue(final int value) {
            this.value = value;
        }
    }

    // FEATURE_REQUEST
    @Getter
    public enum CustomerDemand {
        LOW(1), MEDIUM(3), HIGH(6), VERY_HIGH(10);
        private final int value;
        CustomerDemand(final int value) {
            this.value = value;
        }
    }

}
