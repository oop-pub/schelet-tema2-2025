package main.constants;

import main.entities.users.enums.UserRole;

import java.util.List;
import java.util.Map;

public final class Permissions {
    private Permissions() {
        // Utility class
    }

    public static final Map<String, List<String>> COMMAND_PERMISSIONS = Map.ofEntries(
            Map.entry("reportTicket", List.of(UserRole.REPORTER.name())),
            Map.entry("addComment",
                    List.of(UserRole.REPORTER.name(), UserRole.DEVELOPER.name())),
            Map.entry("undoAddComment",
                    List.of(UserRole.REPORTER.name(), UserRole.DEVELOPER.name())),
            Map.entry("viewNotifications", List.of(UserRole.DEVELOPER.name())),
            Map.entry("viewTickets",
                    List.of(UserRole.REPORTER.name(), UserRole.DEVELOPER.name(),
                            UserRole.MANAGER.name())),
            Map.entry("assignTicket", List.of(UserRole.DEVELOPER.name())),
            Map.entry("undoAssignTicket", List.of(UserRole.DEVELOPER.name())),
            Map.entry("changeStatus", List.of(UserRole.DEVELOPER.name())),
            Map.entry("undoChangeStatus", List.of(UserRole.DEVELOPER.name())),
            Map.entry("viewAssignedTickets", List.of(UserRole.DEVELOPER.name())),
            Map.entry("viewTicketHistory",
                    List.of(UserRole.DEVELOPER.name(), UserRole.MANAGER.name())),
            Map.entry("viewMilestones",
                    List.of(UserRole.DEVELOPER.name(), UserRole.MANAGER.name())),
            Map.entry("search",
                    List.of(UserRole.DEVELOPER.name(), UserRole.MANAGER.name())),
            Map.entry("createMilestone", List.of(UserRole.MANAGER.name())),
            Map.entry("startTestingPhase", List.of(UserRole.MANAGER.name())),
            Map.entry("lostInvestors", List.of(UserRole.MANAGER.name())),
            Map.entry("generatePerformanceReport", List.of(UserRole.MANAGER.name())),
            Map.entry("generateCustomerImpactReport", List.of(UserRole.MANAGER.name())),
            Map.entry("generateTicketRiskReport", List.of(UserRole.MANAGER.name())),
            Map.entry("generateResolutionEfficiencyReport",
                    List.of(UserRole.MANAGER.name())),
            Map.entry("appStabilityReport", List.of(UserRole.MANAGER.name()))
    );

    public static final Map<String, List<String>> DEVELOPER_EXPERTISE_AREAS = Map.ofEntries(
            Map.entry("FRONTEND", List.of("FRONTEND", "DESIGN")),
            Map.entry("BACKEND", List.of("BACKEND", "DB")),
            Map.entry("FULLSTACK", List.of("FRONTEND", "BACKEND", "DEVOPS", "DESIGN", "DB")),
            Map.entry("DEVOPS", List.of("DEVOPS")),
            Map.entry("DESIGN", List.of("DESIGN", "FRONTEND")),
            Map.entry("DB", List.of("DB"))
    );

    // reverse mapping: ticket expertise area -> list of developer
    // expertise types that can handle it
    public static final Map<String, List<String>>
            TICKET_EXPERTISE_TO_DEVELOPER_TYPES = Map.ofEntries(
            Map.entry("FRONTEND", List.of("DESIGN", "FRONTEND",
                    "FULLSTACK")),
            Map.entry("BACKEND", List.of("BACKEND", "FULLSTACK")),
            Map.entry("DEVOPS", List.of("DEVOPS", "FULLSTACK")),
            Map.entry("DESIGN", List.of("DESIGN", "FRONTEND", "FULLSTACK")),
            Map.entry("DB", List.of("BACKEND", "DB", "FULLSTACK"))
    );

    public static final Map<String, List<String>> SENIORITY_PRIORITY_ACCESS = Map.ofEntries(
            Map.entry("JUNIOR", List.of("LOW", "MEDIUM")),
            Map.entry("MID", List.of("LOW", "MEDIUM", "HIGH")),
            Map.entry("SENIOR", List.of("LOW", "MEDIUM", "HIGH", "CRITICAL"))
    );

    // all lists are sorted lexicographically for consistent error messages
    public static final Map<String, List<String>> PRIORITY_SENIORITY_ACCESS = Map.ofEntries(
            Map.entry("LOW", List.of("JUNIOR", "MID", "SENIOR")),
            Map.entry("MEDIUM", List.of("JUNIOR", "MID", "SENIOR")),
            Map.entry("HIGH", List.of("MID", "SENIOR")),
            Map.entry("CRITICAL", List.of("SENIOR"))
    );

    public static final Map<String, List<String>> SENIORITY_TICKET_TYPES_ACCESS = Map.ofEntries(
            Map.entry("JUNIOR", List.of("BUG", "UI_FEEDBACK")),
            Map.entry("MID", List.of("BUG", "UI_FEEDBACK", "FEATURE_REQUEST")),
            Map.entry("SENIOR", List.of("BUG", "UI_FEEDBACK", "FEATURE_REQUEST"))
    );

    // all lists are sorted lexicographically for consistent error messages
    public static final Map<String, List<String>> TICKET_TYPES_SENIORITY_ACCESS = Map.ofEntries(
            Map.entry("BUG", List.of("JUNIOR", "MID", "SENIOR")),
            Map.entry("UI_FEEDBACK", List.of("JUNIOR", "MID", "SENIOR")),
            Map.entry("FEATURE_REQUEST", List.of("MID", "SENIOR"))
    );
}
