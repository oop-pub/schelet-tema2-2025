package main.constants;

import java.util.List;

public final class Constants {

    public static final List<String> PRIORITY_LIST = List.of("LOW", "MEDIUM", "HIGH", "CRITICAL");
    public static final List<String> TYPE_LIST = List.of("BUG", "FEATURE_REQUEST", "UI_FEEDBACK");

    private Constants() {
        // Utility class
    }

    public enum SearchType {
        TICKET, DEVELOPER
    }

    public enum NotificationType {
        UNBLOCKED, MILESTONE_CREATED, DEADLINE_APPROACHING, UNBLOCKED_AFTER_DEADLINE
    }

    public enum Risk {
        NEGLIGIBLE, MODERATE, SIGNIFICANT, MAJOR
    }


}
