package main.server.metrics;

import main.entities.tickets.Bug;
import main.entities.tickets.FeatureRequest;
import main.entities.tickets.UIFeedback;

/** Visitor interface for ticket metrics  */
public interface MetricVisitor {
    /**
     * Visits a bug ticket.
     * @param bug the bug ticket
     * @return calculated metric
     */
    double visit(Bug bug);

    /**
     * Visits a feature request.
     * @param featureRequest the feature request
     * @return calculated metric
     */
    double visit(FeatureRequest featureRequest);

    /**
     * Visits UI feedback.
     * @param uiFeedback the UI feedback
     * @return calculated metric
     */
    double visit(UIFeedback uiFeedback);
}
