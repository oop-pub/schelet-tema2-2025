package main.server.metrics;

import main.entities.tickets.Bug;
import main.entities.tickets.FeatureRequest;
import main.entities.tickets.UIFeedback;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CompositeVisitor implements MetricVisitor {
    private final List<MetricVisitor> visitors;

    public CompositeVisitor(final MetricVisitor... visitors) {
        this.visitors = new ArrayList<>(Arrays.asList(visitors));
    }

    public CompositeVisitor(final List<MetricVisitor> visitors) {
        this.visitors = new ArrayList<>(visitors);
    }

    /**
     * Adds a visitor.
     * @param visitor the visitor to add
     */
    public void addVisitor(final MetricVisitor visitor) {
        this.visitors.add(visitor);
    }

    /**
     * Removes a visitor.
     * @param visitor the visitor to remove
     */
    public void removeVisitor(final MetricVisitor visitor) {
        this.visitors.remove(visitor);
    }

    /**
     * Visits a bug ticket.
     * @param bug the bug ticket
     * @return last visitor result
     */
    @Override
    public double visit(final Bug bug) {
        double lastResult = 0.0;
        for (MetricVisitor visitor : visitors) {
            lastResult = visitor.visit(bug);
        }
        return lastResult;
    }

    /**
     * Visits a feature request ticket.
     * @param featureRequest the feature request ticket
     * @return last visitor result
     */
    @Override
    public double visit(final FeatureRequest featureRequest) {
        double lastResult = 0.0;
        for (MetricVisitor visitor : visitors) {
            lastResult = visitor.visit(featureRequest);
        }
        return lastResult;
    }

    /**
     * Visits a UI feedback ticket.
     * @param uiFeedback the UI feedback ticket
     * @return last visitor result
     */
    @Override
    public double visit(final UIFeedback uiFeedback) {
        double lastResult = 0.0;
        for (MetricVisitor visitor : visitors) {
            lastResult = visitor.visit(uiFeedback);
        }
        return lastResult;
    }
}
