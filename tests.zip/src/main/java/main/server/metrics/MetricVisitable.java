package main.server.metrics;

/** Interface for objects that can accept metric visitors. */
public interface MetricVisitable {
    /**
     * Accepts a metric visitor.
     * @param visitor the visitor
     * @return calculated metric value
     */
    double accept(MetricVisitor visitor);
}
