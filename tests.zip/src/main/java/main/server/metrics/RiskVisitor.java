package main.server.metrics;

import main.entities.tickets.Bug;
import main.entities.tickets.FeatureRequest;
import main.entities.tickets.Ticket;
import main.entities.tickets.UIFeedback;

import static main.constants.TicketConstants.TicketStatus.IN_PROGRESS;
import static main.constants.TicketConstants.TicketStatus.OPEN;

public class RiskVisitor implements MetricVisitor {
    private static final double BUG_MAX_RISK = 12.0;
    private static final double FEATURE_REQUEST_MAX_RISK = 20.0;
    private static final double UI_FEEDBACK_MAX_RISK = 100.0;
    private static final double PERCENTAGE_FACTOR = 100.0;

    /**
     * Visits a bug and calculates risk.
     * @param bug the bug ticket
     * @return risk score
     */
    @Override
    public double visit(final Bug bug) {
        if (invalid(bug)) {
            return -1.0;
        }

        double risk = bug.getFrequency().getValue() * bug.getSeverity().getValue();
        bug.setRiskScore((risk * PERCENTAGE_FACTOR) / BUG_MAX_RISK);
        return bug.getRiskScore();
    }

    /**
     * Visits a feature request and calculates risk.
     * @param featureRequest the feature request ticket
     * @return risk score
     */
    @Override
    public double visit(final FeatureRequest featureRequest) {
        if (invalid(featureRequest)) {
            return -1.0;
        }

        double risk = featureRequest.getBusinessValue().getValue()
                + featureRequest.getCustomerDemand().getValue();
        featureRequest.setRiskScore((risk * PERCENTAGE_FACTOR) / FEATURE_REQUEST_MAX_RISK);
        return featureRequest.getRiskScore();
    }

    /**
     * Visits UI feedback and calculates risk.
     * @param uiFeedback the UI feedback ticket
     * @return risk score
     */
    @Override
    public double visit(final UIFeedback uiFeedback) {
        if (invalid(uiFeedback)) {
            return -1.0;
        }

        double risk = uiFeedback.getBusinessValue().getValue()
                * uiFeedback.getUsabilityRating();
        uiFeedback.setRiskScore((risk * PERCENTAGE_FACTOR) / UI_FEEDBACK_MAX_RISK);
        return uiFeedback.getRiskScore();
    }

    private boolean invalid(final Ticket ticket) {
        return ticket.getStatus() != OPEN && ticket.getStatus() != IN_PROGRESS;
    }
}
