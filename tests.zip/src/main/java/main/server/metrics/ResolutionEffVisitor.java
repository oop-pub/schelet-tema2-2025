package main.server.metrics;

import main.entities.tickets.Bug;
import main.entities.tickets.FeatureRequest;
import main.entities.tickets.Ticket;
import main.entities.tickets.UIFeedback;

import static main.constants.TicketConstants.TicketStatus.CLOSED;
import static main.constants.TicketConstants.TicketStatus.RESOLVED;

public class ResolutionEffVisitor implements  MetricVisitor {
    private static final double MAX_BUG_EFF = 70.0;
    private static final double MAX_FR_EFF = 20.0;
    private static final double MAX_UI_EFF = 20.0;
    private static final double BUG_MULTIPLIER = 10.0;
    private static final double PERCENTAGE_FACTOR = 100.0;

    /**
     * Visits a bug and calculates efficiency.
     * @param bug the bug ticket
     * @return efficiency score
     */
    @Override
    public double visit(final Bug bug) {
        if (invalid(bug)) {
            return -1.0;
        }

        double score = ((bug.getFrequency().getValue()
                + bug.getSeverity().getValue()) * BUG_MULTIPLIER)
                / (double) bug.getDaysToResolve();
        double efficiency = (score * PERCENTAGE_FACTOR) / MAX_BUG_EFF;
        bug.setEfficiencyScore(efficiency);

        return bug.getEfficiencyScore();
    }

    /**
     * Visits a feature request and calculates efficiency.
     * @param featureRequest the feature request ticket
     * @return efficiency score
     */
    @Override
    public double visit(final FeatureRequest featureRequest) {
        if (invalid(featureRequest)) {
            return -1.0;
        }

        double score = (featureRequest.getBusinessValue().getValue()
                + featureRequest.getCustomerDemand().getValue())
                / (double) featureRequest.getDaysToResolve();
        double efficiency = (score * PERCENTAGE_FACTOR) / MAX_FR_EFF;
        featureRequest.setEfficiencyScore(efficiency);

        return featureRequest.getEfficiencyScore();
    }

    /**
     * Visits UI feedback and calculates efficiency.
     * @param uiFeedback the UI feedback ticket
     * @return efficiency score
     */
    @Override
    public double visit(final UIFeedback uiFeedback) {
        if (invalid(uiFeedback)) {
            return -1.0;
        }

        double score = (uiFeedback.getUsabilityRating()
                + uiFeedback.getBusinessValue().getValue())
                / (double) uiFeedback.getDaysToResolve();
        double efficiency = (score * PERCENTAGE_FACTOR) / MAX_UI_EFF;
        uiFeedback.setEfficiencyScore(efficiency);
        return uiFeedback.getEfficiencyScore();
    }

    private boolean invalid(final Ticket ticket) {
        return !(ticket.getStatus() == CLOSED || ticket.getStatus() == RESOLVED);
    }
}
