package main.server.metrics;

import main.entities.tickets.Bug;
import main.entities.tickets.FeatureRequest;
import main.entities.tickets.Ticket;
import main.entities.tickets.UIFeedback;

import static main.constants.TicketConstants.TicketStatus.IN_PROGRESS;
import static main.constants.TicketConstants.TicketStatus.OPEN;

public class ImpactVisitor implements MetricVisitor {
    private static final double MAX_BUG_IMPACT = 48.0;
    private static final double MAX_FEATURE_REQUEST_IMPACT = 100.0;
    private static final double MAX_UI_FEEDBACK_IMPACT = 100.0;
    private static final double PERCENTAGE_FACTOR = 100.0;

    /**
     * Visits a bug ticket and calculates impact.
     * @param bug the bug ticket
     * @return impact score
     */
    @Override
    public double visit(final Bug bug) {
        if (invalid(bug)) {
            return -1.0;
        }

        double score = bug.getFrequency().getValue()
                * bug.getSeverity().getValue()
                * bug.getBusinessPriority().getValue();
        bug.setImpactScore((score * PERCENTAGE_FACTOR) / MAX_BUG_IMPACT);
        return bug.getImpactScore();
    }

    /**
     * Visits a feature request and calculates impact.
     * @param featureRequest the feature request ticket
     * @return impact score
     */
    @Override
    public double visit(final FeatureRequest featureRequest) {
        if (invalid(featureRequest)) {
            return -1.0;
        }

        double score = featureRequest.getBusinessValue().getValue()
                * featureRequest.getCustomerDemand().getValue();
        featureRequest.setImpactScore((score * PERCENTAGE_FACTOR)
                / MAX_FEATURE_REQUEST_IMPACT);
        return featureRequest.getImpactScore();
    }

    /**
     * Visits a UI feedback and calculates impact.
     * @param uiFeedback the UI feedback ticket
     * @return impact score
     */
    @Override
    public double visit(final UIFeedback uiFeedback) {
        if (invalid(uiFeedback)) {
            return -1.0;
        }

        double score = uiFeedback.getBusinessValue().getValue()
                * uiFeedback.getUsabilityRating();
        uiFeedback.setImpactScore((score * PERCENTAGE_FACTOR) / MAX_UI_FEEDBACK_IMPACT);
        return uiFeedback.getImpactScore();
    }

    private boolean invalid(final Ticket ticket) {
        return !(ticket.getStatus() == OPEN || ticket.getStatus() == IN_PROGRESS);
    }
}
