package main.server.notifications;

import lombok.Getter;
import main.constants.Constants;

@Getter
public class Notification {
    private final Constants.NotificationType type;
    private final String message;

    public Notification(final Constants.NotificationType type, final String message) {
        this.type = type;
        this.message = message;
    }
}
