package main.server.notifications;

/**
 * subject interface for entities that generate notifications
 */
public interface Subject {
    /**
     * Attaches an observer.
     * @param observer the observer to attach
     */
    void attach(Observer observer);

    /**
     * Notifies all observers.
     * @param notification the notification to send
     */
    void notifyObservers(Notification notification);
}

