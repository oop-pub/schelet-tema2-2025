package main.server.notifications;

/**
 * observer interface for users who receive notifications
 */
public interface Observer {
    /**
     * Updates the observer with a notification.
     * @param notification the notification message
     */
    void update(String notification);

    /**
     * Gets the username of the observer.
     * @return username
     */
    String getUsername();
}

