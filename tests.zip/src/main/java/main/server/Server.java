package main.server;
import lombok.Data;
import main.constants.TicketConstants;
import main.constants.TicketConstants.BusinessPriority;
import main.dto.BaseDTO;
import main.entities.actions.RemovedFromDev;
import main.entities.users.AbstractUser;
import main.repositories.MilestoneRepo;
import main.repositories.TicketRepo;
import main.repositories.UserRepo;
import main.server.search.SearchBar;
import main.services.InfrastructureService;
import main.services.MilestoneService;
import main.services.ReportService;
import main.services.TicketService;
import main.services.VisualisationService;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static main.constants.Permissions.SENIORITY_PRIORITY_ACCESS;
import static main.constants.TicketConstants.TicketStatus.CLOSED;
import static main.constants.TicketConstants.TicketStatus.OPEN;

/**
 * Singleton server manages bug tracker application,
 * coordinates repositories services and testing phase transitions.
 */
@Data
public final class Server {
    private final TicketService ticketService;
    private final VisualisationService viewService;
    private final MilestoneService milestoneService;
    private final InfrastructureService infrastructureService;
    private final ReportService reportService;

    private final TicketRepo ticketRepository;
    private final UserRepo userRepository;
    private final MilestoneRepo milestoneRepository;

    private final List<BaseDTO> outputs;
    private SimpleDateFormat sdf;
    private static final int TEST_PHASE_DURATION = 12;

    private static Server instance = null;
    private boolean testing;
    private Date timestamp;
    private int daysInTesting;
    private boolean shutdown;

    private SearchBar<?> searchBar;

    /**
     * Private constructor enforces singleton pattern
     * and initializes all repositories and services.
     */
    private Server() {
        this.userRepository = new UserRepo();
        this.ticketRepository = new TicketRepo();
        this.milestoneRepository = new MilestoneRepo(this.ticketRepository);

        this.ticketService = new TicketService(this);
        this.viewService = new VisualisationService(this);
        this.milestoneService = new MilestoneService(this);
        this.infrastructureService = new InfrastructureService(this);
        this.reportService = new ReportService(this);

        this.outputs = new ArrayList<>();
        this.sdf = new SimpleDateFormat("yyyy-MM-dd");
        this.testing = true;
        this.timestamp = null;
        this.daysInTesting = 0;
        this.shutdown = false;
    }

    /** retrieves singleton instance and creates new one if none exists */
    public static Server getInstance() {
        if (instance == null) {
            instance = new Server();
        }
        return instance;
    }

    /** initializes user repository with list of users */
    public void initUsers(final List<AbstractUser> users) {
        this.userRepository.addUsers(users);
    }

    /** adds output object to outputs list */
    public void addOutput(final BaseDTO dto) {
        outputs.add(dto);
    }

    private static final long MS_PER_DAY = 1000L * 60 * 60 * 24;

    /**
     * Updates server timestamp, manages testing phase transitions,
     * and updates milestones.
     * @param dateString the date string
     */
    public void updateTs(final String dateString) {
        try {
            Date newDate = sdf.parse(dateString);
            if (this.timestamp != null) {
                long timeDiff = newDate.getTime() - this.timestamp.getTime();
                this.daysInTesting += (int) (timeDiff / MS_PER_DAY);
            }
            this.timestamp = newDate;
            if (daysInTesting >= TEST_PHASE_DURATION) {
                testing = false;
                daysInTesting = 0;
            }

            updateMilestones(dateString);
        } catch (final Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Updates all milestones with current date
     * for inactive status and priority escalation.
     * @param currentDateString the current date string
     */
    private void updateMilestones(final String currentDateString) {
        Map<Integer, TicketConstants.TicketStatus> ticketStatusMap = new HashMap<>();
        Map<Integer, BusinessPriority> ticketPriorityMap = new HashMap<>();

        ticketRepository.findAll().forEach(ticket -> {
            ticketStatusMap.put(ticket.getId(), ticket.getStatus());
            ticketPriorityMap.put(ticket.getId(), ticket.getBusinessPriority());
        });

        milestoneRepository.findAll().forEach(milestone ->
                milestone.update(ticketStatusMap, ticketPriorityMap,
                        currentDateString)
        );

        ticketPriorityMap.forEach((ticketId, priority) ->
                ticketRepository.findById(ticketId).ifPresent(ticket -> {
                    // find milestone and check if active and not blocked
                    var milestone = milestoneRepository.findById(
                            ticket.getMilestone()).orElse(null);
                    if (milestone == null || !milestone.isActive()
                            || milestone.isBlocked()) {
                        return;
                    }

                    // if milestone is active and not blocked and ticket is
                    // not closed, escalate priority
                    if (ticket.getStatus() != CLOSED) {
                        ticket.setBusinessPriority(priority);
                    }
                }));

        // unassign tickets if priority escalates beyond developer's
        // seniority level
        ticketPriorityMap.forEach((ticketId, priority) ->
                ticketRepository.findById(ticketId).ifPresent(ticket -> {
                    if (ticket.getAssignee() != null) {
                        userRepository.findById(ticket.getAssignee())
                                .ifPresent(user -> {
                            List<String> allowedPriorities =
                                    SENIORITY_PRIORITY_ACCESS.get(
                                            user.getSeniority().name());
                            if (!allowedPriorities.contains(
                                    priority.name())) {
                                ticket.setStatus(OPEN);
                                ticket.getActions().add(new RemovedFromDev(
                                        user.getUsername(),
                                        currentDateString));
                                ticket.setAssignee(null);
                                ticket.setAssignedAt(null);
                            }

                        });
                    }
                }));
    }

    /**
     * Resets server instance.
     */
    public void reset() {
        instance = null;
    }

    /** Starts a new testing phase by resetting testing counters. */
    public void startTestingPhase() {
        daysInTesting = 0;
        testing = true;
    }

}
