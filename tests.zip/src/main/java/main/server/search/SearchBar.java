package main.server.search;

import lombok.Setter;
import main.server.search.strategies.SearchStrategy;

import java.util.List;

@Setter
public class SearchBar<T> {
    private SearchStrategy<T> strategy;

    public SearchBar(final SearchStrategy<T> strategy) {
        this.strategy = strategy;
    }

    /**
     * Executes search with given filters.
     * @param filters the search filters
     * @param items the items to search
     * @return filtered list
     */
    public List<T> execute(final Filters filters, final List<T> items) {
        return strategy.search(filters, items);
    }
}
