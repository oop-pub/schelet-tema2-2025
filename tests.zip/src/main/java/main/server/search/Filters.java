package main.server.search;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

// filters for search strategies
@Getter
@Setter
public final class Filters {
    private String searchType;

    // dev fields
    private String businessPriority;
    private String type;
    private String createdAt;
    private String createdBefore;
    private String createdAfter;
    private Boolean availableForAssignment;

    // manager fields
    private List<String> keywords;
    private String expertiseArea;
    private String seniority;
    private Double performanceScoreAbove;
    private Double performanceScoreBelow;

    /**
     * Checks if no filters are set.
     * @return true if no filters are set
     */
    public boolean noFilters() {
        return (searchType == null || searchType.isEmpty())
                && (businessPriority == null || businessPriority.isEmpty())
                && (type == null || type.isEmpty())
                && (createdAt == null || createdAt.isEmpty())
                && (createdBefore == null || createdBefore.isEmpty())
                && (createdAfter == null || createdAfter.isEmpty())
                && (availableForAssignment == null)
                && (keywords == null || keywords.isEmpty())
                && (expertiseArea == null || expertiseArea.isEmpty())
                && (seniority == null || seniority.isEmpty())
                && (performanceScoreAbove == null)
                && (performanceScoreBelow == null);
    }
}

