package main.server.search.strategies;

import main.server.search.Filters;

import java.util.List;

/**
 * Strategy interface for searching over lists of items using provided filters.
 *
 * @param <T> the type of items to search
 */
public interface SearchStrategy<T> {
    /**
     * Search the provided list using the given filters.
     *
     * @param filters the filters to apply
     * @param list    the list of items to search
     * @return matching items
     */
    List<T> search(Filters filters, List<T> list);
}
