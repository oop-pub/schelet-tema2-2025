package main.server.search.strategies;

import main.entities.users.Developer;
import main.server.search.Filters;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

// manager developer search filters developers with performance metrics
public class ManagerDevSearchStrategy implements SearchStrategy<Developer> {

    /**
     * Searches developers with filters for manager.
     * @param filters the search filters
     * @param items the items to search
     * @return filtered list
     */
    @Override
    public List<Developer> search(final Filters filters, final List<Developer> items) {
        return items.stream()
                .filter(d -> matchesExpertiseArea(d, filters))
                .filter(d -> matchesSeniority(d, filters))
                .filter(d -> matchesPerformanceScoreAbove(d, filters))
                .filter(d -> matchesPerformanceScoreBelow(d, filters))
                .sorted(Comparator.comparing(Developer::getUsername))
                .collect(Collectors.toList());
    }

    private boolean matchesExpertiseArea(final Developer d, final Filters f) {
        return f.getExpertiseArea() == null
                || d.getExpertiseArea().name().equals(f.getExpertiseArea());
    }

    private boolean matchesSeniority(final Developer d, final Filters f) {
        return f.getSeniority() == null
                || d.getSeniority().name().equals(f.getSeniority());
    }

    private boolean matchesPerformanceScoreAbove(final Developer d, final Filters f) {
        return f.getPerformanceScoreAbove() == null
                || d.getPerformanceScore() >= f.getPerformanceScoreAbove();
    }

    private boolean matchesPerformanceScoreBelow(final Developer d, final Filters f) {
        return f.getPerformanceScoreBelow() == null
                || d.getPerformanceScore() <= f.getPerformanceScoreBelow();
    }
}
