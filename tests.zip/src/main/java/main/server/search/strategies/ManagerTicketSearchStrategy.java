package main.server.search.strategies;

import main.entities.tickets.Ticket;
import main.server.search.Filters;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

// manager ticket search extends developer search and adds keywords filter
public class ManagerTicketSearchStrategy extends DevTicketSearchStrategy {

    public ManagerTicketSearchStrategy() {
        super(null);
    }

    /**
     * Searches tickets with filters for manager.
     * @param filters the search filters
     * @param items the items to search
     * @return filtered list
     */
    @Override
    public List<Ticket> search(final Filters filters, final List<Ticket> items) {
        // manager sees all tickets, no status or milestone restrictions
        return items.stream()
                .filter(t -> matchesBusinessPriority(t, filters))
                .filter(t -> matchesType(t, filters))
                .filter(t -> matchesCreatedAt(t, filters))
                .filter(t -> matchesCreatedBefore(t, filters))
                .filter(t -> matchesCreatedAfter(t, filters))
                .filter(t -> matchesKeywords(t, filters))
                .sorted(Comparator.comparing(Ticket::getCreatedAt)
                        .thenComparing(Ticket::getId))
                .collect(Collectors.toList());
    }

    private boolean matchesKeywords(final  Ticket t, final Filters f) {
        if (f.getKeywords() == null || f.getKeywords().isEmpty()) {
            return true;
        }

        String title = t.getTitle() == null ? "" : t.getTitle().toLowerCase();
        String description = t.getDescription() == null ? "" : t.getDescription().toLowerCase();


        for (String keyword : f.getKeywords()) {
            String lowerKeyword = keyword.toLowerCase();
            if (title.contains(lowerKeyword)
                    || description.contains(lowerKeyword)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Finds matching keywords in description and title.
     * @param t the ticket
     * @param keywords the keywords
     * @return true if matches
     */
    public boolean getMatchingWords(final Ticket t, final List<String> keywords) {
        if (keywords == null || keywords.isEmpty()) {
            return false;
        }

        String title = t.getTitle() == null ? "" : t.getTitle().toLowerCase();
        String description = t.getDescription() == null ? "" : t.getDescription().toLowerCase();

        for (String keyword : keywords) {
            String lowerKeyword = keyword.toLowerCase();
            if (title.contains(lowerKeyword) || description.contains(lowerKeyword)) {
                return true;
            }
        }
        return false;
    }
}
