package main.server.search.strategies;

import main.entities.tickets.Ticket;
import main.entities.users.Developer;
import main.server.search.Filters;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;


import static main.constants.Permissions.DEVELOPER_EXPERTISE_AREAS;
import static main.constants.Permissions.SENIORITY_PRIORITY_ACCESS;
import static main.constants.Permissions.SENIORITY_TICKET_TYPES_ACCESS;
import static main.constants.TicketConstants.TicketStatus.OPEN;

// developer ticket search filters only open tickets in dev's milestones
public class DevTicketSearchStrategy implements SearchStrategy<Ticket> {
    private final Developer developer;
    public DevTicketSearchStrategy(final Developer developer) {
        this.developer = developer;
    }

    /**
     * Searches tickets with filters for developer.
     * @param filters the search filters
     * @param items the items to search
     * @return filtered list
     */
    @Override
    public List<Ticket> search(final Filters filters, final List<Ticket> items) {
        return items.stream()
                .filter(t -> t.getStatus() == OPEN)
                .filter(t -> matchesBusinessPriority(t, filters))
                .filter(t -> matchesType(t, filters))
                .filter(t -> matchesCreatedAt(t, filters))
                .filter(t -> matchesCreatedBefore(t, filters))
                .filter(t -> matchesCreatedAfter(t, filters))
                .filter(t -> matchesAvailableForAssignment(t, filters))
                .sorted(Comparator.comparing(Ticket::getCreatedAt).thenComparing(Ticket::getId))
                .collect(Collectors.toList());
    }

    /**
     * Checks if ticket matches business priority filter.
     * @param t the ticket
     * @param f the filters
     * @return true if matches
     */
    protected boolean matchesBusinessPriority(final Ticket t, final Filters f) {
        return f.getBusinessPriority() == null
                || t.getBusinessPriority().name().equals(f.getBusinessPriority());
    }

    /**
     * Checks if ticket matches type filter.
     * @param t the ticket
     * @param f the filters
     * @return true if matches
     */
    protected boolean matchesType(final Ticket t, final Filters f) {
        return f.getType() == null || t.getType().name().equals(f.getType());
    }

    /**
     * Checks if ticket matches created at filter.
     * @param t the ticket
     * @param f the filters
     * @return true if matches
     */
    protected boolean matchesCreatedAt(final Ticket t, final Filters f) {
        return f.getCreatedAt() == null || t.getCreatedAt().equals(f.getCreatedAt());
    }

    /**
     * Checks if ticket matches created before filter.
     * @param t the ticket
     * @param f the filters
     * @return true if matches
     */
    protected boolean matchesCreatedBefore(final Ticket t, final Filters f) {
        if (f.getCreatedBefore() == null) {
            return true;
        }
        LocalDate ticketDate = LocalDate.parse(t.getCreatedAt());
        LocalDate beforeDate = LocalDate.parse(f.getCreatedBefore());
        return ticketDate.isBefore(beforeDate);
    }

    /**
     * Checks if ticket matches created after filter.
     * @param t the ticket
     * @param f the filters
     * @return true if matches
     */
    protected boolean matchesCreatedAfter(final Ticket t, final Filters f) {
        if (f.getCreatedAfter() == null) {
            return true;
        }
        LocalDate ticketDate = LocalDate.parse(t.getCreatedAt());
        LocalDate afterDate = LocalDate.parse(f.getCreatedAfter());
        return ticketDate.isAfter(afterDate);
    }

    private boolean matchesAvailableForAssignment(final Ticket t,
                                                  final Filters f) {
        if (f.getAvailableForAssignment() == null
                || !f.getAvailableForAssignment()) {
            return true;
        }

        // check expertise area
        List<String> allowedAreas = DEVELOPER_EXPERTISE_AREAS.get(
                developer.getExpertiseArea().name());
        if (!allowedAreas.contains(t.getExpertiseArea().name())) {
            return false;
        }

        // check seniority
        List<String> allowedPriorities = SENIORITY_PRIORITY_ACCESS.get(
                developer.getSeniority().name());
        if (!allowedPriorities.contains(t.getBusinessPriority().name())) {
            return false;
        }

        // check ticket type
        List<String> allowedTypes = SENIORITY_TICKET_TYPES_ACCESS.get(
                developer.getSeniority().name());
        return allowedTypes.contains(t.getType().name());
    }
}
