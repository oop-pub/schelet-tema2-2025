package main.server.performance;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class PerformanceData {
    private String username;
    private int closedTickets;
    private double performanceScore;
    private double averageResolutionTime;
    private String seniority;
}
