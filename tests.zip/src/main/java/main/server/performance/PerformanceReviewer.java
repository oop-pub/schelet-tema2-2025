package main.server.performance;

import lombok.Data;
import main.entities.tickets.Ticket;
import main.server.performance.strategies.PerformanceStrategy;

import java.util.List;

@Data
public final class PerformanceReviewer {
    private PerformanceStrategy strategy;

    public PerformanceReviewer(final PerformanceStrategy strategy) {
        this.strategy = strategy;
    }

    /**
     * Calculates performance for given tickets.
     * @param tickets list of tickets
     * @return performance score
     */
    public double review(final List<Ticket> tickets) {
        return strategy.calculatePerformance(tickets);
    }
}
