package main.server.performance.strategies;

import main.entities.tickets.Ticket;

import java.util.List;

import static main.constants.TicketConstants.BusinessPriority.CRITICAL;
import static main.constants.TicketConstants.BusinessPriority.HIGH;

public class SeniorStrategy implements PerformanceStrategy {
    private static final double SENIORITY_BONUS = 30.0;
    private static final double CLOSED_WEIGHT = 0.5;
    private static final double HIGH_PRIORITY_WEIGHT = 1.0;
    private static final double TIME_PENALTY = 0.5;

    /**
     * Calculates performance for senior developers.
     * @param tickets list of tickets
     * @return performance score
     */
    @Override
    public double calculatePerformance(final List<Ticket> tickets) {
        int highPriorityTickets = 0, closedTickets = tickets.size();
        double totalResolutionTime = 0.0;

        for (Ticket t : tickets) {
            var priority = t.getBusinessPriority();
            if (priority == HIGH || priority == CRITICAL) {
                highPriorityTickets++;
            }
            int days = t.getDaysToResolve();
            totalResolutionTime += days;
        }
        double averageResolutionTime = closedTickets > 0
                ? totalResolutionTime / closedTickets : 0.0;
        return Math.max(0, CLOSED_WEIGHT * closedTickets
                + HIGH_PRIORITY_WEIGHT * highPriorityTickets
                - TIME_PENALTY * averageResolutionTime) + SENIORITY_BONUS;
    }
}
