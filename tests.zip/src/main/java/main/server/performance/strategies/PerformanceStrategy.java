package main.server.performance.strategies;

import main.entities.tickets.Ticket;

import java.util.List;
/** strategy interface for performance calculation */
public interface PerformanceStrategy {
    /** calculate performance; TICKETS MUST BE CLOSED FOR THE USER IN PREVIOUS MONTH */
    double calculatePerformance(List<Ticket> tickets);

}
