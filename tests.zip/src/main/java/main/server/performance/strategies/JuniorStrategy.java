package main.server.performance.strategies;

import main.entities.tickets.Ticket;

import java.util.List;

public class JuniorStrategy implements PerformanceStrategy {

    private static final double SENIORITY_BONUS = 5.0;
    private static final double CLOSED_TICKETS_WEIGHT = 0.5;
    private static final double TYPE_COUNT = 3.0;

    /**
     * Calculates performance for junior developers.
     * @param tickets list of tickets
     * @return performance score
     */
    @Override
    public double calculatePerformance(final List<Ticket> tickets) {
        int bug = 0, feature = 0, ui = 0;
        for (Ticket t : tickets) {
            switch (t.getType()) {
                case BUG -> bug++;
                case FEATURE_REQUEST -> feature++;
                case UI_FEEDBACK -> ui++;
                default -> {
                    // No action for other types
                }
            }
        }
        int closedTickets = bug + feature + ui;
        double diversity = ticketDiversityFactor(bug, feature, ui);
        return Math.max(0, CLOSED_TICKETS_WEIGHT * closedTickets - diversity) + SENIORITY_BONUS;
    }

    private double averageResolvedTicketType(final int bug, final int feature, final int ui) {
        return (bug + feature + ui) / TYPE_COUNT;
    }

    private double standardDeviation(final int bug, final int feature, final int ui) {
        double mean = averageResolvedTicketType(bug, feature, ui);
        double variance = (Math.pow(bug - mean, 2) + Math.pow(feature - mean, 2)
                + Math.pow(ui - mean, 2)) / TYPE_COUNT;
        return Math.sqrt(variance);
    }

    private double ticketDiversityFactor(final int bug, final int feature, final int ui) {
        double mean = averageResolvedTicketType(bug, feature, ui);
        if (mean == 0.0) {
            return 0.0;
        }
        double std = standardDeviation(bug, feature, ui);
        return std / mean;
    }
}
