package main.server;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import main.commands.AbstractCmd;
import main.entities.users.AbstractUser;

import java.io.File;
import java.io.IOException;
import java.util.List;

/** reads users and commands from json files */
public class Reader {
    private final ObjectMapper mapper = new ObjectMapper();

    /** reads users from json file */
    public List<AbstractUser> readUsers(final File jsonFile) throws IOException {
        return mapper.readValue(jsonFile, new TypeReference<List<AbstractUser>>() { });
    }

    /** reads commands from json file */
    public List<AbstractCmd> readCommands(final File jsonFile) throws IOException {
        return mapper.readValue(jsonFile, new TypeReference<List<AbstractCmd>>() { });
    }
}
