package main;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import main.server.Reader;
import main.server.Server;

import java.io.File;
import java.io.IOException;

/** main application logic processes input commands and writes outputs to file */
public final class App {
    private static final String INPUT_FILE = "input/database/users.json";
    private static final ObjectWriter WRITER =
            new ObjectMapper().writer().withDefaultPrettyPrinter();

    private App() {
        // Utility class
    }

    /** runs app by reading commands processing them and writing results to output file */
    public static void run(final String inputCommandsFile, final String outputFile)
            throws IOException {
        var server = Server.getInstance();
        var reader = new Reader();

        server.initUsers(reader.readUsers(new File(INPUT_FILE)));

        reader.readCommands(new File(inputCommandsFile))
                .stream()
                .takeWhile(cmd -> !server.isShutdown())
                .forEach(cmd -> {
                    server.updateTs(cmd.getTimestamp());
                    cmd.process();
                });

        try {
            File file = new File(outputFile);
            file.getParentFile().mkdirs();
            WRITER.withDefaultPrettyPrinter().writeValue(file, server.getOutputs());
        } catch (final IOException e) {
            System.out.println("error writing to output file: " + e.getMessage());
        }

        server.reset();
    }

}
