package main.commands.reports;

import main.commands.AbstractCmd;
import main.output.OutputBuilder;
import main.server.Server;

public final class GenPerfReportCmd extends AbstractCmd {
    @Override
    public void process() {
        Server server = Server.getInstance();
        var result = server.getReportService().genPerformanceReport(this);
        var dto = OutputBuilder.fromPerformanceReport(this, result);

        server.addOutput(dto);
    }
}
