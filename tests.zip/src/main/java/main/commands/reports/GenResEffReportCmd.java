package main.commands.reports;

import main.commands.AbstractCmd;
import main.output.OutputBuilder;
import main.server.Server;

public final class GenResEffReportCmd extends AbstractCmd {
    @Override
    public void process() {
        Server server = Server.getInstance();
        var result = server.getReportService().generateEffReport(this);

        var dto = OutputBuilder.fromEffReport(this, result);

        server.addOutput(dto);

    }
}
