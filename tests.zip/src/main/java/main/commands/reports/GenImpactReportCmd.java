package main.commands.reports;

import main.commands.AbstractCmd;
import main.output.OutputBuilder;
import main.server.Server;

public final class GenImpactReportCmd extends AbstractCmd {
    @Override
    public void process() {
        Server server = Server.getInstance();
        var result = server.getReportService().generateImpactReport(this);

        var dto = OutputBuilder.fromGenImpactReport(this, result);
        server.addOutput(dto);
    }
}
