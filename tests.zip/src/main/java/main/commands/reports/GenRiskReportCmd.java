package main.commands.reports;

import main.commands.AbstractCmd;
import main.output.OutputBuilder;
import main.server.Server;

public final class GenRiskReportCmd extends AbstractCmd {
    @Override
    public void process() {
        Server server = Server.getInstance();
        var result = server.getReportService().generateRiskReport(this);

        var dto = OutputBuilder.fromRiskReport(this, result);

        server.addOutput(dto);
    }
}
