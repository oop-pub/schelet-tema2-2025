package main.commands.reports;

import main.commands.AbstractCmd;
import main.output.OutputBuilder;
import main.server.Server;

public final class GenStabilityReportCmd extends AbstractCmd {
    @Override
    public void process() {
        Server server = Server.getInstance();
        var result = server.getReportService().genStabilityReport(this);
        var dto = OutputBuilder.fromStabilityReport(this, result);

        server.addOutput(dto);
    }
}
