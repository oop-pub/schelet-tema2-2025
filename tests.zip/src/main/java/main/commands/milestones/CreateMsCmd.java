package main.commands.milestones;

import lombok.Getter;
import main.commands.AbstractCmd;
import main.output.OutputBuilder;
import main.server.Server;

import java.util.List;

@Getter
public final class CreateMsCmd extends AbstractCmd {
    private String name;
    private String dueDate;
    private List<String> blockingFor;
    private List<Integer> tickets;
    private List<String> assignedDevs;


    @Override
    public void process() {
        Server server = Server.getInstance();
        var result = server.getMilestoneService().create(this);

        var dto = OutputBuilder.fromCreateMs(this, result);

        if (dto != null) {
            Server.getInstance().addOutput(dto);
        }
    }
}
