package main.commands.tickets;

import lombok.Data;
import main.commands.AbstractCmd;
import main.output.OutputBuilder;
import main.server.Server;

@Data
public final class ReportTicketCmd extends AbstractCmd {
    private Params params;

    @Data
    public static class Params {
        private String type;
        private String title;
        private String businessPriority;
        private String reportedBy;
        private String expertiseArea;
        private String description;
        private String expectedBehavior;
        private String actualBehavior;
        private String frequency;
        private String severity;
        private String environment;
        private Integer errorCode;
        private String businessValue;
        private String customerDemand;
        private String uiElementId;
        private Integer usabilityScore;
        private String suggestedFix;
        private String screenshotUrl;
    }

    @Override
    public void process() {
        var result = Server.getInstance().getTicketService().report(this);

        var dto = OutputBuilder.fromReport(this, result);

        if (dto != null)  {
            Server.getInstance().addOutput(dto);
        }
    }
}
