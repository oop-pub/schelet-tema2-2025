package main.commands.tickets;

import lombok.Getter;
import main.commands.AbstractCmd;
import main.output.OutputBuilder;
import main.server.Server;

@Getter
public final class UndoAssignCmd extends AbstractCmd {
    private Integer ticketID;

    @Override
    public void process() {
        Server server = Server.getInstance();
        var result = server.getTicketService().undoAssign(this);

        var dto = OutputBuilder.fromUndoAssign(this, result);

        if (dto != null) {
            Server.getInstance().addOutput(dto);
        }
    }
}
