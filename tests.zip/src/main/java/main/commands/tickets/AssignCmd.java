package main.commands.tickets;

import lombok.Getter;
import main.commands.AbstractCmd;
import main.output.OutputBuilder;
import main.server.Server;

@Getter
public final class AssignCmd extends AbstractCmd {
    protected Integer ticketID;

    @Override
    public void process() {
        Server server = Server.getInstance();
        var result = server.getTicketService().assign(this);

        var dto = OutputBuilder.fromAssign(this, result);

        if (dto != null) {
            Server.getInstance().addOutput(dto);
        }
    }

}
