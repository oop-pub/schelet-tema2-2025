package main.commands.tickets;

import lombok.Getter;
import main.commands.AbstractCmd;
import main.output.OutputBuilder;
import main.server.Server;

@Getter
public final class UndoChangeStCmd extends AbstractCmd {
    private int ticketID;

    @Override
    public void process() {
        Server server = Server.getInstance();

        var result = server.getTicketService().undoChangeStatus(this);
        var dto = OutputBuilder.fromUndoChangeStatus(this, result);

        if (dto != null) {
            Server.getInstance().addOutput(dto);
        }
    }
}
