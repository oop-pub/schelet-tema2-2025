package main.commands.tickets;

import lombok.Getter;
import main.commands.AbstractCmd;
import main.output.OutputBuilder;
import main.server.Server;

@Getter
public final class UndoAddCommentCmd extends AbstractCmd {
    private int ticketID;

    @Override
    public void process() {
        var server = Server.getInstance();
        var result = server.getTicketService().undoAddComment(this);

        var dto = OutputBuilder.fromUndoAddComment(this, result);

        if (dto != null) {
            Server.getInstance().addOutput(dto);
        }
    }

}
