package main.commands.tickets;

import lombok.Data;
import main.commands.AbstractCmd;
import main.output.OutputBuilder;
import main.server.Server;

@Data
public final class ChangeStCmd extends AbstractCmd {
    private int ticketID;

    @Override
    public void process() {
        Server server = Server.getInstance();

        var result = server.getTicketService().changeStatus(this);
        var dto = OutputBuilder.fromChangeStatus(this, result);

        if (dto != null) {
            Server.getInstance().addOutput(dto);
        }
    }
}
