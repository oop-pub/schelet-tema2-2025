package main.commands.general;

import lombok.Getter;
import main.commands.AbstractCmd;
import main.output.OutputBuilder;
import main.server.Server;
import main.server.search.Filters;

@Getter
public final class SearchCmd extends AbstractCmd {
    private Filters filters;
    @Override
    public void process() {
        Server server = Server.getInstance();
        var result = server.getInfrastructureService().search(this);

        var dto = OutputBuilder.fromSearch(this, result);

        server.addOutput(dto);
    }
}
