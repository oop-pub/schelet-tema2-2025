package main.commands.general;

import main.commands.AbstractCmd;
import main.server.Server;

public final class LostInvestorsCmd extends AbstractCmd {
    @Override
    public void process() {
        Server.getInstance().setShutdown(true);
    }

}
