package main.commands.general;

import main.commands.AbstractCmd;
import main.output.OutputBuilder;
import main.server.Server;

public final class StartTestingPhaseCmd extends AbstractCmd {
    @Override
    public void process() {
        Server server = Server.getInstance();
        var result = server.getInfrastructureService().startTesting(this);
        var dto = OutputBuilder.fromStartTesting(this, result);

        if (dto != null) {
            server.addOutput(dto);
        }


    }
}
