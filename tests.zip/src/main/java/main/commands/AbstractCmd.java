package main.commands;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import lombok.Data;
import main.commands.general.LostInvestorsCmd;
import main.commands.general.SearchCmd;
import main.commands.general.StartTestingPhaseCmd;
import main.commands.milestones.CreateMsCmd;
import main.commands.reports.GenImpactReportCmd;
import main.commands.reports.GenPerfReportCmd;
import main.commands.reports.GenResEffReportCmd;
import main.commands.reports.GenRiskReportCmd;
import main.commands.reports.GenStabilityReportCmd;
import main.commands.tickets.AddCommentCmd;
import main.commands.tickets.AssignCmd;
import main.commands.tickets.ChangeStCmd;
import main.commands.tickets.ReportTicketCmd;
import main.commands.tickets.UndoAddCommentCmd;
import main.commands.tickets.UndoAssignCmd;
import main.commands.tickets.UndoChangeStCmd;
import main.commands.view.ViewAssignedCmd;
import main.commands.view.ViewMsCmd;
import main.commands.view.ViewNotificationsCmd;
import main.commands.view.ViewTicketHistoryCmd;
import main.commands.view.ViewTicketsCmd;

/**
 * Base class for all commands
 */
@Data
@JsonTypeInfo(
        use = JsonTypeInfo.Id.NAME,
        include = JsonTypeInfo.As.EXISTING_PROPERTY,
        property = "command",
        visible = true
)
@JsonSubTypes({
        @JsonSubTypes.Type(value = ReportTicketCmd.class, name = "reportTicket"),
        @JsonSubTypes.Type(value = ViewTicketsCmd.class, name = "viewTickets"),
        @JsonSubTypes.Type(value = LostInvestorsCmd.class, name = "exit"),
        @JsonSubTypes.Type(value = LostInvestorsCmd.class,
                name = "lostInvestors"),
        @JsonSubTypes.Type(value = CreateMsCmd.class, name = "createMilestone"),
        @JsonSubTypes.Type(value = ViewMsCmd.class, name = "viewMilestones"),
        @JsonSubTypes.Type(value = AssignCmd.class, name = "assignTicket"),
        @JsonSubTypes.Type(value = ViewAssignedCmd.class, name = "viewAssignedTickets"),
        @JsonSubTypes.Type(value = UndoAssignCmd.class, name = "undoAssignTicket"),
        @JsonSubTypes.Type(value = AddCommentCmd.class, name = "addComment"),
        @JsonSubTypes.Type(value = UndoAddCommentCmd.class, name = "undoAddComment"),
        @JsonSubTypes.Type(value = ChangeStCmd.class, name = "changeStatus"),
        @JsonSubTypes.Type(value = UndoChangeStCmd.class, name = "undoChangeStatus"),
        @JsonSubTypes.Type(value = ViewTicketHistoryCmd.class, name = "viewTicketHistory"),
        @JsonSubTypes.Type(value = GenPerfReportCmd.class, name = "generatePerformanceReport"),
        @JsonSubTypes.Type(value = GenImpactReportCmd.class, name = "generateCustomerImpactReport"),
        @JsonSubTypes.Type(value = GenRiskReportCmd.class, name = "generateTicketRiskReport"),
        @JsonSubTypes.Type(value = GenResEffReportCmd.class,
                name = "generateResolutionEfficiencyReport"),
        @JsonSubTypes.Type(value = GenStabilityReportCmd.class, name = "appStabilityReport"),
        @JsonSubTypes.Type(value = SearchCmd.class, name = "search"),
        @JsonSubTypes.Type(value = ViewNotificationsCmd.class, name = "viewNotifications"),
        @JsonSubTypes.Type(value = StartTestingPhaseCmd.class, name = "startTestingPhase")
})
public abstract class AbstractCmd {
    protected String username;
    protected String command;

    protected String timestamp;

    /**
     * Process the command.
     */
    public abstract void process();
}
