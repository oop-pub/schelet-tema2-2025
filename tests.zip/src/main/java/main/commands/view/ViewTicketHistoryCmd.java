package main.commands.view;

import lombok.Getter;
import main.commands.AbstractCmd;
import main.output.OutputBuilder;
import main.server.Server;

@Getter
public final class ViewTicketHistoryCmd extends AbstractCmd {

    @Override
    public void process() {
        Server server = Server.getInstance();

        var result = server.getViewService().viewHistory(this);
        var dto = OutputBuilder.fromViewTicketHistory(this, result);

        if (dto != null) {
            Server.getInstance().addOutput(dto);
        }
    }
}
