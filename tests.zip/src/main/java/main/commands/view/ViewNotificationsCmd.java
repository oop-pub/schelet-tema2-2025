package main.commands.view;

import main.commands.AbstractCmd;
import main.output.OutputBuilder;
import main.server.Server;

public final class ViewNotificationsCmd extends AbstractCmd {
    @Override
    public void process() {
        Server server = Server.getInstance();
        var result = server.getViewService().viewNotifications(this);

        var dto = OutputBuilder.fromViewNotifications(this, result);
        if (dto != null) {
            server.addOutput(dto);
        }
    }
}
