package main.commands.view;

import main.commands.AbstractCmd;
import main.output.OutputBuilder;
import main.server.Server;

public final class ViewAssignedCmd extends AbstractCmd {
    @Override
    public void process() {
        Server server = Server.getInstance();
        var result = server.getViewService().viewAssigned(this);
        var dto = OutputBuilder.fromViewAssigned(this, result);

        server.addOutput(dto);
    }
}
