package main.commands.view;

import main.commands.AbstractCmd;
import main.output.OutputBuilder;
import main.server.Server;

public final class ViewMsCmd extends AbstractCmd {
    @Override
    public void process() {
        Server server = Server.getInstance();
        var result = server.getViewService().viewMilestones(this);
        var dto = OutputBuilder.fromViewMs(this, result);

        server.addOutput(dto);
    }
}
