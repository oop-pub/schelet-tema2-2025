package main.commands.view;

import lombok.Getter;
import main.commands.AbstractCmd;
import main.commands.general.SearchCmd;
import main.output.OutputBuilder;
import main.server.Server;

@Getter
public final class ViewTicketsCmd extends AbstractCmd {

    public ViewTicketsCmd() {
    }

    public ViewTicketsCmd(final SearchCmd cmd) {
        this.username = cmd.getUsername();
        this.timestamp = cmd.getTimestamp();
        this.command = cmd.getCommand();
    }

    @Override
    public void process() {
        Server server = Server.getInstance();
        var result = server.getViewService().viewTickets(this);
        var dto = OutputBuilder.fromViewTickets(this, result);

        server.addOutput(dto);
    }
}
